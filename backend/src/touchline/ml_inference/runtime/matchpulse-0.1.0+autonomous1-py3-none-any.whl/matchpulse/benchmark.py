"""Measured real-detector latency matrix; does not modify FPS, models or results."""

import argparse
import importlib.metadata
import json
import platform
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from pathlib import Path
from threading import Event, Thread
from time import perf_counter

import numpy as np

from .cli import result_summary
from .features import DetectorConfig, ExtractorConfig, MatchFeatureExtractor, SharedBatchDetector


class GpuSampler:
    def __init__(self):
        self.samples = []
        self._stop = Event()
        self.error = None
        self._thread = None

    def __enter__(self):
        try:
            import pynvml

            pynvml.nvmlInit()
            self.nvml = pynvml
            self.handles = [pynvml.nvmlDeviceGetHandleByIndex(i) for i in range(pynvml.nvmlDeviceGetCount())]
            self._thread = Thread(target=self._sample, daemon=True)
            self._thread.start()
        except (ImportError, OSError, RuntimeError) as exc:
            self.error = str(exc)
        except Exception as exc:
            # pynvml defines platform-specific NVMLError subclasses.
            self.error = str(exc)
        return self

    def _sample(self):
        while not self._stop.is_set():
            try:
                for i, handle in enumerate(self.handles):
                    self.samples.append(
                        {
                            "device": i,
                            "utilization_percent": self.nvml.nvmlDeviceGetUtilizationRates(handle).gpu,
                            "used_memory_bytes": self.nvml.nvmlDeviceGetMemoryInfo(handle).used,
                        }
                    )
            except self.nvml.NVMLError as exc:
                self.error = str(exc)
                break
            self._stop.wait(0.1)

    def __exit__(self, *args):
        self._stop.set()
        if self._thread:
            self._thread.join()
            self.nvml.nvmlShutdown()

    def report(self):
        return {
            "per_device": {
                str(device): {
                    "mean_utilization_percent": float(
                        np.mean([s["utilization_percent"] for s in self.samples if s["device"] == device])
                    ),
                    "peak_used_memory_bytes": max(
                        s["used_memory_bytes"] for s in self.samples if s["device"] == device
                    ),
                }
                for device in sorted({s["device"] for s in self.samples})
            },
            "availability_error": self.error,
            "mean_utilization_percent": float(np.mean([s["utilization_percent"] for s in self.samples]))
            if self.samples
            else None,
            "peak_used_memory_bytes": max((s["used_memory_bytes"] for s in self.samples), default=None),
            "samples": len(self.samples),
        }


def benchmark(
    video, config, *, repeats=5, warmup=1, start=None, cache_mode="cold", streams=1, extractor_config=None
):
    if repeats < 1 or warmup < 0 or streams < 1:
        raise ValueError("Invalid repeat, warmup or stream count")
    t = perf_counter()
    extractor = MatchFeatureExtractor(detector_config=config, config=extractor_config)
    shared = SharedBatchDetector(extractor.detector, max_batch=config.batch_size) if streams > 1 else None
    if shared:
        extractor.detector = shared
    extractors = [extractor] + [
        MatchFeatureExtractor(detector=shared, config=extractor.config) for _ in range(streams - 1)
    ]
    load = perf_counter() - t
    pool = ThreadPoolExecutor(max_workers=streams)
    window_index = 0

    def run_worker(worker):
        if cache_mode == "cold":
            worker.clear_cache()
        if cache_mode == "overlap":
            worker.extract_window(video, (start or 0) + window_index)
        elif start is None:
            worker.extract(video)
        else:
            worker.extract_window(video, start)
        return dict(worker.last_result.timings)

    def run():
        nonlocal window_index
        before = perf_counter()
        workers = list(pool.map(run_worker, extractors))
        wall = perf_counter() - before
        window_index += 1
        timings = {key: float(np.mean([w[key] for w in workers])) for key in workers[0]}
        timings["total"] = wall
        return timings

    try:
        with GpuSampler() as gpu:
            first = run()
            for _ in range(warmup):
                run()
            runs = [run() for _ in range(repeats)]
    finally:
        pool.shutdown(wait=True)
        if shared:
            shared.close()
    latencies = [r["total"] for r in runs]
    stages = {stage: float(np.mean([r[stage] for r in runs])) for stage in runs[0]}
    bottleneck = max((s for s in stages if s != "total"), key=stages.get)
    import cv2
    import torch

    return {
        "detector_config": asdict(config),
        "extractor_config": asdict(extractor.config),
        "steps_per_window": extractor.steps,
        "cache_mode": cache_mode,
        "streams": streams,
        "effective_native_threads": {"opencv": cv2.getNumThreads(), "torch": torch.get_num_threads()},
        "load_seconds": load,
        "first_extraction_seconds": first,
        "warmup_runs": warmup,
        "repeats": repeats,
        "runs_seconds": runs,
        "warm_latency_seconds": {
            "mean": float(np.mean(latencies)),
            **{f"p{p}": float(np.percentile(latencies, p)) for p in (50, 95, 99)},
        },
        "mean_stage_seconds": stages,
        "frames_per_second": extractor.steps * streams * repeats / sum(latencies),
        "new_detector_frames_per_run": extractor.last_result.diagnostics["detector_frames_inferred"]
        * streams,
        "required_frames_per_second": 105,
        "bottleneck": bottleneck,
        "gpu": gpu.report(),
        "last_extraction": result_summary(extractor.last_result),
        "notes": [
            "Cold cache means detector inference is repeated; model remains loaded.",
            "Small repeat counts provide weak tail-latency estimates.",
            "Single-worker throughput does not establish seven-stream deployment capacity.",
            "For multiple streams, stage times are worker means; total is whole-batch wall time.",
            "Reuse/overlap FPS counts assembled output frames; inspect new_detector_frames_per_run separately.",
        ],
    }


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("video", type=Path)
    p.add_argument("--models", nargs="+", default=["yolo26n.pt", "yolo26s.pt"])
    p.add_argument("--sizes", nargs="+", type=int, default=[640, 960])
    p.add_argument("--device", default="cpu")
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--half", action="store_true")
    p.add_argument("--repeats", type=int, default=5)
    p.add_argument("--warmup", type=int, default=1)
    p.add_argument("--start", type=float)
    p.add_argument("--config", type=Path, help="TOML config (default: matchpulse/config.toml)")
    p.add_argument("--cache-mode", choices=["cold", "reuse", "overlap"], default="cold")
    p.add_argument("--streams", type=int, default=1)
    p.add_argument("--opencv-threads", type=int, default=1)
    p.add_argument("--torch-threads", type=int, default=4)
    p.add_argument("--output", type=Path, default=Path("artifacts/benchmark.json"))
    args = p.parse_args(argv)
    if args.repeats < 1 or args.warmup < 0 or min(args.opencv_threads, args.torch_threads, args.streams) < 1:
        p.error("repeats and native threads must be positive; warmup non-negative")
    import cv2
    import torch

    cv2.setNumThreads(args.opencv_threads)
    torch.set_num_threads(args.torch_threads)
    report = {
        "hardware": {
            "platform": platform.platform(),
            "processor": platform.processor(),
            "cuda_available": torch.cuda.is_available(),
            "opencv_threads": cv2.getNumThreads(),
            "torch_threads": torch.get_num_threads(),
        },
        "versions": {
            n: importlib.metadata.version(n) for n in ("numpy", "av", "ultralytics", "torch", "opencv-python")
        },
        "input": str(args.video.resolve()),
        "start": args.start,
        "benchmarks": [],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    extractor_config = ExtractorConfig.from_file(args.config)
    for model in args.models:
        for size in args.sizes:
            cfg = DetectorConfig(
                weights=model, device=args.device, image_size=size, batch_size=args.batch_size, half=args.half
            )
            print(f"Benchmarking {model} at {size}px ({args.device})", flush=True)
            result = benchmark(
                args.video,
                cfg,
                repeats=args.repeats,
                warmup=args.warmup,
                start=args.start,
                cache_mode=args.cache_mode,
                streams=args.streams,
                extractor_config=extractor_config,
            )
            report["benchmarks"].append(result)
            args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
            print(
                json.dumps(
                    {
                        "weights": model,
                        "size": size,
                        "latency": result["warm_latency_seconds"],
                        "fps": result["frames_per_second"],
                        "bottleneck": result["bottleneck"],
                    }
                ),
                flush=True,
            )


if __name__ == "__main__":
    main()
