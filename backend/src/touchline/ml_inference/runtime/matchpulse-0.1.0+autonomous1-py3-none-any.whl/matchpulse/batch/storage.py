"""Transactional compressed numerical chunks, without pickle or duplicated video.

SQLite transactions are checkpoints. A chunk and its frontier commit together;
incomplete transactions cannot become complete observations. SHA256 protects all
stored numerical payloads. Connections are opened per process, never shared.
"""

import json
import os
import sqlite3
from collections import OrderedDict
from hashlib import sha256
from io import BytesIO
from pathlib import Path

import cv2
import numpy as np

from matchpulse.features.camera import CameraObservation
from matchpulse.features.detector import Detection
from matchpulse.features.observations import VisualObservation
from matchpulse.features.pitch import PitchRegion

CACHE_VERSION = "matchpulse-observations-v1"


def json_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False, default=str).encode()


def encode_array(array):
    buffer = BytesIO()
    np.savez_compressed(buffer, data=array)
    return buffer.getvalue()


def decode_array(blob):
    with np.load(BytesIO(blob), allow_pickle=False) as archive:
        return archive["data"]


def encode_observations(observations):
    rows, offsets, metadata = [], [0], []
    for o in observations:
        rejection = {d: 1 if reason == "geometry/closeup" else 2 for d, reason in o.excluded}
        for d in o.detections:
            colour = o.colours.get(d)
            rows.append(
                [
                    *d.xyxy,
                    d.confidence,
                    d.kind == "ball",
                    d in o.people,
                    d in o.balls,
                    colour is not None,
                    *(colour if colour is not None else [0.0, 0.0, 0.0]),
                    rejection.get(d, 0),
                ]
            )
        offsets.append(len(rows))
        metadata.append(
            {
                "t": o.timestamp,
                "pts": o.source_timestamp,
                "shape": o.shape,
                "pitch": [*o.region.mask.shape, o.region.confidence, o.region.coverage, o.region.scale],
                "contours": [c.reshape(-1, 2).tolist() for c in o.region.contours],
                "camera": [
                    float(o.camera.dx),
                    float(o.camera.dy),
                    bool(o.camera.cut),
                    bool(o.camera.reliable),
                    np.asarray(o.camera.affine).tolist(),
                ],
                "wide": o.wide,
            }
        )
    buffer = BytesIO()
    np.savez_compressed(
        buffer,
        detections=np.asarray(rows, dtype=np.float64).reshape(-1, 13),
        offsets=np.asarray(offsets, np.int64),
        metadata=np.frombuffer(json_bytes(metadata), np.uint8),
    )
    return buffer.getvalue()


def decode_observations(blob):
    with np.load(BytesIO(blob), allow_pickle=False) as data:
        rows, offsets = data["detections"], data["offsets"]
        metadata = json.loads(data["metadata"].tobytes())
    if rows.ndim != 2 or rows.shape[1] != 13 or len(offsets) != len(metadata) + 1 or offsets[-1] != len(rows):
        raise ValueError("Malformed observation chunk")
    if not np.isfinite(rows).all() or np.any(np.diff(offsets) < 0):
        raise ValueError("Invalid cached detections")
    result = []
    for i, record in enumerate(metadata):
        detections, people, balls, colours, excluded = [], [], [], {}, []
        for row in rows[offsets[i] : offsets[i + 1]]:
            d = Detection(tuple(row[:4]), float(row[4]), "ball" if row[5] else "person")
            detections.append(d)
            if row[6]:
                people.append(d)
                colours[d] = row[9:12].copy() if row[8] else None
            if row[7]:
                balls.append(d)
            if row[12]:
                excluded.append((d, "geometry/closeup" if row[12] == 1 else "outside pitch"))
        mh, mw, confidence, coverage, scale = record["pitch"]
        mask = np.zeros((int(mh), int(mw)), np.uint8)
        contours = [np.asarray(c, np.int32).reshape(-1, 1, 2) for c in record["contours"]]
        if contours:
            cv2.drawContours(mask, contours, -1, 255, cv2.FILLED)
        region = PitchRegion(mask, confidence, coverage, scale)
        dx, dy, cut, reliable, affine = record["camera"]
        camera = CameraObservation(dx, dy, cut, np.asarray(affine, dtype=np.float64), reliable)
        # Raw YOLO order is confidence-based. Tracker births must replay the
        # exact xyxy ordering used by VisualAnalyzer, independently of that order.
        people.sort(key=lambda d: d.xyxy)
        result.append(
            VisualObservation(
                record["t"],
                record["pts"],
                tuple(record["shape"]),
                tuple(detections),
                tuple(people),
                tuple(balls),
                colours,
                excluded,
                region,
                camera,
                record["wide"],
            )
        )
    return result


class HalfStore:
    def __init__(self, path, *, readonly=False):
        self.path = Path(path)
        self._cache = OrderedDict()
        if readonly:
            self.db = sqlite3.connect(self.path.resolve().as_uri() + "?mode=ro", uri=True)
        else:
            self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            self.db = sqlite3.connect(self.path)
            os.chmod(self.path, 0o600)
            self.db.execute("PRAGMA synchronous=FULL")
            self.db.executescript("""
                CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS chunks (start INTEGER PRIMARY KEY, count INTEGER NOT NULL,
                    checksum TEXT NOT NULL, payload BLOB NOT NULL);
                CREATE TABLE IF NOT EXISTS windows (sample_id TEXT PRIMARY KEY, start REAL, end REAL,
                    split TEXT, label INTEGER, metadata TEXT, audio BLOB, audio_hash TEXT,
                    features BLOB, feature_hash TEXT);
            """)

    def get(self, key, default=None):
        row = self.db.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
        return default if row is None else json.loads(row[0])

    def set(self, key, value):
        self.db.execute("INSERT OR REPLACE INTO metadata VALUES (?,?)", (key, json_bytes(value).decode()))

    @property
    def frontier(self):
        return self.get("committed_frames", 0)

    def append(self, start, observations, timings):
        if start != self.frontier or not observations:
            raise ValueError("Observation checkpoints must be nonempty and contiguous")
        for i, observation in enumerate(observations):
            if abs(observation.timestamp - (start + i + 0.5) / 15) > 1e-7:
                raise ValueError("Observation timestamp is not on the global 15FPS grid")
        blob = encode_observations(observations)
        with self.db:
            self.db.execute(
                "INSERT INTO chunks VALUES (?,?,?,?)",
                (start, len(observations), sha256(blob).hexdigest(), blob),
            )
            self.set("committed_frames", start + len(observations))
            accumulated = self.get("visual_timings", {})
            for key, value in timings.items():
                accumulated[key] = accumulated.get(key, 0.0) + value
            self.set("visual_timings", accumulated)

    def read(self, start, count):
        if start < 0 or count < 1 or start + count > self.frontier:
            raise ValueError("Window is outside committed observation coverage")
        rows = self.db.execute(
            "SELECT start,count,checksum,payload FROM chunks WHERE start<? AND start+count>? ORDER BY start",
            (start + count, start),
        ).fetchall()
        result = []
        for offset, size, checksum, blob in rows:
            if offset not in self._cache:
                if sha256(blob).hexdigest() != checksum:
                    raise ValueError(f"Corrupt observation chunk at {offset}")
                decoded = decode_observations(blob)
                if len(decoded) != size:
                    raise ValueError("Observation chunk length mismatch")
                self._cache[offset] = decoded
            self._cache.move_to_end(offset)
            result.extend(self._cache[offset][max(0, start - offset) : min(size, start + count - offset)])
            while len(self._cache) > 2:
                self._cache.popitem(last=False)
        if len(result) != count:
            raise ValueError("Gap in cached observation coverage")
        return result

    def validate(self):
        frontier = 0
        for start, count, checksum, blob in self.db.execute(
            "SELECT start,count,checksum,payload FROM chunks ORDER BY start"
        ):
            if start != frontier or count < 1 or sha256(blob).hexdigest() != checksum:
                raise ValueError(f"Invalid observation checkpoint at {start}")
            decoded = decode_observations(blob)
            if len(decoded) != count:
                raise ValueError("Corrupt observation count")
            if any(abs(o.timestamp - (start + i + 0.5) / 15) > 1e-7 for i, o in enumerate(decoded)):
                raise ValueError("Corrupt observation grid")
            frontier += count
        if frontier != self.frontier:
            raise ValueError("Observation frontier disagrees with committed chunks")
        for audio, audio_hash, features, feature_hash in self.db.execute(
            "SELECT audio,audio_hash,features,feature_hash FROM windows"
        ):
            if sha256(audio).hexdigest() != audio_hash or (
                features is not None and sha256(features).hexdigest() != feature_hash
            ):
                raise ValueError("Corrupt window payload")
            if not np.isfinite(decode_array(audio)).all():
                raise ValueError("Non-finite stored audio")
            if features is not None and not np.isfinite(decode_array(features)).all():
                raise ValueError("Non-finite stored features")
        return frontier

    def get_window(self, sample_id):
        row = self.db.execute(
            "SELECT metadata,audio,audio_hash,features,feature_hash FROM windows WHERE sample_id=?",
            (sample_id,),
        ).fetchone()
        if row is None:
            return None
        metadata, audio, ah, features, fh = row
        if sha256(audio).hexdigest() != ah or (features is not None and sha256(features).hexdigest() != fh):
            raise ValueError(f"Corrupt window {sample_id}")
        return (
            json.loads(metadata),
            decode_array(audio),
            decode_array(features) if features is not None else None,
        )

    def put_window(self, sample, audio, features=None):
        sound = encode_array(audio)
        feature_blob = encode_array(features) if features is not None else None
        with self.db:
            self.db.execute(
                "INSERT OR REPLACE INTO windows VALUES (?,?,?,?,?,?,?,?,?,?)",
                (
                    sample.sample_id,
                    sample.start,
                    sample.end,
                    sample.split,
                    sample.label,
                    json_bytes(sample.metadata).decode(),
                    sound,
                    sha256(sound).hexdigest(),
                    feature_blob,
                    sha256(feature_blob).hexdigest() if feature_blob is not None else None,
                ),
            )

    def close(self):
        self.db.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as handle:
        handle.write(json_bytes(value))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
