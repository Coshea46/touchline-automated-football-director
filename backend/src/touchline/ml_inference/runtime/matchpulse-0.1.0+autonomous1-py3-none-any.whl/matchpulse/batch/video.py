"""Bounded sequential PTS sampler; no per-window seek or repeated RGB conversion."""

from pathlib import Path

import av


def probe_video(path):
    with av.open(str(path)) as container:
        if not container.streams.video:
            raise ValueError(f"No video stream: {path}")
        stream = container.streams.video[0]
        origin = float((stream.start_time or 0) * stream.time_base)
        duration = (
            float(stream.duration * stream.time_base)
            if stream.duration is not None
            else float(container.duration / av.time_base)
            if container.duration
            else None
        )
        if duration is None or duration <= 0 or min(stream.width, stream.height) < 16:
            raise ValueError(f"Cannot establish valid video duration/dimensions: {path}")
        return {
            "duration": duration,
            "origin": origin,
            "width": stream.width,
            "height": stream.height,
            "audio": bool(container.streams.audio),
        }


def iter_sampled_frames(path, first, stop):
    """Yield (global index, centre timestamp, source PTS, RGB), [first, stop)."""
    if not 0 <= first <= stop:
        raise ValueError("Invalid sample bounds")
    if first == stop:
        return
    try:
        with av.open(str(Path(path))) as container:
            stream = container.streams.video[0]
            origin = float((stream.start_time or 0) * stream.time_base)
            if first:
                seek = max(0.0, (first + 0.5) / 15 - 0.25) + origin
                container.seek(int(seek / stream.time_base), stream=stream, backward=True)
            index, previous, shape, last_pts, display_duration = first, None, None, None, None
            for frame in container.decode(stream):
                if frame.pts is None or frame.is_corrupt:
                    raise ValueError("Missing PTS / corrupt source frame")
                pts = float(frame.pts * stream.time_base) - origin
                if last_pts is not None and pts <= last_pts:
                    raise ValueError("Non-monotonic source PTS")
                while index < stop and (index + 0.5) / 15 < pts - 1e-8:
                    target = (index + 0.5) / 15
                    if previous is None or target - previous[0] > 0.21:
                        raise ValueError(f"Incomplete video near {target:.3f}s")
                    if isinstance(previous[1], av.VideoFrame):
                        previous = previous[0], previous[1].to_ndarray(format="rgb24")
                    yield index, target, previous[0], previous[1]
                    index += 1
                if index == stop:
                    return
                current_shape = (frame.height, frame.width)
                if min(current_shape) < 16 or (shape is not None and shape != current_shape):
                    raise ValueError("Invalid / changing frame dimensions")
                shape, previous, last_pts = current_shape, (pts, frame), pts
                display_duration = float(frame.duration * stream.time_base) if frame.duration else 0
            while index < stop:
                target = (index + 0.5) / 15
                if (
                    previous is None
                    or target - previous[0] > 0.21
                    or previous[0] + display_duration < target - 0.01
                ):
                    raise ValueError("Video ends before declared observation coverage")
                if isinstance(previous[1], av.VideoFrame):
                    previous = previous[0], previous[1].to_ndarray(format="rgb24")
                yield index, target, previous[0], previous[1]
                index += 1
    except av.error.FFmpegError as exc:
        raise ValueError(f"Cannot decode {path}: {exc}") from exc
