"""Kaggle dataset validation, resumable CUDA extraction, benchmarking and private debug."""

import argparse
import json
from dataclasses import replace
from pathlib import Path

import numpy as np

from matchpulse.features import DetectorConfig, ExtractorConfig, MatchFeatureExtractor
from matchpulse.features.debug import write_debug_video
from matchpulse.features.video import from_file

from .dataset import FeatureDataset
from .pipeline import BatchConfig, gpu_environment, plan_dataset, run_pipeline
from .storage import atomic_json


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    for name in ("validate", "run", "benchmark", "smoke"):
        command = sub.add_parser(name)
        command.add_argument("--video-root", type=Path, required=True)
        command.add_argument("--manifest", type=Path, nargs="+", required=True)
        command.add_argument("--output", type=Path, required=True)
        command.add_argument("--config", type=Path)
        command.add_argument("--weights", default="yolo26s.pt")
        command.add_argument("--device", default="cuda:0")
        command.add_argument("--image-size", type=int, default=640)
        command.add_argument("--batch-size", type=int, default=32)
        command.add_argument("--fp32", action="store_true")
        command.add_argument("--materialize", action="store_true")
        command.add_argument("--checkpoint-frames", type=int, default=150)
        command.add_argument("--max-halves", type=int)
        command.add_argument(
            "--time-budget-seconds", type=float, help="Gracefully checkpoint before a session deadline"
        )
        command.add_argument(
            "--max-seconds", type=float, help="Explicit short-run bound; not a full-half benchmark"
        )
        if name == "benchmark":
            command.add_argument(
                "--models", type=Path, nargs="+", default=[Path("yolo26s.pt"), Path("yolo26n.pt")]
            )
    debug = sub.add_parser("debug")
    debug.add_argument("--dataset", type=Path, required=True)
    debug.add_argument("--video-root", type=Path, required=True)
    debug.add_argument("--split", choices=["train", "valid", "test"], default="train")
    debug.add_argument("--index", type=int, default=0)
    debug.add_argument("--output", type=Path, required=True)
    export = sub.add_parser("export")
    export.add_argument("--dataset", type=Path, required=True)
    export.add_argument("--split", choices=["train", "valid", "test"], required=True)
    export.add_argument("--output", type=Path, required=True)
    export.add_argument("--shard-size", type=int, default=128)
    return p


def export_shards(root, split, output, shard_size=128):
    if shard_size < 1:
        raise ValueError("shard-size must be positive")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    with FeatureDataset(root, split) as dataset:
        for first in range(0, len(dataset), shard_size):
            data = [dataset[i] for i in range(first, min(len(dataset), first + shard_size))]
            destination = output / f"{split}-{first:08d}.npz"
            temporary = destination.with_suffix(".npz.tmp")
            with temporary.open("wb") as handle:
                np.savez_compressed(
                    handle,
                    features=np.stack([r[0] for r in data]),
                    labels=np.array([r[1] for r in data], dtype=np.int64),
                    sample_ids=np.array([r[2] for r in data], dtype=str),
                )
            temporary.replace(destination)
    atomic_json(
        output / f"{split}-index.json", {"samples": len(dataset), "shard_size": shard_size, "split": split}
    )


def main(argv=None):
    args = parser().parse_args(argv)
    if args.command == "export":
        export_shards(args.dataset, args.split, args.output, args.shard_size)
        return 0
    if args.command == "debug":
        from .manifest import discover_videos

        with FeatureDataset(args.dataset, args.split) as dataset:
            features, _, _ = dataset[args.index]
            row = dataset.rows[args.index]
            source = discover_videos(args.video_root)[f"{row['match_id']}/{row['half']}_720p.mkv"]
            store = dataset._stores[str((dataset.root / row["cache_path"]).resolve())]
            config = ExtractorConfig(**store.get("extractor_config"))
            extractor = MatchFeatureExtractor(config=config, detector=dataset_detector())
            cached = store.get_window(row["sample_id"])
            extractor.assemble_observations(store.read(row["offset"], row["steps"]), audio=cached[1])
            window = from_file(
                source, start=row["observation_start_seconds"], duration_seconds=config.clip_duration_seconds
            )
            write_debug_video(args.output, window.frames, features, extractor.last_result.diagnostics)
        return 0
    config = ExtractorConfig.from_file(args.config)
    if config.clip_duration_seconds != 5:
        raise ValueError("This training job requires clip_duration_seconds=5.0 (75,215)")
    if args.command == "validate":
        _, groups, probes, plan = plan_dataset(args.video_root, args.manifest, config)
        atomic_json(
            args.output / "dataset-plan.json",
            {
                **plan,
                "halves": list(groups),
                "probes": probes,
                "environment": gpu_environment(require_cuda=False, device="cpu"),
            },
        )
        print(json.dumps(plan, indent=2))
        return 0
    if args.command == "smoke":
        if args.max_seconds is None:
            args.max_seconds = 10.0
        args.max_halves = 1
        args.device, args.fp32 = "cpu", True
    batch = BatchConfig(
        args.checkpoint_frames, args.materialize, args.max_seconds, args.max_halves, args.time_budget_seconds
    )
    dc = DetectorConfig(
        weights=args.weights,
        device=args.device,
        image_size=args.image_size,
        batch_size=args.batch_size,
        half=not args.fp32,
    )
    import cv2

    cv2.setNumThreads(1)
    if args.command == "benchmark":
        gpu_environment(device=args.device)
        results, missing = [], []
        for model in args.models:
            if not model.is_file():
                missing.append(str(model))
                print(f"Benchmark skipped unavailable weights: {model}", flush=True)
                continue
            run_output = args.output / f"{model.stem}-{args.image_size}-b{args.batch_size}"
            report = run_pipeline(
                args.video_root,
                args.manifest,
                run_output,
                detector_config=replace(dc, weights=str(model)),
                extractor_config=config,
                batch_config=batch,
            )
            results.append(report)
        atomic_json(args.output / "benchmark-summary.json", {"runs": results, "unavailable_weights": missing})
        return (
            0
            if results and all(all(h["status"] != "failed" for h in r["halves"].values()) for r in results)
            else 2
        )
    report = run_pipeline(
        args.video_root,
        args.manifest,
        args.output,
        detector_config=dc,
        extractor_config=config,
        batch_config=batch,
        require_cuda=args.command != "smoke",
    )
    print(json.dumps({k: report[k] for k in ("seconds", "supervised_windows", "unprocessed")}, indent=2))
    return 2 if any(h["status"] == "failed" for h in report["halves"].values()) else 0


def dataset_detector():
    from .pipeline import CachedOnlyDetector

    return CachedOnlyDetector()


if __name__ == "__main__":
    raise SystemExit(main())
