"""Map-style NumPy/PyTorch-compatible dataset; no inference or source video required."""

import os
from collections import OrderedDict
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq

from matchpulse.features import ExtractorConfig, MatchFeatureExtractor
from matchpulse.features.schema import SCHEMA_VERSION, validate

from .manifest import SPLITS
from .pipeline import CachedOnlyDetector, window_fingerprint
from .storage import HalfStore


class FeatureDataset:
    """Returns (float32 [T,215], int64 label, sample_id).

    torch.utils.data.DataLoader collates the NumPy arrays automatically. SQLite
    handles are reopened per worker PID; cache at most two halves and two chunks
    per half. No live model is held by this dataset. materialized stores avoid
    repeating CPU tracking each epoch; otherwise identical features are assembled
    lazily from the unique-frame observations.
    """

    def __init__(self, root, split="train"):
        if split not in ("train", "valid", "test"):
            raise ValueError("Choose train, valid or test explicitly")
        self.root = Path(root).resolve()
        self.rows = pq.read_table(self.root / "windows" / f"{split}.parquet").to_pylist()
        self._stores, self._extractors = OrderedDict(), {}
        self._pid = os.getpid()

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        if self._pid != os.getpid():
            self.close()
            self._pid = os.getpid()
        row = self.rows[index]
        if row["schema_version"] != SCHEMA_VERSION or row["label"] not in (0, 1):
            raise ValueError("Unsupported schema or supervised label")
        path = (self.root / row["cache_path"]).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("Cache path escapes dataset root")
        if str(path) not in self._stores:
            self._stores[str(path)] = HalfStore(path, readonly=True)
        store = self._stores[str(path)]
        self._stores.move_to_end(str(path))
        while len(self._stores) > 2:
            _, old = self._stores.popitem(last=False)
            old.close()
        window = store.get_window(row["sample_id"])
        if window is None:
            raise ValueError("Index points to an uncommitted window")
        metadata, sound, features = window
        if (
            str(metadata["match_id"]).replace("\\", "/").strip("/") != row["match_id"]
            or metadata["half"] != row["half"]
            or metadata["label"] != row["label"]
            or SPLITS.get(str(metadata["split"]).lower()) != row["split"]
            or metadata["observation_start_seconds"] != row["observation_start_seconds"]
            or metadata["observation_end_seconds"] != row["observation_end_seconds"]
        ):
            raise ValueError("Index/cache window identity, split or label mismatch")
        if not store.get("completed"):
            raise ValueError("Half has not completed validation")
        if features is None:
            config = ExtractorConfig(**store.get("extractor_config"))
            if metadata.get("feature_config_sha256") != window_fingerprint(config):
                raise ValueError(
                    "Lazy assembly code/config differs from the cached dataset; use its recorded code version"
                )
            if config not in self._extractors:
                self._extractors[config] = MatchFeatureExtractor(detector=CachedOnlyDetector(), config=config)
            features = self._extractors[config].assemble_observations(
                store.read(row["offset"], row["steps"]), audio=sound
            )
        validate(features, steps=row["steps"])
        return features, np.int64(row["label"]), row["sample_id"]

    def metadata(self, index):
        self[index]
        row = self.rows[index]
        store = self._stores[str((self.root / row["cache_path"]).resolve())]
        return store.get_window(row["sample_id"])[0]

    def close(self):
        for store in self._stores.values():
            store.close()
        self._stores.clear()
        self._extractors.clear()

    def __getstate__(self):
        state = dict(self.__dict__)
        state.update(_stores=OrderedDict(), _extractors={}, _pid=None)
        return state

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
