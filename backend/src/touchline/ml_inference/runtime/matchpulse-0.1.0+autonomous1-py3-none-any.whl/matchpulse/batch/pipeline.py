"""Sequential per-half inference followed by exact window-local feature assembly."""

import importlib.metadata
import math
import os
import time
from collections import defaultdict
from dataclasses import asdict, dataclass, replace
from hashlib import sha256
from itertools import islice
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq

from matchpulse.features import DetectorConfig, ExtractorConfig, MatchFeatureExtractor, YoloDetector
from matchpulse.features.audio import audio_features
from matchpulse.features.observations import VisualAnalyzer
from matchpulse.features.schema import FEATURE_NAMES, SCHEMA_VERSION, validate
from matchpulse.features.video import decode_audio

from .manifest import discover_videos, load_manifest
from .storage import CACHE_VERSION, HalfStore, atomic_json, json_bytes
from .video import iter_sampled_frames, probe_video


@dataclass(frozen=True)
class BatchConfig:
    checkpoint_frames: int = 150
    materialize: bool = False
    max_seconds: float | None = None  # explicit smoke/benchmark bound, never automatic
    max_halves: int | None = None
    time_budget_seconds: float | None = None

    def __post_init__(self):
        if self.checkpoint_frames < 1 or (self.max_halves is not None and self.max_halves < 1):
            raise ValueError("Checkpoint size and half limit must be positive")
        if self.max_seconds is not None and (not math.isfinite(self.max_seconds) or self.max_seconds < 5):
            raise ValueError("Explicit smoke limit must be finite and >=5 seconds")
        if self.time_budget_seconds is not None and (
            not math.isfinite(self.time_budget_seconds) or self.time_budget_seconds <= 0
        ):
            raise ValueError("Session time budget must be positive and finite")


class CheckpointReached(Exception):
    """Graceful session deadline; committed data remains usable on resume."""


def gpu_environment(*, require_cuda=True, device="cuda:0"):
    import torch

    available = torch.cuda.is_available()
    if require_cuda and (not available or device == "cpu"):
        raise RuntimeError(
            "CUDA GPU required. Enable a Kaggle GPU accelerator; full-dataset CPU fallback is disabled."
        )
    if available and device != "cpu":
        index = int(device.split(":")[-1]) if ":" in device else int(device) if device.isdigit() else 0
        torch.cuda.set_device(index)
        name = torch.cuda.get_device_name(index)
    else:
        name = None
    return {
        "cuda_available": available,
        "gpu": name,
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "device": device,
        "versions": {
            n: importlib.metadata.version(n)
            for n in ("numpy", "av", "ultralytics", "opencv-python", "pyarrow")
        },
    }


def file_hash(path):
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def observation_fingerprint(detector_config, extractor_config):
    # Duration and window tracking settings do not change raw visual observations.
    root = Path(__file__).parents[1] / "features"
    code = {
        name: file_hash(root / name)
        for name in ("observations.py", "pitch.py", "camera.py", "teams.py", "detector.py")
    }
    weights = Path(detector_config.weights)
    detector_settings = asdict(detector_config)
    detector_settings["weights"] = weights.name
    return {
        "cache_version": CACHE_VERSION,
        "schema": SCHEMA_VERSION,
        "fps": 15,
        "detector": detector_settings,
        "weights_sha256": file_hash(weights) if weights.is_file() else None,
        "visual_config": {
            "analysis_width": extractor_config.analysis_width,
            "touchline_tolerance": extractor_config.touchline_tolerance,
        },
        "code": code,
    }


def window_fingerprint(config):
    root = Path(__file__).parents[1] / "features"
    return sha256(
        json_bytes(
            {
                "config": asdict(config),
                "schema": SCHEMA_VERSION,
                "code": {p.name: file_hash(p) for p in sorted(root.glob("*.py"))},
                "cache_assembly_code": {
                    name: file_hash(Path(__file__).parent / name) for name in ("storage.py", "pipeline.py")
                },
            }
        )
    ).hexdigest()


def plan_dataset(video_root, manifests, config):
    if abs(config.clip_duration_seconds * 15 - round(config.clip_duration_seconds * 15)) > 1e-7:
        raise ValueError(
            "Batch window duration must contain whole 15FPS intervals to reuse the global sample grid"
        )
    videos = discover_videos(video_root)
    samples, summary = load_manifest(manifests, videos, duration=config.clip_duration_seconds)
    grouped = defaultdict(list)
    probes = {}
    for sample in samples:
        if sample.half_key not in probes:
            probes[sample.half_key] = probe_video(videos[sample.half_key])
        if sample.end > probes[sample.half_key]["duration"] + 1e-6:
            raise ValueError(f"{sample.sample_id}: endpoint {sample.end} exceeds video duration")
        grouped[sample.half_key].append(sample)
    return (
        videos,
        dict(grouped),
        probes,
        {**summary, "discovered_halves": len(videos), "unused_videos": sorted(set(videos) - set(grouped))},
    )


def cache_visuals(
    path, store, detector, detector_config, config, probe, total_frames, checkpoint_frames, deadline=None
):
    first = store.frontier
    if first >= total_frames:
        return {
            "sampled_frames": 0,
            "inferred_frames": 0,
            "cached_frames": first,
            "decode": 0.0,
            "detector": 0.0,
            "pitch_team": 0.0,
            "camera": 0.0,
        }
    analyzer = VisualAnalyzer(config)
    start = max(0, first - 1)
    frames = iter(iter_sampled_frames(path, start, total_frames))
    last_pts, last_raw = None, None
    chunk, chunk_start = [], first
    timings = dict.fromkeys(
        ("decode", "detector", "pitch_team", "camera", "sampled_frames", "inferred_frames"), 0.0
    )
    report = dict(timings)
    report["cached_frames"] = first
    if first:
        # One decoded seed frame restores camera context; its detections are reused.
        _, target, pts, rgb = next(frames)
        previous = store.read(first - 1, 1)[0]
        analyzer.analyze(rgb, previous.detections, target, pts, timings)
        last_pts, last_raw = pts, previous.detections
    while True:
        if deadline is not None and time.perf_counter() >= deadline:
            if chunk:
                store.append(chunk_start, chunk, timings)
            raise CheckpointReached("Session deadline reached during visual extraction")
        before = time.perf_counter()
        batch = list(islice(frames, detector_config.batch_size))
        timings["decode"] += time.perf_counter() - before
        if not batch:
            break
        unique = {}
        for _, _, pts, rgb in batch:
            if pts != last_pts:
                unique.setdefault(pts, rgb)
        before = time.perf_counter()
        predictions = detector.detect(list(unique.values())) if unique else []
        if len(predictions) != len(unique):
            raise RuntimeError("Detector returned incorrect batch count")
        timings["detector"] += time.perf_counter() - before
        raw_by_pts = dict(zip(unique, predictions, strict=True))
        if last_pts is not None:
            raw_by_pts[last_pts] = last_raw
        timings["inferred_frames"] += len(unique)
        for _, target, pts, rgb in batch:
            raw = tuple(raw_by_pts[pts])
            chunk.append(analyzer.analyze(rgb, raw, target, pts, timings))
            last_pts, last_raw = pts, raw
        timings["sampled_frames"] += len(batch)
        if len(chunk) >= checkpoint_frames:
            store.append(chunk_start, chunk, timings)
            for key, value in timings.items():
                report[key] += value
            chunk_start += len(chunk)
            chunk, timings = [], dict.fromkeys(timings, 0.0)
    if chunk:
        store.append(chunk_start, chunk, timings)
        for key, value in timings.items():
            report[key] += value
    with store.db:
        store.set("visual_complete_frames", total_frames)
    return report


def assemble_half(path, store, samples, config, *, materialize=False, deadline=None):
    # No model is loaded for assembly; assemble_observations never calls a detector.
    extractor = MatchFeatureExtractor(config=config, detector=CachedOnlyDetector())
    signature = window_fingerprint(config)
    previous_signature = store.get("window_fingerprint")
    report = dict.fromkeys(
        (
            "audio",
            "tracking",
            "pitch_team",
            "camera",
            "interpolation",
            "assembly",
            "windows",
            "reused_windows",
        ),
        0.0,
    )
    for sample in samples:
        if deadline is not None and time.perf_counter() >= deadline:
            raise CheckpointReached("Session deadline reached during window assembly")
        cached = store.get_window(sample.sample_id)
        sound = features = None
        if cached:
            metadata, sound, features = cached
            if (
                metadata["observation_start_seconds"] != sample.start
                or metadata["observation_end_seconds"] != sample.end
                or str(metadata["match_id"]).replace("\\", "/") != sample.match_id
                or metadata["half"] != sample.half
            ):
                raise ValueError(f"Sample ID changed its video/timestamp identity: {sample.sample_id}")
            if sound.shape != (extractor.steps, 5):
                raise ValueError("Cached audio duration disagrees with window")
            if metadata.get("feature_config_sha256") == signature and (
                not materialize or features is not None
            ):
                if features is not None:
                    validate(features, steps=extractor.steps)
                # Annotation changes update metadata, without feeding them to extraction.
                metadata = {
                    **sample.metadata,
                    "feature_track_slots": metadata.get("feature_track_slots", []),
                    "feature_config_sha256": signature,
                }
                store.put_window(replace(sample, metadata=metadata), sound, features)
                report["reused_windows"] += 1
                continue
        if sound is None or previous_signature != signature:
            before = time.perf_counter()
            probe = store.get("probe")
            waveform, rate = (
                decode_audio(path, sample.start, sample.end, probe["origin"])
                if probe["audio"]
                else (None, None)
            )
            sound = audio_features(
                waveform, rate, allow_gaps=True, duration_seconds=config.clip_duration_seconds
            )
            report["audio"] += time.perf_counter() - before
        observations = store.read(sample.offset, extractor.steps)
        features = extractor.assemble_observations(observations, audio=sound)
        for key, value in extractor.last_result.timings.items():
            report[key] += value
        tracks = [
            {"segment": t.key[0], "track_id": t.key[1], "slot": t.slot, "team": t.team}
            for t in extractor.last_result.diagnostics["tracks"].values()
        ]
        metadata = {**sample.metadata, "feature_track_slots": tracks, "feature_config_sha256": signature}
        store.put_window(replace(sample, metadata=metadata), sound, features if materialize else None)
        report["windows"] += 1
    with store.db:
        store.set("window_fingerprint", signature)
        store.set("extractor_config", asdict(config))
        store.set("last_completed_samples", [s.sample_id for s in samples])
    return report


class CachedOnlyDetector:
    def detect(self, frames):
        raise RuntimeError("Detector inference is forbidden during cached window assembly")


def write_indices(output, rows):
    schema = pa.schema(
        [
            ("sample_id", pa.string()),
            ("window_id", pa.string()),
            ("match_id", pa.string()),
            ("half", pa.int8()),
            ("split", pa.string()),
            ("label", pa.int8()),
            ("observation_start_seconds", pa.float64()),
            ("observation_end_seconds", pa.float64()),
            ("offset", pa.int64()),
            ("steps", pa.int32()),
            ("cache_path", pa.string()),
            ("schema_version", pa.string()),
            ("materialized", pa.bool_()),
        ]
    )
    directory = Path(output) / "windows"
    directory.mkdir(parents=True, exist_ok=True)
    for split in ("train", "valid", "test"):
        table = pa.Table.from_pylist([r for r in rows if r["split"] == split], schema=schema)
        temporary = directory / f"{split}.parquet.tmp"
        pq.write_table(table, temporary, compression="zstd")
        os.replace(temporary, directory / f"{split}.parquet")


def run_pipeline(
    video_root,
    manifests,
    output,
    *,
    detector_config=None,
    extractor_config=None,
    batch_config=None,
    detector=None,
    require_cuda=True,
):
    config = extractor_config or ExtractorConfig.from_file()
    batch_config = batch_config or BatchConfig()
    dc = detector_config or DetectorConfig(device="cuda:0", half=True, batch_size=32)
    # Fail before a full-dataset CPU fallback or a model download.
    environment = gpu_environment(require_cuda=require_cuda, device=dc.device)
    videos, groups, probes, plan = plan_dataset(video_root, manifests, config)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True, mode=0o700)
    atomic_json(
        output / "schema.json",
        {
            "version": SCHEMA_VERSION,
            "feature_names": FEATURE_NAMES,
            "fps": 15,
            "duration_seconds": config.clip_duration_seconds,
            "features_per_frame": 215,
        },
    )
    selected = sorted(groups)[: batch_config.max_halves]
    deferred = sorted(set(groups) - set(selected))
    model_started = time.perf_counter()
    detector = detector if detector is not None else YoloDetector(dc)
    model_load_seconds = time.perf_counter() - model_started
    visual_signature = observation_fingerprint(dc, config)
    statuses, rows = {}, []
    before_run = time.perf_counter()
    deadline = (
        before_run + batch_config.time_budget_seconds
        if batch_config.time_budget_seconds is not None
        else None
    )
    import psutil

    from matchpulse.benchmark import GpuSampler

    process = psutil.Process()
    cpu_start = sum(process.cpu_times()[:2])
    with GpuSampler() as gpu:
        for position, key in enumerate(selected):
            if deadline is not None and time.perf_counter() >= deadline:
                deferred.extend(selected[position:])
                break
            before_half = time.perf_counter()
            relative = f"halves/{sha256(key.encode()).hexdigest()[:24]}.sqlite"
            path, probe = videos[key], probes[key]
            limit = (
                min(probe["duration"], batch_config.max_seconds)
                if batch_config.max_seconds
                else probe["duration"]
            )
            total_frames = math.floor(limit * 15 + 1e-7)
            samples = [s for s in groups[key] if s.end <= total_frames / 15 + 1e-7]
            statuses[key] = {"status": "processing", "cache_path": relative}
            atomic_json(output / "status.json", {"halves": statuses, "deferred": deferred, "plan": plan})
            try:
                validation_started = time.perf_counter()
                source_sha = file_hash(path)
                source_validation_seconds = time.perf_counter() - validation_started
                with HalfStore(output / relative) as store:
                    identity = {
                        "half_key": key,
                        "source_sha256": source_sha,
                        "observations": visual_signature,
                    }
                    if store.get("identity") not in (None, identity):
                        raise ValueError(
                            "Cache source/model/visual configuration changed; use a separate output directory"
                        )
                    with store.db:
                        store.set("identity", identity)
                        store.set("probe", probe)
                        store.set("environment", environment)
                    store.validate()
                    visual = cache_visuals(
                        path,
                        store,
                        detector,
                        dc,
                        config,
                        probe,
                        total_frames,
                        batch_config.checkpoint_frames,
                        deadline=deadline,
                    )
                    windows = assemble_half(
                        path, store, samples, config, materialize=batch_config.materialize, deadline=deadline
                    )
                    with store.db:
                        store.set(
                            "completed",
                            {
                                "frames": store.frontier,
                                "samples": [s.sample_id for s in samples],
                                "full_half": batch_config.max_seconds is None or limit == probe["duration"],
                            },
                        )
                    for sample in samples:
                        rows.append(
                            {
                                "sample_id": sample.sample_id,
                                "window_id": sample.sample_id,
                                "match_id": sample.match_id,
                                "half": sample.half,
                                "split": sample.split,
                                "label": sample.label,
                                "observation_start_seconds": sample.start,
                                "observation_end_seconds": sample.end,
                                "offset": sample.offset,
                                "steps": round(config.clip_duration_seconds * 15),
                                "cache_path": relative,
                                "schema_version": SCHEMA_VERSION,
                                "materialized": batch_config.materialize,
                            }
                        )
                    elapsed = time.perf_counter() - before_half
                    statuses[key] = {
                        "status": "complete",
                        "reused_complete_half": visual["sampled_frames"] == 0 and windows["windows"] == 0,
                        "cache_path": relative,
                        "full_half": limit == probe["duration"],
                        "source_frames": total_frames,
                        "visual": visual,
                        "windows": windows,
                        "seconds": elapsed,
                        "source_validation_seconds": source_validation_seconds,
                        "detector_fps": visual["inferred_frames"] / visual["detector"]
                        if visual["detector"]
                        else None,
                        "end_to_end_fps": visual["sampled_frames"] / elapsed,
                        "cache_bytes": (output / relative).stat().st_size,
                    }
            except CheckpointReached as exc:
                with HalfStore(output / relative, readonly=True) as checkpoint:
                    committed_frames = checkpoint.frontier
                statuses[key] = {
                    "status": "checkpointed",
                    "cache_path": relative,
                    "committed_frames": committed_frames,
                    "reason": str(exc),
                }
                deferred.extend(selected[position + 1 :])
            except Exception as exc:
                statuses[key] = {
                    "status": "failed",
                    "cache_path": relative,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            write_indices(output, rows)
            atomic_json(output / "status.json", {"halves": statuses, "deferred": deferred, "plan": plan})
            print(f"{statuses[key]['status']}: {key}", flush=True)
            if statuses[key]["status"] == "checkpointed":
                break
    elapsed = time.perf_counter() - before_run
    write_indices(output, rows)
    atomic_json(output / "status.json", {"halves": statuses, "deferred": deferred, "plan": plan})
    report = {
        "environment": environment,
        "detector": asdict(dc),
        "extractor": asdict(config),
        "batch": asdict(batch_config),
        "schema_version": SCHEMA_VERSION,
        "plan": plan,
        "halves": statuses,
        "deferred": deferred,
        "seconds": elapsed,
        "model_load_seconds": model_load_seconds,
        "gpu": gpu.report(),
        "cpu_percent_one_core_basis": 100 * (sum(process.cpu_times()[:2]) - cpu_start) / max(elapsed, 1e-9),
        "unprocessed": deferred
        + [k for k, v in statuses.items() if v["status"] != "complete" or not v.get("full_half", False)],
        "partial_halves": [
            k for k, v in statuses.items() if v["status"] == "complete" and not v.get("full_half", False)
        ],
        "supervised_windows": len(rows),
    }
    import torch

    report["torch_gpu_peak_allocated_bytes"] = (
        torch.cuda.max_memory_allocated() if dc.device != "cpu" and torch.cuda.is_available() else None
    )
    atomic_json(output / "run-report.json", report)
    return report
