"""Private, resumable SoccerNet observation datasets; no GRU or label generation."""

from .manifest import discover_videos, load_manifest

__all__ = ["discover_videos", "load_manifest"]
