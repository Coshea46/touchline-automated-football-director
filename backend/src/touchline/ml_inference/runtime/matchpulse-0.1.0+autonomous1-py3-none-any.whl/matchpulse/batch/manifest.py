"""Read the labelling pipeline's Parquet contract and relocate Windows paths by match ID."""

import math
import re
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

import pyarrow.parquet as pq

SPLITS = {"train": "train", "valid": "valid", "val": "valid", "validation": "valid", "test": "test"}
REQUIRED = {"match_id", "half", "split", "label", "observation_start_seconds", "observation_end_seconds"}


@dataclass(frozen=True)
class Sample:
    sample_id: str
    match_id: str
    half: int
    split: str
    label: int
    start: float
    end: float
    metadata: dict

    @property
    def half_key(self):
        return f"{self.match_id}/{self.half}_720p.mkv"

    @property
    def offset(self):
        return round(self.start * 15)


def discover_videos(root):
    root = Path(root).resolve(strict=True)
    videos = {}
    for path in sorted(root.rglob("*")):
        match = re.fullmatch(r"([12])_720p\.mkv", path.name, flags=re.IGNORECASE)
        if not path.is_file() or match is None:
            continue
        resolved = path.resolve()
        if not resolved.is_relative_to(root):
            raise ValueError(f"Video escapes the authorised input root: {path}")
        relative = path.relative_to(root)
        if len(relative.parts) < 4:
            raise ValueError(f"Expected <league>/<season>/<match>/<half>_720p.mkv: {path}")
        key = PurePosixPath(*relative.parts[-4:-1], f"{match[1]}_720p.mkv").as_posix()
        if key in videos:
            raise ValueError(f"Ambiguous duplicate match half: {key}")
        videos[key] = resolved
    if not videos:
        raise ValueError(f"No SoccerNet *_720p.mkv match halves under {root}")
    return videos


def load_manifest(paths, videos, *, duration=5.0):
    """Ignore event tables in a manifest directory; never pass annotations to visual inference."""
    if isinstance(paths, (str, Path)):
        paths = [paths]
    files = []
    for path in map(Path, paths):
        candidates = sorted(path.rglob("*.parquet")) if path.is_dir() else [path]
        for candidate in candidates:
            columns = set(pq.read_schema(candidate).names)
            if REQUIRED <= columns:
                files.append(candidate)
            elif not path.is_dir():
                raise ValueError(f"{candidate}: missing manifest columns {sorted(REQUIRED - columns)}")
    if not files:
        raise ValueError("No window Parquet manifests found")
    samples, ids, assignments = [], set(), {}
    ignored = 0
    for file in sorted(set(files)):
        table = pq.ParquetFile(file)
        for batch in table.iter_batches(batch_size=8192):
            for row in batch.to_pylist():
                raw_id = row.get("window_id", row.get("sample_id"))
                if raw_id is None or not str(raw_id).strip():
                    raise ValueError(f"{file}: nonempty window_id or sample_id required")
                sample_id = str(raw_id)
                if sample_id in ids:
                    raise ValueError(f"Duplicate sample ID {sample_id}")
                ids.add(sample_id)
                match_id = str(row["match_id"]).replace("\\", "/").strip("/")
                if len(PurePosixPath(match_id).parts) != 3 or ".." in PurePosixPath(match_id).parts:
                    raise ValueError(f"Invalid match_id {match_id}")
                if row["half"] not in (1, 2):
                    raise ValueError(f"{sample_id}: half must be 1 or 2")
                split = SPLITS.get(str(row["split"]).lower())
                if split is None:
                    raise ValueError(f"{sample_id}: unknown split {row['split']}")
                if match_id in assignments and assignments[match_id] != split:
                    raise ValueError(f"Match-level split leakage: {match_id}")
                assignments[match_id] = split
                start, end = float(row["observation_start_seconds"]), float(row["observation_end_seconds"])
                if (
                    not all(math.isfinite(v) for v in (start, end))
                    or start < 0
                    or abs(end - start - duration) > 1e-7
                ):
                    raise ValueError(f"{sample_id}: observation must span {duration:g} seconds")
                if abs(start * 15 - round(start * 15)) > 1e-6:
                    raise ValueError(f"{sample_id}: observation start must align to the 15FPS global grid")
                label = row["label"]
                if label is None or label in (-1, "ignore", "ignored"):
                    ignored += 1
                    continue
                if label not in (0, 1):
                    raise ValueError(f"{sample_id}: label must be 0, 1 or ignore")
                sample = Sample(sample_id, match_id, int(row["half"]), split, int(label), start, end, row)
                if sample.half_key not in videos:
                    raise ValueError(f"{sample_id}: missing video {sample.half_key}")
                samples.append(sample)
    if not samples:
        raise ValueError("No eligible supervised windows")
    return sorted(samples, key=lambda s: (s.half_key, s.start, s.sample_id)), {
        "files": [str(p) for p in sorted(set(files))],
        "eligible": len(samples),
        "ignored": ignored,
        "matches": len(assignments),
        "halves": len({s.half_key for s in samples}),
    }
