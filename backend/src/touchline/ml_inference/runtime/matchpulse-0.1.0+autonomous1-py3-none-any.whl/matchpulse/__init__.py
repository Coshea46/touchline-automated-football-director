"""MatchPulse football feature extraction and optional Stage 1 classification."""

from .features import MatchFeatureExtractor, extract_match_features


def load_interest_classifier(path, *, device="cpu"):
    """Load a trained Stage 1 classifier without requiring Torch for feature-only imports."""
    from .interest.checkpoint import load_interest_classifier as load

    return load(path, device=device)


__all__ = ["MatchFeatureExtractor", "extract_match_features", "load_interest_classifier"]
