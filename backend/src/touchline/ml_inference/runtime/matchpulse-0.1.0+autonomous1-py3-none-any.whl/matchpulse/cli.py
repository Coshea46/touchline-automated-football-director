"""Inspect feature names, detection validity, shot-local identities and timings."""

import argparse
import json
from pathlib import Path

import numpy as np

from .features import DetectorConfig, ExtractorConfig, MatchFeatureExtractor
from .features.schema import (
    BALL,
    CAMERA,
    FEATURE_NAMES,
    PLAYER_WIDTH,
    PLAYERS,
    SCHEMA_VERSION,
    SLOTS,
    Ball,
    Camera,
    Player,
)


def result_summary(result):
    f, d = result.features, result.diagnostics
    return {
        "schema": SCHEMA_VERSION,
        "shape": list(f.shape),
        "dtype": str(f.dtype),
        "clip_duration_seconds": d["clip_duration_seconds"],
        "timings_seconds": result.timings,
        "camera_cut_frames": np.flatnonzero(f[:, CAMERA][:, Camera.CUT]).tolist(),
        "mean_visible_players": float(
            f[:, PLAYERS].reshape(len(f), SLOTS, PLAYER_WIDTH)[..., Player.VISIBLE].sum(axis=1).mean()
        ),
        "direct_ball_frames": int(f[:, BALL][:, Ball.VISIBLE].sum()),
        "interpolated_ball_frames": int(d["ball_interpolated"].sum()),
        "audio_available_intervals": d["audio_available_intervals"],
        "detector_frames_inferred": d["detector_frames_inferred"],
        "tracks": [
            {
                "segment": t.key[0],
                "track_id": t.key[1],
                "slot": t.slot,
                "feature_start": t.slot * 9 if t.slot is not None else None,
                "team": t.team,
                "likely_official_or_third_kit": t.official,
                "observed_frames": [o.frame for o in t.observations],
            }
            for t in d["tracks"].values()
        ],
        "warnings": d["warnings"],
    }


def inspect_main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("video", type=Path, nargs="?")
    p.add_argument("--schema", action="store_true")
    p.add_argument("--weights", default="yolo26s.pt")
    p.add_argument("--device", default="cpu")
    p.add_argument("--image-size", type=int, default=640)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--confidence", type=float, default=0.15)
    p.add_argument("--ball-confidence", type=float, default=0.08)
    p.add_argument("--half", action="store_true")
    p.add_argument("--tracker", choices=["botsort", "bytetrack"], default="botsort")
    p.add_argument("--fps", type=float, help="Source .npy FPS; default assumes configured count at 15FPS")
    p.add_argument("--config", type=Path, help="TOML config (default: matchpulse/config.toml)")
    p.add_argument("--start", type=float, help="Window start in a longer file")
    p.add_argument("--debug-video", type=Path)
    p.add_argument("--output", type=Path, default=Path("artifacts/features.npy"))
    args = p.parse_args(argv)
    if args.schema:
        print(json.dumps(dict(enumerate(FEATURE_NAMES)), indent=2))
        if args.video is None:
            return
    if args.video is None:
        p.error("video is required unless --schema is used")
    import cv2

    cv2.setNumThreads(1)
    extractor = MatchFeatureExtractor(
        detector_config=DetectorConfig(
            weights=args.weights,
            device=args.device,
            image_size=args.image_size,
            batch_size=args.batch_size,
            confidence=args.confidence,
            ball_confidence=args.ball_confidence,
            half=args.half,
        ),
        config=ExtractorConfig.from_file(args.config, tracker=args.tracker),
    )
    if args.start is not None:
        features = extractor.extract_window(args.video, args.start, debug_video=args.debug_video)
    else:
        video = np.load(args.video, allow_pickle=False) if args.video.suffix == ".npy" else args.video
        features = extractor.extract(video, fps=args.fps, debug_video=args.debug_video)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.save(args.output, features)
    np.savetxt(
        args.output.with_suffix(".csv"),
        np.column_stack([extractor.last_result.diagnostics["timestamps"], features]),
        delimiter=",",
        header=",".join(("timestamp", *FEATURE_NAMES)),
        comments="",
    )
    summary = result_summary(extractor.last_result)
    args.output.with_suffix(".json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "tracks"}, indent=2))
