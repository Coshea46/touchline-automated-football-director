"""Training-only masked channel statistics, with explicit schema-v1 validity rules."""

import numpy as np

from matchpulse.features.schema import FEATURE_NAMES, SCHEMA_VERSION

PRESERVED = tuple([s * 9 + j for s in range(22) for j in (6, 7, 8)] + [202, 203, 208, 209, 214])
RULE_VERSION = "masked-channel-zscore-v1"


def validity_mask(x):
    """Recover position validity from sizes/visibility; schema v1 lacks explicit interpolation masks."""
    x = np.asarray(x)
    if x.shape[-1] != 215 or x.ndim < 2 or not np.isfinite(x).all():
        raise ValueError("Expected finite [...,time,215] raw features")
    mask = np.ones(x.shape, bool)
    p = x[..., :198].reshape(*x.shape[:-1], 22, 9)
    pm = mask[..., :198].reshape(*x.shape[:-1], 22, 9)
    valid = (p[..., 7] == 1) | ((p[..., 4] > 0) & (p[..., 5] > 0))
    pm[..., :6] = valid[..., None]
    motion = valid.copy()
    motion[..., 0, :] = False
    motion[..., 1:, :] &= valid[..., :-1, :]
    motion &= x[..., 208, None] == 0
    pm[..., 2:4] = motion[..., None]
    ball = (x[..., 203] == 1) | np.any(x[..., 198:200] != 0, axis=-1)
    mask[..., 198:202] = ball[..., None]
    bmotion = ball.copy()
    bmotion[..., 0] = False
    bmotion[..., 1:] &= ball[..., :-1]
    bmotion &= x[..., 208] == 0
    mask[..., 200:202] = bmotion[..., None]
    mask[..., 204] = ball & (p[..., 7] == 1).any(axis=-1)
    mask[..., 206:208] = ((x[..., 208] == 0) & (x[..., 209] == 1))[..., None]
    mask[..., 0, 206:208] = False
    mask[..., 210:214] = x[..., 214, None] == 1
    mask[..., list(PRESERVED)] = False
    return mask


class MaskedStandardizer:
    def __init__(self, mean, scale, count, epsilon=1e-6):
        self.mean, self.scale = np.asarray(mean, np.float64), np.asarray(scale, np.float64)
        self.count, self.epsilon = np.asarray(count, np.int64), epsilon
        if self.mean.shape != (215,) or self.scale.shape != (215,) or self.count.shape != (215,):
            raise ValueError("Normalizer must describe all 215 schema channels")
        if not np.isfinite(self.mean).all() or not np.isfinite(self.scale).all() or (self.scale <= 0).any():
            raise ValueError("Invalid normalization parameters")

    @classmethod
    def fit(cls, batches, *, split, epsilon=1e-6):
        if split != "train":
            raise ValueError("Fit normalization on the training split only")
        count, mean, m2 = np.zeros(215, np.int64), np.zeros(215), np.zeros(215)
        for batch in batches:
            x = np.asarray(batch, np.float64)
            mask = validity_mask(x).reshape(-1, 215)
            flat = x.reshape(-1, 215)
            n = mask.sum(axis=0)
            bmean = np.sum(np.where(mask, flat, 0), axis=0) / np.maximum(n, 1)
            bm2 = np.sum(np.where(mask, (flat - bmean) ** 2, 0), axis=0)
            total = count + n
            delta = bmean - mean
            mean += delta * n / np.maximum(total, 1)
            m2 += bm2 + delta**2 * count * n / np.maximum(total, 1)
            count = total
        if not count.any():
            raise ValueError("No usable training observations for normalization")
        scale = np.sqrt(m2 / np.maximum(count, 1))
        scale[(count < 2) | (scale < epsilon)] = 1
        mean[list(PRESERVED)], scale[list(PRESERVED)] = 0, 1
        return cls(mean, scale, count, epsilon)

    def transform(self, features):
        x = np.asarray(features)
        mask = validity_mask(x)
        out = np.where(mask, (x - self.mean) / self.scale, 0).astype(np.float32)
        out[..., list(PRESERVED)] = x[..., list(PRESERVED)]
        return out

    def to_dict(self):
        return {
            "version": RULE_VERSION,
            "schema": SCHEMA_VERSION,
            "feature_names": list(FEATURE_NAMES),
            "mean": self.mean.tolist(),
            "scale": self.scale.tolist(),
            "count": self.count.tolist(),
            "epsilon": self.epsilon,
            "fitted_split": "train",
            "preserved_channels": list(PRESERVED),
        }

    @classmethod
    def from_dict(cls, value):
        if (
            value["version"] != RULE_VERSION
            or value["schema"] != SCHEMA_VERSION
            or value["fitted_split"] != "train"
        ):
            raise ValueError("Unsupported preprocessing or training provenance")
        if value["feature_names"] != list(FEATURE_NAMES) or value["preserved_channels"] != list(PRESERVED):
            raise ValueError("Preprocessing channel order changed")
        return cls(value["mean"], value["scale"], value["count"], value["epsilon"])
