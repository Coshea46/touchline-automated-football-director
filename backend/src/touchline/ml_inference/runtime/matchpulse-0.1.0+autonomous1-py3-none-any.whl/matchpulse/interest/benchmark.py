"""Warm CPU/CUDA latency at batch sizes 1 and 7, separated from loading."""

import os
import platform
import time
from pathlib import Path

import numpy as np
import torch

from .checkpoint import load_interest_classifier


def benchmark_classifier(path, raw_samples, *, repeats=100, warmup=25):
    if not torch.cuda.is_available():
        raise RuntimeError("GPU benchmarking must actually use CUDA")
    old_threads = torch.get_num_threads()
    results = []
    try:
        torch.set_num_threads(1)
        for device in ("cpu", "cuda:0"):
            classifier = load_interest_classifier(path, device=device)
            for batch_size in (1, 7):
                raw = np.stack([raw_samples[i % len(raw_samples)] for i in range(batch_size)])
                prepared = classifier.normalization.transform(raw)[..., : classifier.input_size]
                x = torch.from_numpy(np.ascontiguousarray(prepared)).to(device)
                with torch.inference_mode():
                    for _ in range(warmup):
                        classifier.model(x).sigmoid()
                    if device != "cpu":
                        torch.cuda.synchronize()
                    compute, api = [], []
                    for _ in range(repeats):
                        if device == "cpu":
                            started = time.perf_counter()
                            classifier.model(x).sigmoid()
                            compute.append((time.perf_counter() - started) * 1000)
                        else:
                            begin, end = (
                                torch.cuda.Event(enable_timing=True),
                                torch.cuda.Event(enable_timing=True),
                            )
                            begin.record()
                            classifier.model(x).sigmoid()
                            end.record()
                            end.synchronize()
                            compute.append(begin.elapsed_time(end))
                    for _ in range(repeats):
                        if device != "cpu":
                            torch.cuda.synchronize()
                        started = time.perf_counter()
                        classifier.predict_batch(raw)
                        if device != "cpu":
                            torch.cuda.synchronize()
                        api.append((time.perf_counter() - started) * 1000)
                results.append(
                    {
                        "device": device,
                        "batch_size": batch_size,
                        "cpu_threads": 1,
                        "load_ms": classifier.load_seconds * 1000,
                        "warmup": warmup,
                        "repeats": repeats,
                        "model_median_ms": float(np.median(compute)),
                        "model_p95_ms": float(np.percentile(compute, 95)),
                        "api_median_ms": float(np.median(api)),
                        "api_p95_ms": float(np.percentile(api, 95)),
                        "model_samples_per_second": batch_size * 1000 / float(np.mean(compute)),
                        "api_samples_per_second": batch_size * 1000 / float(np.mean(api)),
                    }
                )
    finally:
        torch.set_num_threads(old_threads)
    cpu_name = platform.processor()
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        cpu_name = next(
            (
                s.split(":", 1)[1].strip()
                for s in cpuinfo.read_text().splitlines()
                if s.startswith("model name")
            ),
            cpu_name,
        )
    return {
        "gpu": torch.cuda.get_device_name(0),
        "cpu": cpu_name,
        "logical_cpus": os.cpu_count(),
        "cuda_context": "Already initialized; loading timings are not a cold CUDA driver startup benchmark",
        "measurements": results,
    }
