"""Validation-only thresholds and original-incident event metrics."""

from collections import defaultdict

import numpy as np


def _scores(scores, rows):
    scores = np.asarray(scores, np.float64)
    if scores.shape != (len(rows),) or not np.isfinite(scores).all() or np.any((scores < 0) | (scores > 1)):
        raise ValueError("One finite sigmoid score in [0,1] is required per sample")
    return scores


class ForwardingBudget:
    """Exact selected-clip union, accumulated at complete score-tie groups."""

    def __init__(self, rows, scores):
        self.scores = _scores(scores, rows)
        if not len(rows):
            raise ValueError("Nonempty scored rows required")
        by_half = defaultdict(list)
        for i, row in enumerate(rows):
            by_half[(row["match_id"], row["half"])].append(i)
        cells, ranges = {}, {}
        self.exposure = 0.0
        for key, indices in by_half.items():
            starts = [
                float(rows[i].get("observation_start_seconds", rows[i]["observation_end_seconds"] - 5))
                for i in indices
            ]
            ends = [float(rows[i]["observation_end_seconds"]) for i in indices]
            if any(b <= a for a, b in zip(starts, ends, strict=True)):
                raise ValueError("Invalid forwarding clip interval")
            boundaries = np.unique(starts + ends)
            lengths = np.diff(boundaries)
            eligible = np.zeros(len(lengths), bool)
            for i, start, end in zip(indices, starts, ends, strict=True):
                lo, hi = np.searchsorted(boundaries, [start, end])
                ranges[i] = key, lo, hi
                eligible[lo:hi] = True
            self.exposure += float(lengths[eligible].sum())
            cells[key] = lengths, np.zeros(len(lengths), bool)
        order = np.argsort(-self.scores, kind="stable")
        thresholds, seconds, counts = [], [], []
        forwarded = 0.0
        for position, i in enumerate(order):
            key, lo, hi = ranges[int(i)]
            lengths, covered = cells[key]
            forwarded += float(lengths[lo:hi][~covered[lo:hi]].sum())
            covered[lo:hi] = True
            if position == len(order) - 1 or self.scores[order[position + 1]] != self.scores[i]:
                thresholds.append(self.scores[i])
                seconds.append(forwarded)
                counts.append(position + 1)
        self.thresholds, self.union_seconds, self.counts = (
            np.asarray(thresholds),
            np.asarray(seconds),
            np.asarray(counts),
        )

    def threshold(self, budget, *, split, mode="clip_union"):
        if split != "valid":
            raise ValueError("Operating thresholds must be selected on validation only")
        if not 0 <= budget <= 1 or mode not in ("clip_union", "decision_gate"):
            raise ValueError("Invalid budget or forwarding definition")
        fractions = (
            self.union_seconds / self.exposure if mode == "clip_union" else self.counts / len(self.scores)
        )
        permitted = np.flatnonzero(fractions <= budget + 1e-12)
        return (
            float(self.thresholds[permitted[-1]])
            if len(permitted)
            else float(np.nextafter(self.thresholds[0], np.inf))
        )

    def measure(self, threshold):
        count = int(np.searchsorted(-self.thresholds, -threshold, side="right"))
        return (float(self.union_seconds[count - 1]), int(self.counts[count - 1])) if count else (0.0, 0)


def choose_threshold(scores, budget, *, split, rows=None, mode="clip_union"):
    """Lowest >= threshold satisfying the validation budget; ties are never split."""
    if split != "valid":
        raise ValueError("Operating thresholds must be selected on validation only")
    if rows is not None:
        return ForwardingBudget(rows, scores).threshold(budget, split=split, mode=mode)
    scores = _scores(scores, scores)
    if len(scores) == 0 or not 0 <= budget <= 1:
        raise ValueError("Nonempty scores and budget in [0,1] required")
    unique, counts = np.unique(scores, return_counts=True)
    unique, counts = unique[::-1], counts[::-1]
    permitted = np.flatnonzero(np.cumsum(counts) <= budget * len(scores) + 1e-10)
    # nextafter also handles saturated score=1 without splitting equal scores.
    return float(unique[permitted[-1]]) if len(permitted) else float(np.nextafter(unique[0], np.inf))


def incident_groups(events, rows):
    halves = {(r["match_id"], int(r["half"])) for r in rows}
    groups = {}
    for event in events:
        if not event["qualifying"] or (event["match_id"], int(event["half"])) not in halves:
            continue
        key = event["evaluation_group_id"]
        if not key:
            raise ValueError("Original evaluation_group_id required; do not regenerate event labels")
        group = groups.setdefault(
            key,
            {
                "id": key,
                "match_id": event["match_id"],
                "half": int(event["half"]),
                "timestamp": float(event["timestamp_seconds"]),
                "event_ids": [],
            },
        )
        if (group["match_id"], group["half"]) != (event["match_id"], int(event["half"])):
            raise ValueError("An incident group crosses match halves")
        group["timestamp"] = min(group["timestamp"], float(event["timestamp_seconds"]))
        group["event_ids"].append(event["event_id"])
    return list(groups.values())


def alert_episodes(rows, predictions, stride=1.0):
    if len(rows) != len(predictions):
        raise ValueError("Prediction/row count mismatch")
    ordered = sorted(
        range(len(rows)),
        key=lambda i: (rows[i]["match_id"], rows[i]["half"], rows[i]["observation_end_seconds"]),
    )
    episodes, current = [], None
    for i in ordered:
        row = rows[i]
        key, time = (row["match_id"], int(row["half"])), float(row["observation_end_seconds"])
        if not predictions[i]:
            current = None
            continue
        if current is None or current["half_key"] != key or abs(time - current["times"][-1] - stride) > 1e-6:
            current = {"half_key": key, "times": [], "indices": []}
            episodes.append(current)
        current["times"].append(time)
        current["indices"].append(i)
    for episode in episodes:
        episode["start"] = episode["times"][0]
        episode["end"] = episode["times"][-1] + stride
        episode["duration"] = episode["end"] - episode["start"]
    return episodes


def event_metrics(
    rows,
    scores,
    events,
    threshold,
    *,
    full_match_hours=None,
    stride=1.0,
    min_lead=3,
    max_lead=10,
    forwarding_mode="clip_union",
    forwarding_index=None,
):
    scores = _scores(scores, rows)
    positive = scores >= threshold
    forwarding = forwarding_index or ForwardingBudget(rows, scores)
    clip_seconds, forwarded_decisions = forwarding.measure(threshold)
    footage_fraction, decision_fraction = clip_seconds / forwarding.exposure, float(positive.mean())
    independent_seconds = float(
        sum(
            row["observation_end_seconds"]
            - row.get("observation_start_seconds", row["observation_end_seconds"] - 5)
            for row, selected in zip(rows, positive, strict=True)
            if selected
        )
    )
    if forwarding_mode not in ("clip_union", "decision_gate"):
        raise ValueError("Unknown forwarding definition")
    episodes = alert_episodes(rows, positive, stride)
    groups = incident_groups(events, rows)
    by_half = defaultdict(list)
    for i, row in enumerate(rows):
        by_half[(row["match_id"], int(row["half"]))].append(i)
    detected, eligible, leads, successful_indices = [], [], [], set()
    for group in groups:
        indices = by_half[(group["match_id"], group["half"])]
        permitted = [
            i
            for i in indices
            if min_lead - 1e-7 <= group["timestamp"] - rows[i]["observation_end_seconds"] <= max_lead + 1e-7
        ]
        if permitted:
            eligible.append(group["id"])
        alerted = [i for i in permitted if positive[i]]
        if alerted:
            detected.append(group["id"])
            successful_indices.update(alerted)
            leads.append(max(group["timestamp"] - rows[i]["observation_end_seconds"] for i in alerted))
    false = sum(not any(i in successful_indices for i in episode["indices"]) for episode in episodes)
    scored_hours = len(rows) * stride / 3600
    full_hours = full_match_hours if full_match_hours is not None else scored_hours
    return {
        "threshold": float(threshold),
        "threshold_comparator": ">=",
        "qualifying_events": len(groups),
        "anticipatable_events_in_scored_coverage": len(eligible),
        "anticipated_events": len(detected),
        "event_recall": len(detected) / len(groups) if groups else None,
        "event_recall_given_scored_coverage": len(detected) / len(eligible) if eligible else None,
        "forwarding_mode": forwarding_mode,
        "forwarding_fraction": footage_fraction if forwarding_mode == "clip_union" else decision_fraction,
        "clip_union_forwarding_fraction": footage_fraction,
        "decision_forwarding_fraction": decision_fraction,
        "window_forwarding_fraction": decision_fraction,
        "forwarded_windows": forwarded_decisions,
        "total_windows": len(rows),
        "independent_clip_processing_seconds": independent_seconds,
        "additional_uncached_video_seconds": max(0.0, independent_seconds - clip_seconds),
        "uncached_vs_unique_video_work_multiplier": independent_seconds / clip_seconds
        if clip_seconds
        else None,
        "overlap_reuse_savings_fraction": 1 - clip_seconds / independent_seconds
        if independent_seconds
        else 0.0,
        "independent_work_fraction_of_eligible_footage": independent_seconds / forwarding.exposure,
        "stage2_cost_note": "Clip-seconds are a video/frame-analysis work proxy, not measured Stage 2 latency or monetary cost. Request overhead and temporal-model work may remain even when overlapping footage is cached.",
        "forwarded_seconds": clip_seconds
        if forwarding_mode == "clip_union"
        else forwarded_decisions * stride,
        "forwarded_clip_union_seconds": clip_seconds,
        "eligible_clip_union_seconds": forwarding.exposure,
        "scored_match_hours": scored_hours,
        "available_match_hours": full_hours,
        "scored_coverage_fraction": scored_hours / full_hours if full_hours else None,
        "forwarding_fraction_of_full_footage_lower_bound": (
            clip_seconds if forwarding_mode == "clip_union" else forwarded_decisions * stride
        )
        / (3600 * full_hours)
        if full_hours
        else None,
        "alert_episodes": len(episodes),
        "false_alert_episodes": false,
        "alerts_per_match_hour": len(episodes) / full_hours if full_hours else None,
        "false_alerts_per_match_hour": false / full_hours if full_hours else None,
        "false_alerts_per_scored_hour": false / scored_hours if scored_hours else None,
        "average_alert_duration_seconds": float(np.mean([e["duration"] for e in episodes]))
        if episodes
        else 0.0,
        "average_advance_warning_seconds": float(np.mean(leads)) if leads else None,
        "anticipated_event_group_ids": detected,
        "coverage_note": "Default budgets measure selected five-second clip unions divided by all eligible clip unions. The decision-gate rate is also reported. Ignored/unscored decision gaps split alert episodes; full-match alert rates are lower bounds because those gaps have no predictions.",
        "incident_timestamp_rule": "Earliest original annotation timestamp in each original evaluation_group_id; no incident regrouping or relabelling.",
    }


def binary_metrics(labels, scores, threshold):
    from sklearn.metrics import (
        average_precision_score,
        confusion_matrix,
        f1_score,
        precision_score,
        recall_score,
        roc_auc_score,
    )

    labels = np.asarray(labels)
    if labels.shape != np.asarray(scores).shape or not np.isin(labels, [0, 1]).all():
        raise ValueError("Binary labels required")
    predicted = np.asarray(scores) >= threshold
    both = len(np.unique(labels)) == 2
    return {
        "precision": float(precision_score(labels, predicted, zero_division=0)),
        "recall": float(recall_score(labels, predicted, zero_division=0)),
        "f1": float(f1_score(labels, predicted, zero_division=0)),
        "macro_f1": float(f1_score(labels, predicted, average="macro", labels=[0, 1], zero_division=0)),
        "average_precision": float(average_precision_score(labels, scores)) if np.any(labels == 1) else None,
        "roc_auc": float(roc_auc_score(labels, scores)) if both else None,
        "confusion_matrix": confusion_matrix(labels, predicted, labels=[0, 1]).tolist(),
    }


def evaluate(rows, labels, scores, events, threshold, **kwargs):
    return {
        **binary_metrics(labels, scores, threshold),
        **event_metrics(rows, scores, events, threshold, **kwargs),
    }
