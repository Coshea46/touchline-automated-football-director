"""Stage 1 temporal classification, training and event-level evaluation."""
