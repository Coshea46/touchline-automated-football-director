"""Frozen, serialisable experimental controls; A/B differ only in clipping."""

import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class StudyConfig:
    seed: int = 42
    batch_size: int = 128
    max_epochs: int = 30
    patience: int = 5
    min_delta: float = 0.0
    learning_rate: float = 0.001
    weight_decay: float = 0.01
    dropout: float = 0.2
    gru_hidden_size: int = 64
    tcn_channels: int = 32
    tcn_kernel_size: int = 3
    tcn_dilations: tuple = (1, 2, 4)
    num_workers: int = 2
    checkpoint_batches: int = 100
    forwarding_budgets: tuple = (0.1, 0.2, 0.3)
    decision_stride_seconds: float = 1.0
    forecast_min_seconds: float = 3.0
    forecast_max_seconds: float = 10.0
    selection_budget: float = 0.2
    forwarding_mode: str = "clip_union"
    normalization_epsilon: float = 1e-6
    session_seconds: float = 7 * 3600

    def __post_init__(self):
        if min(self.batch_size, self.max_epochs, self.patience, self.checkpoint_batches) < 1:
            raise ValueError("Batch size, epochs, patience and checkpoint interval must be positive")
        if self.learning_rate <= 0 or self.normalization_epsilon <= 0 or self.session_seconds <= 0:
            raise ValueError("Learning rate, normalization epsilon and session budget must be positive")
        if (
            not all(0 < b < 1 for b in self.forwarding_budgets)
            or self.selection_budget not in self.forwarding_budgets
        ):
            raise ValueError("Selection budget must be one of the forwarding budgets in (0,1)")
        if not {0.1, 0.2, 0.3}.issubset(self.forwarding_budgets) or self.selection_budget != 0.2:
            raise ValueError("This programme reports 10/20/30% budgets and selects at 20%")
        if self.forwarding_mode not in ("clip_union", "decision_gate"):
            raise ValueError("Unknown forwarding mode")
        if not 0 <= self.dropout < 1 or self.num_workers < 0:
            raise ValueError("Invalid dropout or worker count")
        if self.decision_stride_seconds != 1 or (self.forecast_min_seconds, self.forecast_max_seconds) != (
            3,
            10,
        ):
            raise ValueError("This study uses the existing one-second, 3–10-second label contract")

    @classmethod
    def from_file(cls, path=None):
        data = json.loads(Path(path or Path(__file__).with_name("config.json")).read_text())
        for key in ("tcn_dilations", "forwarding_budgets"):
            if key in data:
                data[key] = tuple(data[key])
        return cls(**data)

    def to_dict(self):
        return asdict(self)


def experiment_configs(config, stronger_gru=None):
    head = {"dropout": config.dropout}
    gru = {"kind": "gru", "input_size": 215, "hidden_size": config.gru_hidden_size, **head}
    result = {
        "A_gru": {"model": gru, "clip_norm": None},
        "B_gru_clipped": {"model": dict(gru), "clip_norm": 1.0},
        "C_tcn": {
            "model": {
                "kind": "tcn",
                "input_size": 215,
                "channels": config.tcn_channels,
                "kernel_size": config.tcn_kernel_size,
                "dilations": list(config.tcn_dilations),
                **head,
            },
            "clip_norm": None,
        },
    }
    if stronger_gru is not None:
        if stronger_gru not in ("A_gru", "B_gru_clipped"):
            raise ValueError("Audio ablation must use a validated GRU configuration")
        parent = result[stronger_gru]
        result["D_gru_no_audio"] = {
            "model": {**parent["model"], "input_size": 210},
            "clip_norm": parent["clip_norm"],
            "parent": stronger_gru,
        }
    return result
