"""Audit existing numerical outputs against original manifests; never silently drop a sample."""

import json
from collections import Counter
from hashlib import sha256
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq
from torch.utils.data import Dataset

from matchpulse.batch.dataset import FeatureDataset
from matchpulse.batch.storage import HalfStore, atomic_json, json_bytes
from matchpulse.features.schema import FEATURE_NAMES, SCHEMA_VERSION

from .preprocessing import MaskedStandardizer


def file_hash(path):
    h = sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def class_weight(labels):
    labels = np.asarray(labels)
    if labels.ndim != 1 or not np.isin(labels, [0, 1]).all():
        raise ValueError("Binary training labels required")
    positive = int((labels == 1).sum())
    negative = int((labels == 0).sum())
    if not positive or not negative:
        raise ValueError("Both training classes are required")
    return negative / positive


def audit_and_prepare(feature_root, manifest_root, cache_root, *, epsilon=1e-6,
                      splits=("train", "valid", "test")):
    if splits not in (("train", "valid", "test"), ("train", "valid")):
        raise ValueError("Audit requires train/valid, with optional held-out test")
    feature_root, manifest_root, cache_root = map(Path, (feature_root, manifest_root, cache_root))
    schema = json.loads((feature_root / "schema.json").read_text())
    if (schema["version"], schema["fps"], schema["duration_seconds"], schema["features_per_frame"]) != (
        SCHEMA_VERSION,
        15,
        5,
        215,
    ):
        raise ValueError("Stage 1 requires the versioned float32 (75,215), five-second, 15FPS schema")
    if schema["feature_names"] != list(FEATURE_NAMES):
        raise ValueError("Feature channel ordering mismatch")
    run = json.loads((feature_root / "run-report.json").read_text())
    if run["unprocessed"] or any(
        v["status"] != "complete" or not v["full_half"] for v in run["halves"].values()
    ):
        raise ValueError("Full extraction is not complete; do not train on a partial dataset")
    expected, ignored_ids, assignments, versions, config_hashes = {}, set(), {}, set(), set()
    manifest_hashes = {}
    for path in sorted(manifest_root.glob("*.parquet")):
        if "window_id" not in pq.read_schema(path).names:
            continue
        manifest_hashes[path.name] = file_hash(path)
        for row in pq.read_table(path).to_pylist():
            identifier = row["window_id"]
            if identifier in expected or identifier in ignored_ids:
                raise ValueError(f"Duplicate manifest sample {identifier}")
            split = {"val": "valid", "validation": "valid"}.get(row["split"], row["split"])
            if split not in splits:
                raise ValueError("Manifest includes a split excluded from this audit")
            if split not in ("train", "valid", "test"):
                raise ValueError("Unknown official split")
            row = {**row, "split": split, "match_id": row["match_id"].replace("\\", "/").strip("/")}
            previous = assignments.setdefault(row["match_id"], split)
            if previous != split:
                raise ValueError("Match-level split leakage")
            versions.add(row["label_version"])
            config_hashes.add(row["config_sha256"])
            if row["label"] == -1:
                ignored_ids.add(identifier)
            elif row["label"] in (0, 1):
                expected[identifier] = row
            else:
                raise ValueError("Unknown supervised label")
    if len(versions) != 1 or len(config_hashes) != 1 or not expected:
        raise ValueError("One consistent original labelling version/configuration is required")
    candidates = [
        manifest_root.parent / "config/labels-v1.json",
        manifest_root.parents[2] / "config/labels-v1.json",
    ]
    config_path = next((p for p in candidates if p.is_file()), None)
    if config_path is None:
        raise ValueError("Original labels-v1.json configuration is required")
    label_config = json.loads(config_path.read_text())
    if (
        label_config["label_version"],
        label_config["observation_seconds"],
        label_config["window_stride_seconds"],
        label_config["min_forecast_lead_seconds"],
        label_config["max_forecast_lead_seconds"],
    ) != (next(iter(versions)), 5, 1, 3, 10):
        raise ValueError("Original labelling configuration disagrees with the study contract")
    events_path = manifest_root / "events.parquet"
    events = pq.read_table(events_path).to_pylist()
    events_by_id = {e["event_id"]: e for e in events}
    if len(events_by_id) != len(events):
        raise ValueError("Duplicate original event ID")
    event_hash = file_hash(events_path)
    for row in expected.values():
        future = row["future_event_ids"]
        if bool(future) != bool(row["label"]):
            raise ValueError("Binary label disagrees with its original future event IDs")
        for identifier in future:
            event = events_by_id[identifier]
            lead = event["timestamp_seconds"] - row["observation_end_seconds"]
            if not event["qualifying"] or not 3 - 1e-7 <= lead <= 10 + 1e-7:
                raise ValueError("Original event association is outside the anticipation horizon")
            if (event["match_id"], event["half"], event["split"]) != (
                row["match_id"],
                row["half"],
                row["split"],
            ):
                raise ValueError("Event/window association crosses a split or match half")
    cache_root.mkdir(parents=True, exist_ok=True)
    seen, ordered, counts, hours, arrays, label_arrays, half_keys = set(), {}, {}, {}, {}, {}, set()
    feature_hashes = {}
    half_paths, decisions = {}, set()
    for split in splits:
        ordered[split], hours[split] = [], 0.0
        with FeatureDataset(feature_root, split) as dataset:
            expected_split = {k for k, r in expected.items() if r["split"] == split}
            actual = [r["sample_id"] for r in dataset.rows]
            if len(actual) != len(set(actual)) or set(actual) != expected_split:
                raise ValueError(f"{split}: missing, extra or duplicate feature sample IDs")
            if not actual:
                raise ValueError(f"{split}: empty split")
            arrays[split] = np.lib.format.open_memmap(
                cache_root / f"{split}.npy", mode="w+", dtype=np.float32, shape=(len(actual), 75, 215)
            )
            label_arrays[split] = np.lib.format.open_memmap(
                cache_root / f"{split}-labels.npy", mode="w+", dtype=np.int64, shape=(len(actual),)
            )
            stores_seen = set()
            for i, index in enumerate(dataset.rows):
                identifier = index["sample_id"]
                original = expected[identifier]
                decision = (original["match_id"], original["half"], original["observation_end_seconds"])
                if (
                    decision in decisions
                    or abs(original["observation_end_seconds"] - original["observation_start_seconds"] - 5)
                    > 1e-7
                ):
                    raise ValueError("Duplicate decision time or invalid observation duration")
                decisions.add(decision)
                if identifier in seen or identifier in ignored_ids or not index["materialized"]:
                    raise ValueError("Duplicate/ignored sample or non-materialized training feature")
                for key in (
                    "match_id",
                    "half",
                    "split",
                    "label",
                    "observation_start_seconds",
                    "observation_end_seconds",
                ):
                    if index[key] != original[key]:
                        raise ValueError(f"Feature/manifest mismatch for {identifier}: {key}")
                if index["steps"] != 75 or index["schema_version"] != SCHEMA_VERSION:
                    raise ValueError("Feature index schema mismatch")
                cache_path = (feature_root / index["cache_path"]).resolve()
                if not cache_path.is_relative_to(feature_root.resolve()):
                    raise ValueError("Unsafe feature cache path")
                if cache_path not in stores_seen:
                    with HalfStore(cache_path, readonly=True) as store:
                        completed = store.get("completed")
                        if (
                            not completed
                            or not completed["full_half"]
                            or store.frontier != completed["frames"]
                        ):
                            raise ValueError("Training requires fully completed match halves")
                        probe = store.get("probe")
                        half_key = store.get("identity")["half_key"]
                        if half_key != f"{original['match_id']}/{original['half']}_720p.mkv":
                            raise ValueError("Cache identity differs from the original match half")
                        if half_key in half_paths and half_paths[half_key] != cache_path:
                            raise ValueError("A match half is duplicated across numerical stores")
                        half_paths[half_key] = cache_path
                        hours[split] += probe["duration"] / 3600
                        half_keys.add(half_key)
                    stores_seen.add(cache_path)
                    feature_hashes[index["cache_path"]] = file_hash(cache_path)
                features, label, sample_id = dataset[i]
                if label != original["label"] or sample_id != identifier:
                    raise ValueError("Feature payload label/identifier mismatch")
                arrays[split][i], label_arrays[split][i] = features, label
                ordered[split].append(original)
                seen.add(identifier)
            counts[split] = {
                "samples": len(actual),
                "positive": int((label_arrays[split] == 1).sum()),
                "negative": int((label_arrays[split] == 0).sum()),
            }
            arrays[split].flush()
            label_arrays[split].flush()
    if seen != set(expected) or len(half_keys) != len(run["halves"]):
        raise ValueError("Feature audit did not cover the complete supplied dataset")
    report = {
        "schema": SCHEMA_VERSION,
        "shape": [75, 215],
        "dtype": "float32",
        "counts": counts,
        "ignored_windows_excluded": len(ignored_ids),
        "match_split_counts": dict(Counter(assignments.values())),
        "manifest_sha256": manifest_hashes,
        "feature_sha256": feature_hashes,
        "events_sha256": event_hash,
        "label_version": next(iter(versions)),
        "label_config_sha256": next(iter(config_hashes)),
        "label_configuration": label_config,
        "label_config_file_sha256": file_hash(config_path),
        "full_match_hours": hours,
        "half_count": len(half_keys),
        "sample_identity_sha256": sha256(
            json_bytes(sorted((i, expected[i]["label"], expected[i]["split"]) for i in expected))
        ).hexdigest(),
        "pos_weight": class_weight(label_arrays["train"]),
    }
    if splits == ("train", "valid"):
        report["scope"] = "subset-trained, validation-evaluated MVP; test not accessed"
    report["audit_sha256"] = sha256(json_bytes(report)).hexdigest()
    train = arrays["train"]
    standardizer = MaskedStandardizer.fit(
        (train[i : i + 128] for i in range(0, len(train), 128)), split="train", epsilon=epsilon
    )
    for split, array in arrays.items():
        for start in range(0, len(array), 128):
            array[start : start + 128] = standardizer.transform(array[start : start + 128])
        array.flush()
    atomic_json(cache_root / "audit.json", report)
    atomic_json(cache_root / "normalization.json", standardizer.to_dict())
    return report, standardizer, ordered, events


class NumericalDataset(Dataset):
    """Read audited standardized memmaps; no YOLO, tracking or raw footage access."""

    def __init__(self, root, split, input_size=215):
        self.root, self.split, self.input_size = Path(root), split, input_size
        if input_size not in (210, 215):
            raise ValueError("Use full features or the five-channel audio ablation")
        self.x = np.load(self.root / f"{split}.npy", mmap_mode="r", allow_pickle=False)
        self.y = np.load(self.root / f"{split}-labels.npy", mmap_mode="r", allow_pickle=False)
        if (
            self.x.shape != (len(self.y), 75, 215)
            or self.x.dtype != np.float32
            or not np.isin(self.y, [0, 1]).all()
        ):
            raise ValueError("Invalid numerical training arrays")

    def __len__(self):
        return len(self.y)

    def __getitem__(self, index):
        return np.array(self.x[index, :, : self.input_size], copy=True), np.float32(self.y[index])

    def __getstate__(self):
        return {"root": self.root, "split": self.split, "input_size": self.input_size}

    def __setstate__(self, state):
        self.__init__(state["root"], state["split"], state["input_size"])
