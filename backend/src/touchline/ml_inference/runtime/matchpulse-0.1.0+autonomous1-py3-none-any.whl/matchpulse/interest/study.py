"""Execute all four controlled CUDA experiments, freeze selection, then evaluate test once."""

import argparse
import importlib.metadata
import json
import os
import platform
import shutil
import time
from pathlib import Path

import numpy as np
import torch

from matchpulse.batch.dataset import FeatureDataset
from matchpulse.batch.storage import atomic_json, json_bytes

from .benchmark import benchmark_classifier
from .checkpoint import export_checkpoint
from .config import StudyConfig, experiment_configs
from .data import NumericalDataset, audit_and_prepare, file_hash
from .evaluation import ForwardingBudget, evaluate, event_metrics
from .models import build_model, parameter_count
from .reporting import write_reports
from .training import SessionCheckpoint, predict_dataset, set_seed, train_experiment


def budget_key(budget):
    return str(round(100 * budget))


def validation_rank(name, results, budget=0.2):
    result = results[name]
    point = result["operating_points"][budget_key(budget)]
    return (
        -(point["event_recall"] if point["event_recall"] is not None else -1),
        -(point["average_precision"] if point["average_precision"] is not None else -1),
        result["parameters"],
        name,
    )


def summarise_split(rows, labels, scores, events, thresholds, curve_thresholds, hours, forwarding_mode):
    kwargs = {
        "full_match_hours": hours,
        "forwarding_mode": forwarding_mode,
        "forwarding_index": ForwardingBudget(rows, scores),
    }
    return {
        "operating_points": {
            key: evaluate(rows, labels, scores, events, threshold, **kwargs)
            for key, threshold in thresholds.items()
        },
        "event_curve": [
            {"validation_budget": budget, **event_metrics(rows, scores, events, threshold, **kwargs)}
            for budget, threshold in curve_thresholds
        ],
    }


def run_study(feature_root, manifest_root, output, cache_root, *, config=None):
    config = config or StudyConfig.from_file()
    if not torch.cuda.is_available():
        raise RuntimeError("A Kaggle CUDA GPU is required for this programme; no CPU training fallback")
    torch.cuda.set_device(0)
    torch.cuda.reset_peak_memory_stats()
    set_seed(config.seed)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    # Every session re-audits source arrays and reconstructs its ephemeral memmaps.
    audit, normalization, rows, events = audit_and_prepare(
        feature_root, manifest_root, cache_root, epsilon=config.normalization_epsilon
    )
    code = {p.name: file_hash(p) for p in sorted(Path(__file__).parent.glob("*.py"))}
    identity = json.loads(
        json_bytes({"configuration": config.to_dict(), "dataset": audit["audit_sha256"], "code": code})
    )
    identity_path = output / "study-identity.json"
    if identity_path.exists() and json.loads(identity_path.read_text()) != identity:
        raise ValueError("Study code/configuration/dataset changed; refusing to mix experiments")
    atomic_json(identity_path, identity)
    atomic_json(output / "dataset-audit.json", audit)
    atomic_json(output / "normalization.json", normalization.to_dict())
    environment = {
        "python": platform.python_version(),
        "gpu": torch.cuda.get_device_name(0),
        "gpu_count": torch.cuda.device_count(),
        "cuda": torch.version.cuda,
        "device": "cuda:0",
        "versions": {
            n: importlib.metadata.version(n)
            for n in ("torch", "numpy", "pyarrow", "scikit-learn", "matplotlib")
        },
        "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
        "CUBLAS_WORKSPACE_CONFIG": os.environ["CUBLAS_WORKSPACE_CONFIG"],
    }
    if (output / "environment.json").exists() and json.loads(
        (output / "environment.json").read_text()
    ) != environment:
        raise ValueError("Training environment changed across sessions; refusing to mix experiment runtimes")
    atomic_json(output / "environment.json", environment)
    deadline = time.perf_counter() + config.session_seconds
    validation, test, training, benchmarks = {}, {}, {}, {}
    labels_scores = {"valid": {}, "test": {}}
    definitions = experiment_configs(config)
    selected_gru = None
    try:
        for name in ("A_gru", "B_gru_clipped", "C_tcn", "D_gru_no_audio"):
            if name == "D_gru_no_audio":
                selected_gru = min(
                    ("A_gru", "B_gru_clipped"),
                    key=lambda n: validation_rank(n, validation, config.selection_budget),
                )
                definitions = experiment_configs(config, selected_gru)
                atomic_json(
                    output / "audio-parent-selection.json",
                    {
                        "selected_on": "valid",
                        "stronger_gru": selected_gru,
                        "rule": "Event recall at <=20% forwarding, then AP, then parameter count, then name",
                    },
                )
            experiment = definitions[name]
            checkpoint = train_experiment(
                name, experiment, config, cache_root, output, audit, deadline=deadline
            )
            saved = torch.load(checkpoint, map_location="cpu", weights_only=True)
            model = build_model(experiment["model"]).to("cuda:0")
            model.load_state_dict(saved["state_dict"])
            valid = NumericalDataset(cache_root, "valid", experiment["model"]["input_size"])
            scores, labels, loss = predict_dataset(model, valid, config, "cuda:0", audit["pos_weight"])
            forwarding = ForwardingBudget(rows["valid"], scores)
            thresholds = {
                budget_key(b): forwarding.threshold(b, split="valid", mode=config.forwarding_mode)
                for b in config.forwarding_budgets
            }
            curve_thresholds = [
                (float(b), forwarding.threshold(float(b), split="valid", mode=config.forwarding_mode))
                for b in np.linspace(0, 0.5, 51)
            ]
            result = summarise_split(
                rows["valid"],
                labels,
                scores,
                events,
                thresholds,
                curve_thresholds,
                audit["full_match_hours"]["valid"],
                config.forwarding_mode,
            )
            result.update(
                validation_loss=loss,
                parameters=parameter_count(model),
                thresholds=thresholds,
                best_epoch=saved["epoch"],
                model_configuration=experiment["model"],
            )
            validation[name], labels_scores["valid"][name] = result, (labels, scores)
            directory = output / "experiments" / name
            atomic_json(directory / "validation.json", result)
            np.savez_compressed(
                directory / "validation-predictions.npz",
                sample_ids=np.asarray([r["window_id"] for r in rows["valid"]]),
                labels=labels,
                scores=scores,
            )
            training[name] = json.loads((directory / "training-complete.json").read_text())
            export_checkpoint(
                directory / "classifier.pt",
                model,
                experiment["model"],
                normalization,
                threshold=thresholds[budget_key(config.selection_budget)],
                audit=audit,
                study_config=config,
                validation_metrics=result,
                experiment={"name": name, **experiment},
            )
            del model
        preferred = min(
            validation, key=lambda name: validation_rank(name, validation, config.selection_budget)
        )
        selection = {
            "selected_on": "valid",
            "preferred_model": preferred,
            "stronger_gru": selected_gru,
            "budget": config.selection_budget,
            "forwarding_mode": config.forwarding_mode,
            "threshold": validation[preferred]["thresholds"][budget_key(config.selection_budget)],
            "rule": "Highest distinct-event recall under 20% eligible-footage forwarding; ties: AP, fewer parameters, name",
            "dataset_audit_sha256": audit["audit_sha256"],
            "thresholds": {n: validation[n]["thresholds"] for n in validation},
            "curve_thresholds": {
                n: [(p["validation_budget"], p["threshold"]) for p in validation[n]["event_curve"]]
                for n in validation
            },
        }
        selection = json.loads(json_bytes(selection))
        selection_path = output / "selection-frozen-before-test.json"
        if selection_path.exists() and json.loads(selection_path.read_text()) != selection:
            raise ValueError("Attempt to alter model/threshold selection after test access")
        atomic_json(selection_path, selection)
        shutil.copy2(output / "experiments" / preferred / "classifier.pt", output / "best_model.pt")
        for name, experiment in definitions.items():
            directory = output / "experiments" / name
            test_path = directory / "test.json"
            prediction_path = directory / "test-predictions.npz"
            if test_path.exists() and prediction_path.exists():
                test[name] = json.loads(test_path.read_text())
                with np.load(prediction_path, allow_pickle=False) as value:
                    if value["sample_ids"].tolist() != [r["window_id"] for r in rows["test"]]:
                        raise ValueError("Saved test predictions refer to different samples")
                    labels_scores["test"][name] = value["labels"].copy(), value["scores"].copy()
            else:
                if time.perf_counter() >= deadline:
                    raise SessionCheckpoint("Training/selection completed; test evaluation deferred")
                saved = torch.load(directory / "best.pt", map_location="cpu", weights_only=True)
                model = build_model(experiment["model"]).to("cuda:0")
                model.load_state_dict(saved["state_dict"])
                dataset = NumericalDataset(cache_root, "test", experiment["model"]["input_size"])
                scores, labels, loss = predict_dataset(model, dataset, config, "cuda:0", audit["pos_weight"])
                result = summarise_split(
                    rows["test"],
                    labels,
                    scores,
                    events,
                    selection["thresholds"][name],
                    selection["curve_thresholds"][name],
                    audit["full_match_hours"]["test"],
                    config.forwarding_mode,
                )
                result.update(weighted_bce_loss=loss, selected_before_test=True)
                test[name], labels_scores["test"][name] = result, (labels, scores)
                np.savez_compressed(
                    prediction_path,
                    sample_ids=np.asarray([r["window_id"] for r in rows["test"]]),
                    labels=labels,
                    scores=scores,
                )
                atomic_json(test_path, result)
                del model
        # Benchmark real validation feature tensors, without labels, after model selection is frozen.
        with FeatureDataset(feature_root, "valid") as dataset:
            raw_samples = [dataset[i][0] for i in range(min(7, len(dataset)))]
        for name in definitions:
            path = output / "experiments" / name / "benchmark.json"
            if path.exists():
                benchmarks[name] = json.loads(path.read_text())
            else:
                if time.perf_counter() >= deadline:
                    raise SessionCheckpoint("Inference benchmarks deferred to next session")
                benchmarks[name] = benchmark_classifier(
                    output / "experiments" / name / "classifier.pt", raw_samples
                )
                atomic_json(path, benchmarks[name])
        write_reports(output, validation, test, selection, training, benchmarks, labels_scores)
        atomic_json(output / "validation-results.json", validation)
        atomic_json(output / "test-results.json", test)
        atomic_json(
            output / "programme-status.json",
            {
                "complete": True,
                "selection": selection,
                "experiments_completed": list(definitions),
                "dataset_audit_sha256": audit["audit_sha256"],
                "torch_gpu_peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                "best_model_sha256": file_hash(output / "best_model.pt"),
            },
        )
    except SessionCheckpoint as exc:
        atomic_json(
            output / "programme-status.json",
            {"complete": False, "reason": str(exc), "dataset_audit_sha256": audit["audit_sha256"]},
        )
        print(f"CHECKPOINTED: {exc}", flush=True)
    return json.loads((output / "programme-status.json").read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--features", type=Path, required=True)
    parser.add_argument("--manifests", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--config", type=Path)
    args = parser.parse_args()
    run_study(
        args.features, args.manifests, args.output, args.cache, config=StudyConfig.from_file(args.config)
    )


if __name__ == "__main__":
    main()
