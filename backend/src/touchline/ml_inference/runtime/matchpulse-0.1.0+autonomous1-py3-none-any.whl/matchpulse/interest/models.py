"""Lightweight logit models; the TCN never reads a future timestep."""

import torch
import torch.nn.functional as F
from torch import nn


class InterestGRU(nn.Module):
    def __init__(self, input_size=215, hidden_size=64, dropout=0.2):
        super().__init__()
        self.gru = nn.GRU(input_size, hidden_size, num_layers=1, batch_first=True)
        self.head = nn.Sequential(
            nn.Linear(hidden_size, 32), nn.ReLU(), nn.Dropout(dropout), nn.Linear(32, 1)
        )

    def forward(self, x):
        _, hidden = self.gru(x)
        return self.head(hidden[-1]).squeeze(-1)


class CausalConv(nn.Module):
    def __init__(self, channels, kernel_size, dilation):
        super().__init__()
        self.left = (kernel_size - 1) * dilation
        self.conv = nn.Conv1d(channels, channels, kernel_size, dilation=dilation)

    def forward(self, x):
        return self.conv(F.pad(x, (self.left, 0)))


class ResidualBlock(nn.Module):
    def __init__(self, channels, kernel_size, dilation, dropout):
        super().__init__()
        self.block = nn.Sequential(
            CausalConv(channels, kernel_size, dilation),
            nn.ReLU(),
            nn.Dropout(dropout),
            CausalConv(channels, kernel_size, dilation),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        return F.relu(x + self.block(x))


class InterestTCN(nn.Module):
    def __init__(self, input_size=215, channels=32, kernel_size=3, dilations=(1, 2, 4), dropout=0.2):
        super().__init__()
        self.projection = nn.Conv1d(input_size, channels, 1)
        self.blocks = nn.Sequential(*(ResidualBlock(channels, kernel_size, d, dropout) for d in dilations))
        self.head = nn.Sequential(nn.Linear(channels, 32), nn.ReLU(), nn.Dropout(dropout), nn.Linear(32, 1))
        self.receptive_field = 1 + 2 * (kernel_size - 1) * sum(dilations)

    def encode(self, x):
        return self.blocks(self.projection(x.transpose(1, 2)))

    def forward(self, x):
        return self.head(self.encode(x)[:, :, -1]).squeeze(-1)


def build_model(config):
    config = dict(config)
    kind = config.pop("kind")
    if kind == "gru":
        return InterestGRU(**config)
    if kind == "tcn":
        return InterestTCN(**config)
    if kind == "pooled_gru":
        return PooledInterestGRU(**config)
    if kind == "aggregate_logit":
        return AggregateLogit(**config)
    raise ValueError(f"Unknown architecture: {kind}")


def parameter_count(model):
    return sum(p.numel() for p in model.parameters())


class PooledFeatures(nn.Module):
    """Observed-player summaries, invariant to slot and team-code permutations.

    Undo saved per-slot scaling before pooling; otherwise slot-specific scaling
    would destroy permutation invariance. Missing players never become means.
    """
    width = 35

    def __init__(self, source_mean, source_scale):
        super().__init__()
        self.register_buffer('source_mean',torch.tensor(source_mean,dtype=torch.float32))
        self.register_buffer('source_scale',torch.tensor(source_scale,dtype=torch.float32))

    def forward(self,z):
        raw=z*self.source_scale+self.source_mean
        p=raw[...,:198].reshape(*raw.shape[:-1],22,9)
        visible=p[...,7]>.5
        mask=visible[...,None].expand(*visible.shape,7).clone()
        motion=visible.clone()
        motion[:,0]=False
        motion[:,1:] &= visible[:,:-1]
        motion &= (raw[...,208]<.5)[...,None]
        mask[...,2:4]=motion[...,None]
        values=p[...,:7]
        count=mask.sum(-2).clamp_min(1)
        mean=(values*mask).sum(-2)/count
        variance=((values-mean[...,None,:]).square()*mask).sum(-2)/count
        std=variance.clamp_min(0).sqrt()
        team0=((p[...,8]==0)&visible).float().mean(-1)
        team1=((p[...,8]==1)&visible).float().mean(-1)
        unknown=((p[...,8]==-1)&visible).float().mean(-1)
        teams=torch.stack([torch.minimum(team0,team1),torch.maximum(team0,team1),unknown],-1)
        return torch.cat([mean,std,visible.float().mean(-1,keepdim=True),teams,z[...,198:215]],-1)


class PooledInterestGRU(nn.Module):
    def __init__(self,source_mean,source_scale,input_size=215,hidden_size=16,dropout=.1):
        super().__init__()
        if input_size!=215: raise ValueError('Pooling requires the complete source schema')
        self.features=PooledFeatures(source_mean,source_scale)
        self.register_buffer('pool_mean',torch.zeros(35))
        self.register_buffer('pool_scale',torch.ones(35))
        self.gru=nn.GRU(35,hidden_size,batch_first=True)
        self.head=nn.Sequential(nn.Linear(hidden_size,16),nn.ReLU(),nn.Dropout(dropout),nn.Linear(16,1))

    def forward(self,x):
        features=(self.features(x)-self.pool_mean)/self.pool_scale
        _,h=self.gru(features)
        return self.head(h[-1]).squeeze(-1)


class AggregateLogit(nn.Module):
    def __init__(self,source_mean,source_scale,input_size=215):
        super().__init__()
        if input_size!=215: raise ValueError('Aggregate baseline requires full source schema')
        self.features=PooledFeatures(source_mean,source_scale)
        self.register_buffer('aggregate_mean',torch.zeros(210))
        self.register_buffer('aggregate_scale',torch.ones(210))
        self.linear=nn.Linear(210,1)

    def aggregate(self,x):
        f=self.features(x)
        return torch.cat([f.mean(1),f.std(1,unbiased=False),f.amin(1),f.amax(1),f[:,-1],f[:,-1]-f[:,0]],-1)

    def forward(self,x):
        return self.linear((self.aggregate(x)-self.aggregate_mean)/self.aggregate_scale).squeeze(-1)
