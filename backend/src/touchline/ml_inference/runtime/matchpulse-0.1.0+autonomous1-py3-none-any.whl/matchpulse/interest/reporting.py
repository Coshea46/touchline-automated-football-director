"""Measured study tables and presentation figures; no placeholder results."""

import csv
import json
from pathlib import Path

import numpy as np


def write_reports(output, validation, test, selection, training, benchmarks, labels_scores):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import precision_recall_curve

    output = Path(output)
    plots = output / "plots"
    plots.mkdir(exist_ok=True)
    names = list(validation)
    plt.rcParams.update({"figure.dpi": 150, "axes.grid": True, "grid.alpha": 0.2})
    rows, thresholds, latency = [], [], []
    for name in names:
        for split, results in (("valid", validation), ("test", test)):
            for budget, metrics in results[name]["operating_points"].items():
                row = {
                    "model": name,
                    "split": split,
                    "validation_budget_percent": budget,
                    "parameters": training[name]["parameters"],
                    "epochs": training[name]["epochs"],
                    "training_seconds": training[name]["training_seconds"],
                    "best_epoch": validation[name]["best_epoch"],
                    "validation_loss": validation[name]["validation_loss"],
                    **{k: v for k, v in metrics.items() if isinstance(v, (str, float, int)) or v is None},
                }
                rows.append(row)
                thresholds.append(
                    {
                        k: row[k]
                        for k in (
                            "model",
                            "split",
                            "validation_budget_percent",
                            "threshold",
                            "forwarding_fraction",
                            "event_recall",
                            "anticipated_events",
                            "qualifying_events",
                            "false_alerts_per_match_hour",
                        )
                    }
                )
        for measurement in benchmarks[name]["measurements"]:
            latency.append({"model": name, "parameters": training[name]["parameters"], **measurement})

    def table(path, records):
        fields = list(dict.fromkeys(k for r in records for k in r))
        with (output / path).open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(records)

    table("experiment-summary.csv", rows)
    table("threshold-comparison.csv", thresholds)
    table(
        "forwarding-costs.csv",
        [
            {
                k: row[k]
                for k in (
                    "model",
                    "split",
                    "validation_budget_percent",
                    "forwarding_fraction",
                    "window_forwarding_fraction",
                    "forwarded_windows",
                    "total_windows",
                    "forwarded_clip_union_seconds",
                    "eligible_clip_union_seconds",
                    "independent_clip_processing_seconds",
                    "additional_uncached_video_seconds",
                    "uncached_vs_unique_video_work_multiplier",
                    "overlap_reuse_savings_fraction",
                    "stage2_cost_note",
                )
            }
            for row in rows
        ],
    )
    table("latency-comparison.csv", latency)
    table(
        "audio-ablation.csv", [r for r in rows if r["model"] in (selection["stronger_gru"], "D_gru_no_audio")]
    )
    for key, filename, title in (
        ("train_loss", "training-loss", "Training weighted BCE"),
        ("validation_loss", "validation-loss", "Validation weighted BCE"),
    ):
        fig, ax = plt.subplots(figsize=(8, 4.5))
        for name in names:
            history = json.loads((output / "experiments" / name / "history.json").read_text())
            ax.plot([h["epoch"] for h in history], [h[key] for h in history], label=name)
        ax.set(xlabel="Epoch", ylabel="Weighted BCE", title=title)
        ax.legend()
        fig.tight_layout()
        fig.savefig(plots / f"{filename}.png")
        plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, split in zip(axes, ("valid", "test"), strict=True):
        for name in names:
            labels, scores = labels_scores[split][name]
            precision, recall, _ = precision_recall_curve(labels, scores)
            ax.plot(recall, precision, label=name)
        ax.set(xlabel="Window recall", ylabel="Window precision", title=split, xlim=(0, 1), ylim=(0, 1))
        ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(plots / "precision-recall.png")
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, split, results in zip(axes, ("valid", "test"), (validation, test), strict=True):
        for name in names:
            curve = results[name]["event_curve"]
            ax.plot(
                [100 * p["forwarding_fraction"] for p in curve],
                [p["event_recall"] for p in curve],
                label=name,
            )
        point = results[selection["preferred_model"]]["operating_points"]["20"]
        ax.scatter(
            [100 * point["forwarding_fraction"]],
            [point["event_recall"]],
            marker="*",
            s=170,
            color="black",
            zorder=5,
            label="Selected validation 20% operating point",
        )
        ax.set(
            xlabel="Eligible scored footage forwarded (%)",
            ylabel="Distinct event recall",
            title=split,
            ylim=(0, 1),
        )
        ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(plots / "event-recall-vs-forwarding.png")
    fig.savefig(plots / "event-recall-vs-forwarding.pdf")
    plt.close(fig)
    fig, axes = plt.subplots(2, len(names), figsize=(4 * len(names), 7), squeeze=False)
    for row_index, (split, results) in enumerate((("valid", validation), ("test", test))):
        for column, name in enumerate(names):
            matrix = np.asarray(results[name]["operating_points"]["20"]["confusion_matrix"])
            ax = axes[row_index, column]
            ax.imshow(matrix, cmap="Blues")
            for (i, j), value in np.ndenumerate(matrix):
                ax.text(j, i, str(value), ha="center", va="center")
            ax.set(
                title=f"{name} / {split}", xlabel="Predicted", ylabel="Actual", xticks=[0, 1], yticks=[0, 1]
            )
            ax.grid(False)
    fig.tight_layout()
    fig.savefig(plots / "confusion-matrices.png")
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, device in zip(axes, ("cpu", "cuda:0"), strict=True):
        for batch, offset in ((1, -0.2), (7, 0.2)):
            values = [
                next(
                    m["api_median_ms"]
                    for m in benchmarks[n]["measurements"]
                    if m["device"] == device and m["batch_size"] == batch
                )
                for n in names
            ]
            ax.bar(np.arange(len(names)) + offset, values, width=0.4, label=f"batch {batch}")
        ax.set(
            xticks=np.arange(len(names)),
            xticklabels=names,
            ylabel="Warm complete score API latency (ms)",
            title=device,
        )
        ax.tick_params(axis="x", rotation=20)
        ax.legend()
    fig.tight_layout()
    fig.savefig(plots / "inference-latency.png")
    plt.close(fig)
    preferred = validation[selection["preferred_model"]]["operating_points"]["20"]
    held_out = test[selection["preferred_model"]]["operating_points"]["20"]
    full_audio = selection["stronger_gru"]
    audio_comparison = {
        split: {n: results[n]["operating_points"]["20"] for n in (full_audio, "D_gru_no_audio")}
        for split, results in (("valid", validation), ("test", test))
    }
    (output / "audio-ablation.json").write_text(json.dumps(audio_comparison, indent=2) + "\n")
    text = f"""# MatchPulse Stage 1 measured results

Selected using validation only: **{selection["preferred_model"]}**, threshold **{selection["threshold"]:.8g}**.
Validation: {preferred["anticipated_events"]}/{preferred["qualifying_events"]} distinct events anticipated at {100 * preferred["forwarding_fraction"]:.2f}% eligible-footage forwarding.
Final held-out test: {held_out["anticipated_events"]}/{held_out["qualifying_events"]} distinct events anticipated at {100 * held_out["forwarding_fraction"]:.2f}% eligible-footage forwarding, using the unchanged validation threshold.

The primary presentation figure is `plots/event-recall-vs-forwarding.pdf`. Numerical metrics, threshold sweeps, predictions, training histories and latency tables accompany it.

All architectures, checkpoints and operating thresholds were frozen before test evaluation. A/B selection determined the parent for D, and all four comparisons used validation for model selection. Test comparisons are descriptive, with no retuning. This is one seed, not a statistical-significance study. Scores are uncalibrated.

Forwarding definition: `{selection["forwarding_mode"]}`. The default measures the union of selected five-second observation clips divided by the union of all eligible clips, counting overlapping footage once. The one-second decision-gate rate is reported separately. Ignored windows were excluded from supervised learning and have no predictions; gaps break alert episodes. Full-match alert rates are therefore lower bounds. Coverage and conditional event recall are reported alongside recall over all qualifying incident groups, including groups without eligible anticipation windows.

Goal/shot duplicates use original `evaluation_group_id` values and the earliest annotation timestamp within each group. An alert must occur 3–10 seconds before that timestamp. Consecutive positive one-second decisions in the same half form one episode; average warning uses the first qualifying alert for each successfully anticipated incident.

The suggested TCN has a 29-frame receptive field (two convolutions per block, dilations 1/2/4): it receives 75 timesteps but its final output uses the last 29. GRU classification uses the final recurrent hidden state after all 75 timesteps. This architecture difference is a limitation of the comparison.

Preprocessing uses training-only, per-channel masked z-scores. Visibility, confidence, team and availability codes remain unchanged. Missing coordinates remain zero after transformation; interpolated player positions are recognised by nonzero bounding-box sizes. Schema v1 lacks explicit interpolation/camera-reliability flags, so ball position validity uses visibility or nonzero position, and camera motion uses wide-view/non-cut intervals. Those validity approximations remain a limitation.

CPU measurements use one thread on the Kaggle host. CUDA events time model execution; synchronized wall time measures the full score API. Loading is reported separately, with CUDA already initialized. No GRU was trained on the laptop CPU, no YOLO was retrained, and original labels were not regenerated.
"""
    (output / "RESULTS.md").write_text(text, encoding="utf-8")
