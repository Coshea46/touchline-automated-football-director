"""Controlled CUDA experiments with exact batch-level optimizer/RNG resume."""

import math
import os
import random
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Subset

from matchpulse.batch.storage import atomic_json

from .checkpoint import atomic_checkpoint
from .data import NumericalDataset
from .models import build_model, parameter_count


class SessionCheckpoint(Exception):
    """Normal stop: current progress must be saved as a private Kaggle output."""


def set_seed(seed):
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)


def rng_state():
    state = np.random.get_state()
    return {
        "python": random.getstate(),
        "numpy": [state[0], state[1].tolist(), state[2], state[3], state[4]],
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
    }


def restore_rng(state):
    random.setstate(state["python"])
    n = state["numpy"]
    np.random.set_state((n[0], np.asarray(n[1], np.uint32), n[2], n[3], n[4]))
    torch.set_rng_state(state["torch"].cpu())
    if state["cuda"]:
        torch.cuda.set_rng_state_all([s.cpu() for s in state["cuda"]])


def make_loader(dataset, config, *, epoch=0, train=False, start_batch=0):
    generator = torch.Generator().manual_seed(config.seed + epoch)
    if train:
        order = torch.randperm(len(dataset), generator=generator).tolist()
        dataset = Subset(dataset, order[start_batch * config.batch_size :])
    # A dedicated generator keeps DataLoader worker seed generation out of the model's dropout RNG.
    return DataLoader(
        dataset,
        batch_size=config.batch_size,
        shuffle=False,
        num_workers=config.num_workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=False,
        generator=generator,
        drop_last=False,
    )


def predict_dataset(model, dataset, config, device, pos_weight):
    model.eval()
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(pos_weight, device=device))
    logits, labels, total, count = [], [], 0.0, 0
    with torch.inference_mode():
        for x, y in make_loader(dataset, config):
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            prediction = model(x)
            total += float(criterion(prediction, y)) * len(y)
            count += len(y)
            logits.append(prediction.cpu())
            labels.append(y.cpu())
    if count != len(dataset):
        raise ValueError("Evaluation silently lost samples")
    return torch.cat(logits).sigmoid().numpy(), torch.cat(labels).numpy().astype(np.int64), total / count


def train_experiment(name, experiment, config, cache_root, output, audit, *, deadline, device="cuda:0"):
    if not torch.cuda.is_available() or torch.device(device).type != "cuda":
        raise RuntimeError("Actual CUDA training is required; laptop/CPU training fallback is disabled")
    directory = Path(output) / "experiments" / name
    directory.mkdir(parents=True, exist_ok=True)
    identity = {"experiment": experiment, "study": config.to_dict(), "audit": audit["audit_sha256"]}
    # JSON canonicalisation makes tuple/list representations agree after checkpoint deserialisation.
    import json

    identity = json.loads(json.dumps(identity))
    complete_path, resume_path = directory / "training-complete.json", directory / "resume.pt"
    if complete_path.exists():
        value = json.loads(complete_path.read_text())
        if value["identity"] != identity:
            raise ValueError("Completed experiment configuration or dataset changed")
        return directory / "best.pt"
    set_seed(config.seed)
    model = build_model(experiment["model"]).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay
    )
    train = NumericalDataset(cache_root, "train", experiment["model"]["input_size"])
    valid = NumericalDataset(cache_root, "valid", experiment["model"]["input_size"])
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(audit["pos_weight"], device=device))
    state = {
        "identity": identity,
        "epoch": 0,
        "next_batch": 0,
        "best_loss": math.inf,
        "bad_epochs": 0,
        "history": [],
        "accumulator": {
            "loss": 0.0,
            "samples": 0,
            "gradient_norm_sum": 0.0,
            "gradient_norm_max": 0.0,
            "batches": 0,
            "clipped_batches": 0,
        },
        "training_seconds": 0.0,
    }
    if resume_path.exists():
        state = torch.load(resume_path, map_location="cpu", weights_only=True)
        if state["identity"] != identity:
            raise ValueError("Resume dataset/configuration mismatch")
        model.load_state_dict(state.pop("model"))
        optimizer.load_state_dict(state.pop("optimizer"))
        restore_rng(state.pop("rng"))
    started = time.perf_counter()
    previous_seconds = state["training_seconds"]

    def checkpoint():
        state["training_seconds"] = previous_seconds + time.perf_counter() - started
        atomic_checkpoint(
            resume_path,
            {**state, "model": model.state_dict(), "optimizer": optimizer.state_dict(), "rng": rng_state()},
        )

    while state["epoch"] < config.max_epochs and state["bad_epochs"] < config.patience:
        model.train()
        epoch = state["epoch"]
        accumulator = state["accumulator"]
        start_batch = state["next_batch"]
        for batch_index, (x, y) in enumerate(
            make_loader(train, config, epoch=epoch, train=True, start_batch=start_batch), start=start_batch
        ):
            if time.perf_counter() >= deadline:
                checkpoint()
                raise SessionCheckpoint(f"{name}: committed epoch {epoch + 1}, next batch {batch_index}")
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            loss = criterion(logits, y)
            if not torch.isfinite(loss):
                raise FloatingPointError(
                    "Non-finite training loss; no model substitution or automatic retuning"
                )
            loss.backward()
            if experiment["clip_norm"] is not None:
                norm = torch.nn.utils.clip_grad_norm_(
                    model.parameters(), max_norm=experiment["clip_norm"], error_if_nonfinite=True
                )
            else:
                norm = torch.stack(
                    [p.grad.detach().norm(2) for p in model.parameters() if p.grad is not None]
                ).norm(2)
            norm = float(norm)
            if not math.isfinite(norm):
                raise FloatingPointError("Non-finite gradient norm")
            optimizer.step()
            accumulator["loss"] += float(loss.detach()) * len(y)
            accumulator["samples"] += len(y)
            accumulator["gradient_norm_sum"] += norm
            accumulator["gradient_norm_max"] = max(accumulator["gradient_norm_max"], norm)
            accumulator["batches"] += 1
            accumulator["clipped_batches"] += (
                experiment["clip_norm"] is not None and norm > experiment["clip_norm"]
            )
            state["next_batch"] = batch_index + 1
            if state["next_batch"] % config.checkpoint_batches == 0:
                checkpoint()
        if accumulator["samples"] != len(train):
            raise ValueError("Epoch lost or duplicated training samples during resume")
        if time.perf_counter() >= deadline:
            checkpoint()
            raise SessionCheckpoint(f"{name}: training epoch complete; validation deferred")
        _, _, validation_loss = predict_dataset(model, valid, config, device, audit["pos_weight"])
        if not math.isfinite(validation_loss):
            raise FloatingPointError("Non-finite validation loss")
        record = {
            "epoch": epoch + 1,
            "train_loss": accumulator["loss"] / len(train),
            "validation_loss": validation_loss,
            "mean_gradient_norm": accumulator["gradient_norm_sum"] / accumulator["batches"],
            "max_gradient_norm": accumulator["gradient_norm_max"],
            "clipped_batch_fraction": accumulator["clipped_batches"] / accumulator["batches"],
        }
        state["history"].append(record)
        if validation_loss < state["best_loss"] - config.min_delta:
            state["best_loss"], state["bad_epochs"] = validation_loss, 0
            atomic_checkpoint(
                directory / "best.pt",
                {
                    "identity": identity,
                    "architecture": experiment["model"],
                    "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
                    "epoch": epoch + 1,
                    "validation_loss": validation_loss,
                    "parameters": parameter_count(model),
                },
            )
        else:
            state["bad_epochs"] += 1
        state["epoch"], state["next_batch"] = epoch + 1, 0
        state["accumulator"] = dict.fromkeys(state["accumulator"], 0)
        checkpoint()
        atomic_json(directory / "history.json", state["history"])
        print(
            f"{name} epoch {epoch + 1}: train={record['train_loss']:.6f} valid={validation_loss:.6f}",
            flush=True,
        )
    atomic_json(
        complete_path,
        {
            "identity": identity,
            "epochs": state["epoch"],
            "best_validation_loss": state["best_loss"],
            "training_seconds": state["training_seconds"],
            "parameters": parameter_count(model),
        },
    )
    return directory / "best.pt"
