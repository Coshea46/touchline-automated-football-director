"""Versioned, immutable training/inference feature contract."""

from enum import IntEnum

import numpy as np

from .config import SAMPLE_FPS, load_clip_duration, validate_duration

SCHEMA_VERSION = "matchpulse-215-v1"
FPS = SAMPLE_FPS
SLOTS = 22
PLAYER_WIDTH = 9
FEATURES = 215
PLAYERS = slice(0, 198)
BALL = slice(198, 205)
CAMERA = slice(205, 210)
AUDIO = slice(210, 215)


def sampling_timestamps(duration_seconds=None):
    """Interval centres, including a partial final interval for fractional seconds."""
    duration = load_clip_duration() if duration_seconds is None else validate_duration(duration_seconds)
    steps = int(np.ceil(duration * FPS - 1e-9))
    starts = np.arange(steps, dtype=np.float64) / FPS
    return (starts + np.minimum(starts + 1 / FPS, duration)) / 2


# Compatibility snapshots of the packaged defaults; extraction uses instance grids.
DURATION = load_clip_duration()
TIMESTAMPS = sampling_timestamps(DURATION)
STEPS = len(TIMESTAMPS)
TIMESTAMPS.flags.writeable = False
MISSING_DISTANCE = 0.0  # validity requires ball position AND at least one visible player


class Player(IntEnum):
    X = 0
    Y = 1
    VX = 2
    VY = 3
    WIDTH = 4
    HEIGHT = 5
    CONFIDENCE = 6
    VISIBLE = 7
    TEAM = 8


class Ball(IntEnum):
    X = 0
    Y = 1
    VX = 2
    VY = 3
    CONFIDENCE = 4
    VISIBLE = 5
    NEAREST_PLAYER_DISTANCE = 6


class Camera(IntEnum):
    PITCH_COVERAGE = 0
    DX = 1
    DY = 2
    CUT = 3
    WIDE_VIEW = 4


PLAYER_NAMES = ("x", "y", "vx", "vy", "width", "height", "confidence", "visible", "team")
BALL_NAMES = ("x", "y", "vx", "vy", "confidence", "visible", "nearest_player_distance")
CAMERA_NAMES = ("pitch_coverage", "camera_dx", "camera_dy", "camera_cut", "wide_view")
AUDIO_NAMES = ("log_rms", "rms_delta", "spectral_flux", "spectral_centroid", "audio_available")
FEATURE_NAMES = (
    tuple(f"player_{s + 1}.{n}" for s in range(SLOTS) for n in PLAYER_NAMES)
    + tuple(f"ball.{n}" for n in BALL_NAMES)
    + CAMERA_NAMES
    + AUDIO_NAMES
)


def validate(features: np.ndarray, *, steps=None) -> None:
    steps = len(sampling_timestamps()) if steps is None else steps
    if features.shape != (steps, FEATURES) or features.dtype != np.float32:
        raise ValueError(f"Features must have shape ({steps}, 215) and dtype float32")
    if not np.isfinite(features).all():
        raise ValueError("Non-finite extracted features")
    p = features[:, PLAYERS].reshape(steps, SLOTS, PLAYER_WIDTH)
    for a in (
        p[..., [0, 1, 4, 5, 6, 7]],
        features[:, 198:200],
        features[:, 202:205],
        features[:, [205, 208, 209, 214]],
    ):
        if np.any((a < 0) | (a > 1)):
            raise ValueError("Position, size, confidence or indicator out of range")
    if not np.isin(p[..., Player.TEAM], [-1, 0, 1]).all():
        raise ValueError("Invalid team encoding")
    if not all(
        np.isin(a, [0, 1]).all()
        for a in (p[..., Player.VISIBLE], features[:, 203], features[:, 208:210], features[:, 214])
    ):
        raise ValueError("Visibility and availability indicators must be binary")
