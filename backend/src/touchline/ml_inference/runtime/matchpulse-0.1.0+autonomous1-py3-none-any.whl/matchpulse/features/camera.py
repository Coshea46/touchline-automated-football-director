"""Background optical flow + robust affine motion and multi-signal hard cuts."""

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class CameraObservation:
    dx: float = 0.0
    dy: float = 0.0
    cut: bool = False
    affine: np.ndarray | None = None  # normalized coordinate transform previous -> current
    reliable: bool = False


class CameraEstimator:
    def __init__(self, width=480):
        self.width = width
        self.previous = None

    def update(self, rgb, timestamp, pitch, detections):
        h, w = rgb.shape[:2]
        size = (min(w, self.width), max(16, round(h * min(w, self.width) / w)))
        small = cv2.resize(rgb, size)
        gray = cv2.cvtColor(small, cv2.COLOR_RGB2GRAY)
        hsv = cv2.cvtColor(small, cv2.COLOR_RGB2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [24, 16], [0, 180, 0, 256])
        cv2.normalize(hist, hist, norm_type=cv2.NORM_L1)
        mask = np.full(gray.shape, 255, np.uint8)
        for detection in detections:
            x1, y1, x2, y2 = detection.xyxy
            x1, x2 = int(x1 * size[0] / w), int(x2 * size[0] / w)
            y1, y2 = int(y1 * size[1] / h), int(y2 * size[1] / h)
            cv2.rectangle(mask, (max(0, x1 - 4), max(0, y1 - 4)), (x2 + 4, y2 + 4), 0, -1)
        result = CameraObservation(affine=np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]))
        if self.previous is not None:
            prev_gray, prev_hist, prev_mask, prev_pitch, prev_t = self.previous
            dt = timestamp - prev_t
            points = cv2.goodFeaturesToTrack(prev_gray, 180, 0.015, 8, mask=prev_mask)
            affine = None
            match_ratio = 0.0
            if points is not None and len(points) >= 6:
                moved, status, _ = cv2.calcOpticalFlowPyrLK(
                    prev_gray, gray, points, None, winSize=(21, 21), maxLevel=3
                )
                back, back_status, _ = cv2.calcOpticalFlowPyrLK(
                    gray, prev_gray, moved, None, winSize=(21, 21), maxLevel=3
                )
                good = status.ravel().astype(bool) & back_status.ravel().astype(bool)
                good &= np.linalg.norm(points - back, axis=2).ravel() < 1.5
                good &= np.isfinite(moved).all(axis=(1, 2))
                valid = moved[:, 0]
                good &= (valid[:, 0] >= 0) & (valid[:, 0] < size[0])
                good &= (valid[:, 1] >= 0) & (valid[:, 1] < size[1])
                if good.sum() >= 6:
                    affine, inliers = cv2.estimateAffinePartial2D(
                        points[good], moved[good], method=cv2.RANSAC, ransacReprojThreshold=2.5
                    )
                    match_ratio = float(inliers.sum() / len(points)) if inliers is not None else 0
            hist_change = cv2.compareHist(prev_hist, hist, cv2.HISTCMP_BHATTACHARYYA)
            pixel_change = float(np.mean(cv2.absdiff(prev_gray, gray))) / 255
            coverage_change = abs(pitch.coverage - prev_pitch)
            # Histograms alone fail for switches between two green pitch views.
            cut = (
                (hist_change > 0.6 and (match_ratio < 0.35 or coverage_change > 0.3))
                or (match_ratio < 0.08 and pixel_change > 0.19)
                or (coverage_change > 0.55 and match_ratio < 0.18)
            )
            result.cut = bool(cut)
            if not cut and affine is not None and match_ratio >= 0.25 and dt > 1e-9:
                scale = np.hypot(affine[0, 0], affine[1, 0])
                if 0.8 <= scale <= 1.25:
                    normal = affine.copy()
                    normal[0, 1] *= size[1] / size[0]
                    normal[1, 0] *= size[0] / size[1]
                    normal[:, 2] /= np.array(size)
                    # Camera velocity describes movement of the frame centre (includes zoom/rotation).
                    movement = normal @ np.array([0.5, 0.5, 1.0]) - 0.5
                    result.dx, result.dy = movement / dt
                    result.affine, result.reliable = normal, True
        self.previous = (gray, hist, mask, pitch.coverage, timestamp)
        return result
