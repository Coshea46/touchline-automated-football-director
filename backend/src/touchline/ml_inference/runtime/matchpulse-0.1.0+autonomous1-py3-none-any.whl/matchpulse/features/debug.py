"""Optional annotated MP4 export. No source audio is copied to debug videos."""

from pathlib import Path

import cv2
import numpy as np

from .schema import BALL, CAMERA, FPS, PLAYER_WIDTH, PLAYERS, SLOTS, Ball, Camera, Player


def write_debug_video(path, frames, features, diagnostics):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    h, w = frames[0].shape[:2]
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), FPS, (w, h))
    if not writer.isOpened():
        raise RuntimeError(f"Cannot open debug video writer: {path}")
    trajectory = []
    try:
        for i, rgb in enumerate(frames):
            camera = features[i, CAMERA]
            ball = features[i, BALL]
            image = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            region = diagnostics["pitch_regions"][i]
            mask = cv2.resize(region.mask, (w, h), interpolation=cv2.INTER_NEAREST) > 0
            image[mask] = (0.8 * image[mask] + 0.2 * np.array([0, 200, 0])).astype(np.uint8)
            for d in diagnostics["raw_detections"][i]:
                x1, y1, x2, y2 = map(int, d.xyxy)
                cv2.rectangle(image, (x1, y1), (x2, y2), (130, 130, 130), 1)
            for detection, reason in diagnostics["excluded"][i]:
                x1, y1, x2, y2 = map(int, detection.xyxy)
                cv2.rectangle(image, (x1, y1), (x2, y2), (90, 90, 230), 1)
                cv2.putText(
                    image, reason, (x1, max(12, y1 - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (90, 90, 230), 1
                )
            players = features[i, PLAYERS].reshape(SLOTS, PLAYER_WIDTH)
            for slot, player in enumerate(players):
                if not diagnostics["player_valid"][i, slot]:
                    continue
                x, y, _, _, bw, bh, confidence, visible, team = player
                colour = (255, 170, 30) if team == -1 else (30, 100, 255) if team == 1 else (220, 220, 220)
                foot = (round(x * w), round(y * h))
                box = (round((x - bw / 2) * w), round((y - bh) * h), round((x + bw / 2) * w), foot[1])
                cv2.rectangle(image, box[:2], box[2:], colour, 2 if visible else 1)
                label = (
                    f"slot{slot + 1} id{diagnostics['slot_ids'][i, slot]} team{team:+.0f} {confidence:.2f}"
                )
                if not visible:
                    label += " INTERP"
                cv2.putText(
                    image, label, (box[0], max(12, box[1] - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.35, colour, 1
                )
            if camera[Camera.CUT]:
                trajectory = []
            if diagnostics["ball_valid"][i]:
                bx, by = ball[:2]
                point = (round(bx * w), round(by * h))
                trajectory.append(point)
                cv2.circle(image, point, 5, (0, 255, 255), 2 if ball[Ball.VISIBLE] else 1)
                if diagnostics["ball_interpolated"][i]:
                    cv2.putText(image, "BALL INTERP", point, cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 255), 1)
                if len(trajectory) > 1:
                    cv2.polylines(image, [np.array(trajectory[-20:])], False, (0, 255, 255), 1)
            else:
                trajectory = []
            timestamp = diagnostics["timestamps"][i]
            text = f"t={timestamp:.3f}s pitch={camera[Camera.PITCH_COVERAGE]:.2f} wide={camera[Camera.WIDE_VIEW]:.0f}"
            if camera[Camera.CUT]:
                text += " CAMERA CUT"
            if not diagnostics["camera_reliable"][i]:
                text += " motion uncertain"
            if players[:, Player.VISIBLE].sum() < 4 or not camera[Camera.WIDE_VIEW]:
                text += " tracking uncertain"
            cv2.putText(image, text, (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.43, (255, 255, 255), 1)
            writer.write(image)
    finally:
        writer.release()
    if not path.exists() or path.stat().st_size == 0:
        raise RuntimeError("Debug video export failed")
