"""Bounded, thread safe LRU; keys must include source identity and model configuration."""

from collections import OrderedDict
from threading import RLock

import numpy as np


class BoundedCache:
    def __init__(self, capacity=300, max_bytes=256 * 1024 * 1024):
        self.capacity, self.max_bytes = capacity, max_bytes
        self._items = OrderedDict()
        self._bytes = 0
        self._lock = RLock()
        self.hits = self.misses = 0

    def get(self, key):
        with self._lock:
            item = self._items.get(key)
            if item is None:
                self.misses += 1
                return None
            self._items.move_to_end(key)
            self.hits += 1
            return item[0]

    def put(self, key, value):
        size = value.nbytes if isinstance(value, np.ndarray) else 256 + len(value) * 64
        with self._lock:
            old = self._items.pop(key, None)
            if old:
                self._bytes -= old[1]
            if self.capacity == 0 or size > self.max_bytes:
                return
            self._items[key] = (value, size)
            self._bytes += size
            while len(self._items) > self.capacity or self._bytes > self.max_bytes:
                _, (_, n) = self._items.popitem(last=False)
                self._bytes -= n

    def clear(self):
        with self._lock:
            self._items.clear()
            self._bytes = 0
