"""Stateless detection interface; one YOLO can serve many stream workers."""

from collections.abc import Sequence
from concurrent.futures import Future
from dataclasses import dataclass
from queue import Empty, Queue
from threading import RLock, Thread
from time import monotonic
from typing import Protocol

import numpy as np

from .config import DetectorConfig


@dataclass(frozen=True)
class Detection:
    xyxy: tuple[float, float, float, float]
    confidence: float
    kind: str  # 'person' or 'ball'; independent of fine-tuned model class IDs

    def __post_init__(self):
        if self.kind not in ("person", "ball") or not np.isfinite((*self.xyxy, self.confidence)).all():
            raise ValueError("Invalid detection")
        if not 0 <= self.confidence <= 1 or self.xyxy[2] <= self.xyxy[0] or self.xyxy[3] <= self.xyxy[1]:
            raise ValueError("Invalid detection box/confidence")


class Detector(Protocol):
    def detect(self, frames: Sequence[np.ndarray]) -> list[list[Detection]]: ...


class YoloDetector:
    def __init__(self, config: DetectorConfig | None = None):
        from ultralytics import YOLO

        self.config = config or DetectorConfig()
        self._lock = RLock()
        self.model = YOLO(self.config.weights, task="detect")
        if self.model.task != "detect":
            raise ValueError("MatchPulse requires detection weights, not a pose model")
        names = self.model.names
        if self.config.person_class not in names or self.config.ball_class not in names:
            raise ValueError("Configured person/ball class IDs do not exist in the model")

    def detect(self, frames):
        if not frames:
            return []
        cfg, output = self.config, []
        from ultralytics.cfg import DEFAULT_CFG_DICT

        precision = (
            {"quantize": 16 if cfg.half else 32} if "quantize" in DEFAULT_CFG_DICT else {"half": cfg.half}
        )
        with self._lock:
            for offset in range(0, len(frames), cfg.batch_size):
                batch = frames[offset : offset + cfg.batch_size]
                real_count = len(batch)
                if cfg.device != "cpu" and real_count < cfg.batch_size:
                    # Keep CUDA tensor shapes stable at clip/checkpoint boundaries.
                    # Artificial black images avoid inferring any sampled frame twice.
                    batch = list(batch) + [
                        np.zeros_like(batch[-1]) for _ in range(cfg.batch_size - real_count)
                    ]
                bgr = [np.ascontiguousarray(f[..., ::-1]) for f in batch]
                results = self.model.predict(
                    source=bgr,
                    imgsz=cfg.image_size,
                    device=cfg.device,
                    **precision,
                    conf=min(cfg.confidence, cfg.ball_confidence),
                    batch=len(batch),
                    classes=[cfg.person_class, cfg.ball_class],
                    verbose=False,
                )
                if len(results) != len(batch):
                    raise RuntimeError("YOLO returned a different number of results than frames")
                for result in results[:real_count]:
                    detections = []
                    # One transfer per frame; cache never holds GPU tensors or tracking IDs.
                    for x1, y1, x2, y2, confidence, cls in result.boxes.data.detach().cpu().numpy():
                        kind = "person" if int(cls) == cfg.person_class else "ball"
                        threshold = cfg.confidence if kind == "person" else cfg.ball_confidence
                        if confidence >= threshold:
                            detections.append(
                                Detection(tuple(map(float, (x1, y1, x2, y2))), float(confidence), kind)
                            )
                    output.append(detections)
        return output


class SharedBatchDetector:
    """Queue concurrent stream calls into one detector batch; contains no identities.

    Use as a context manager around seven worker extractors. Closing drains queued
    requests. Mixed resolutions are allowed by YOLO's letterboxing. Backpressure
    is bounded by queue_capacity, and exceptions propagate to every affected caller.
    """

    def __init__(self, detector: Detector, max_batch=32, max_wait=0.005, queue_capacity=600):
        if max_batch < 1 or max_wait < 0 or queue_capacity < 1:
            raise ValueError("Invalid shared batch settings")
        self.detector = detector
        self.max_batch, self.max_wait = max_batch, max_wait
        self._queue = Queue(maxsize=queue_capacity)
        self._closed = False
        self._submit_lock = RLock()
        self._thread = Thread(target=self._run, name="matchpulse-detector", daemon=True)
        self._thread.start()

    def detect(self, frames):
        futures = []
        with self._submit_lock:
            if self._closed:
                raise RuntimeError("Shared detector is closed")
            for frame in frames:
                future = Future()
                self._queue.put((frame, future))
                futures.append(future)
        return [f.result() for f in futures]

    def _run(self):
        stopping = False
        while not stopping:
            first = self._queue.get()
            if first is None:
                break
            batch = [first]
            deadline = monotonic() + self.max_wait
            while len(batch) < self.max_batch:
                try:
                    item = self._queue.get(timeout=max(0, deadline - monotonic()))
                except Empty:
                    break
                if item is None:
                    stopping = True
                    break
                batch.append(item)
            try:
                result = self.detector.detect([f for f, _ in batch])
                if len(result) != len(batch):
                    raise RuntimeError("Shared detector result count mismatch")
                for (_, future), detections in zip(batch, result, strict=True):
                    future.set_result(detections)
            except Exception as exc:
                for _, future in batch:
                    future.set_exception(exc)

    def close(self):
        with self._submit_lock:
            if self._closed:
                return
            self._closed = True
            self._queue.put(None)
        self._thread.join()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
