"""Per-interval audio: dBFS/80, its delta, L2 positive flux, centroid/Nyquist.

No per-clip standardisation. Float PCM must be [-1,1]; integer PCM is scaled by
its dtype's full scale. Stereo uses channel RMS-equivalent power for energy and
mean channel magnitude spectra (avoids cancellation of antiphase channels).
"""

from math import gcd

import numpy as np
from scipy.signal import resample_poly

from .config import load_clip_duration, validate_duration
from .schema import FPS, sampling_timestamps

CANONICAL_SAMPLE_RATE = 16000


def audio_features(audio, sample_rate, *, allow_gaps=False, duration_seconds=None):
    duration = load_clip_duration() if duration_seconds is None else validate_duration(duration_seconds)
    steps = len(sampling_timestamps(duration))
    out = np.zeros((steps, 5), np.float32)
    if audio is None:
        if sample_rate is not None:
            raise ValueError("audio_sample_rate requires audio")
        return out
    if not isinstance(sample_rate, (int, np.integer)) or sample_rate < 1000:
        raise ValueError("Valid integer audio_sample_rate >=1000 required")
    data = np.asarray(audio)
    if data.ndim not in (1, 2) or (data.ndim == 2 and data.shape[1] not in (1, 2)):
        raise ValueError("Audio must be mono (samples,) or time-major (samples,1|2)")
    if len(data) < round(duration * sample_rate):
        raise ValueError(f"Supplied audio must cover the entire {duration:g}-second window")
    data = data[: round(duration * sample_rate)]
    if np.issubdtype(data.dtype, np.integer):
        info = np.iinfo(data.dtype)
        midpoint = (info.max + 1) / 2 if info.min == 0 else 0
        data = (data.astype(np.float64) - midpoint) / (midpoint or -info.min)
    elif not np.issubdtype(data.dtype, np.floating):
        raise ValueError("Audio must be integer or floating point PCM")
    data = data.astype(np.float64).reshape(len(data), -1)
    finite = np.isfinite(data)
    if (not allow_gaps and not finite.all()) or np.any(np.abs(data[finite]) > 1.00001):
        raise ValueError("Audio must be finite PCM within [-1,1]")
    # File audio is decoded at 16kHz. Apply the same bandwidth/frequency scale
    # to external waveforms, after endpoint cropping, to keep training and
    # inference comparable across source sample rates.
    if sample_rate != CANONICAL_SAMPLE_RATE:
        divisor = gcd(int(sample_rate), CANONICAL_SAMPLE_RATE)
        data = resample_poly(data, CANONICAL_SAMPLE_RATE // divisor, int(sample_rate) // divisor, axis=0)
        data = np.clip(data[: round(duration * CANONICAL_SAMPLE_RATE)], -1.0, 1.0)
        sample_rate = CANONICAL_SAMPLE_RATE
    previous_spectrum = previous_log = None
    for i in range(steps):
        a, b = round(i * sample_rate / FPS), min(len(data), round((i + 1) * sample_rate / FPS))
        chunk = data[a:b]
        if not len(chunk) or not np.isfinite(chunk).all():
            previous_spectrum = previous_log = None
            continue
        rms = np.sqrt(np.mean(chunk * chunk))
        log = max(-80.0, 20.0 * np.log10(max(rms, 1e-4))) / 80.0
        spec = np.abs(np.fft.rfft(chunk * np.hanning(len(chunk))[:, None], axis=0)).mean(axis=1)
        unit = spec / max(np.linalg.norm(spec), 1e-12)
        # Roundoff can give successive intervals different FFT lengths; fixed normalized bins.
        spectrum = np.interp(np.linspace(0, 1, 512), np.linspace(0, 1, len(unit)), unit)
        spectrum /= max(np.linalg.norm(spectrum), 1e-12)
        flux = (
            np.linalg.norm(np.maximum(0, spectrum - previous_spectrum))
            if previous_spectrum is not None
            else 0
        )
        centroid = np.dot(np.linspace(0, 1, len(spec)), spec) / max(spec.sum(), 1e-12)
        out[i] = [log, log - previous_log if previous_log is not None else 0, flux, centroid, 1]
        previous_log, previous_spectrum = log, spectrum
    return out
