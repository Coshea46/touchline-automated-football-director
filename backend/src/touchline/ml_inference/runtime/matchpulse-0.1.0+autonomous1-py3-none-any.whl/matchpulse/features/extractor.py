from dataclasses import dataclass
from functools import lru_cache
from hashlib import blake2b
from pathlib import Path
from threading import RLock
from time import perf_counter

import numpy as np

from .audio import audio_features
from .ball import BallTracker
from .cache import BoundedCache
from .config import DetectorConfig, ExtractorConfig
from .detector import YoloDetector
from .interpolation import interpolate, velocities
from .observations import FrameGeometry, VisualAnalyzer, initial_camera
from .schema import (
    AUDIO,
    BALL,
    CAMERA,
    FEATURES,
    PLAYER_WIDTH,
    PLAYERS,
    SLOTS,
    Ball,
    Player,
    sampling_timestamps,
    validate,
)
from .teams import TeamClassifier
from .tracking import PlayerTracker, assign_slots
from .video import from_array, from_file


@dataclass
class ExtractionResult:
    features: np.ndarray
    timings: dict[str, float]
    diagnostics: dict


class MatchFeatureExtractor:
    """Reusable configured-duration RGB video -> (ceil(15*n),215) float32 extractor.

    One extractor serializes its own calls. Independent workers should each own
    an extractor and share a YoloDetector or SharedBatchDetector. No clip tracking
    state survives extraction. Only immutable frames and raw detections are cached.
    last_result contains timings in seconds and feature validity/identity metadata.
    """

    def __init__(
        self,
        *,
        detector=None,
        detector_config: DetectorConfig | None = None,
        config: ExtractorConfig | None = None,
        config_path: str | Path | None = None,
    ):
        if config is not None and config_path is not None:
            raise ValueError("Provide config or config_path, not both")
        self.config = config if config is not None else ExtractorConfig.from_file(config_path)
        self.timestamps = sampling_timestamps(self.config.clip_duration_seconds)
        self.steps = len(self.timestamps)
        self.detector_config = detector_config or DetectorConfig()
        self.model_load_seconds = 0.0
        if detector is None:
            started = perf_counter()
            detector = YoloDetector(self.detector_config)
            self.model_load_seconds = perf_counter() - started
        self.detector = detector
        self._frames = BoundedCache(self.config.cache_frames * 2, self.config.cache_bytes)
        self._detections = BoundedCache(self.config.cache_frames, self.config.cache_bytes // 8)
        self._lock = RLock()
        self.last_result = None

    def clear_cache(self):
        with self._lock:
            self._frames.clear()
            self._detections.clear()

    def extract(
        self,
        video: str | Path | np.ndarray,
        *,
        fps=None,
        audio=None,
        audio_sample_rate=None,
        debug_video=None,
    ) -> np.ndarray:
        return self._extract(
            video, fps=fps, audio=audio, audio_sample_rate=audio_sample_rate, debug_video=debug_video
        )

    def extract_window(self, video: str | Path, start: float, *, debug_video=None) -> np.ndarray:
        """Read [start,start+n) using configured duration; overlapping windows reuse cache.

        start is seconds relative to the first video PTS. A one-second slide keeps
        the same sampling grid and reuses overlapping full-interval samples.
        """
        if not isinstance(video, (str, Path)):
            raise ValueError("extract_window requires a video file")
        return self._extract(video, start=start, debug_video=debug_video)

    def _extract(self, video, *, fps=None, audio=None, audio_sample_rate=None, start=None, debug_video=None):
        with self._lock:
            started = perf_counter()
            self.last_result = None
            timing = dict.fromkeys(
                (
                    "decode",
                    "detector",
                    "tracking",
                    "pitch_team",
                    "camera",
                    "audio",
                    "interpolation",
                    "assembly",
                    "debug",
                ),
                0.0,
            )
            t = perf_counter()
            if isinstance(video, np.ndarray):
                window = from_array(video, fps, duration_seconds=self.config.clip_duration_seconds)
            elif isinstance(video, (str, Path)):
                if fps is not None:
                    raise ValueError("fps is only accepted for NumPy video; files use PTS")
                window = from_file(
                    video, start=start, cache=self._frames, duration_seconds=self.config.clip_duration_seconds
                )
            else:
                raise TypeError("video must be a path or RGB NumPy array")
            timing["decode"] = perf_counter() - t
            # Explicit audio may override file audio, using the same window origin.
            if audio is not None:
                sound, rate, gaps = audio, audio_sample_rate, False
            else:
                if audio_sample_rate is not None:
                    raise ValueError("audio_sample_rate requires an explicit audio waveform")
                sound, rate, gaps = window.audio, window.audio_sample_rate, True
            t = perf_counter()
            audio_values = audio_features(
                sound, rate, allow_gaps=gaps, duration_seconds=self.config.clip_duration_seconds
            )
            timing["audio"] = perf_counter() - t
            t = perf_counter()
            keys = window.keys or [
                (frame.shape, blake2b(frame, digest_size=16).digest()) for frame in window.frames
            ]
            raw = [self._detections.get(k) for k in keys]
            missing = [i for i, detections in enumerate(raw) if detections is None]
            # De-duplicate repeated frames in low-FPS sources, without losing frame order.
            unique = {}
            for i in missing:
                unique.setdefault(keys[i], i)
            if unique:
                predictions = self.detector.detect([window.frames[i] for i in unique.values()])
                if len(predictions) != len(unique):
                    raise RuntimeError("Detector result count does not match input frame count")
                by_key = dict(zip(unique, predictions, strict=True))
                for i in missing:
                    raw[i] = tuple(by_key[keys[i]])
                    self._detections.put(keys[i], raw[i])
            timing["detector"] = perf_counter() - t
            output, diagnostics = self._assemble(window.frames, raw, window.source_timestamps, timing)
            output[:, AUDIO] = audio_values
            validate(output, steps=self.steps)
            diagnostics["timestamps"] = window.timestamps
            diagnostics["clip_duration_seconds"] = self.config.clip_duration_seconds
            diagnostics["source_timestamps"] = window.source_timestamps
            diagnostics["detector_cache_hits"] = self.steps - len(unique)
            diagnostics["detector_frames_inferred"] = len(unique)
            diagnostics["audio_available_intervals"] = int(audio_values[:, -1].sum())
            if debug_video is not None:
                from .debug import write_debug_video

                t = perf_counter()
                write_debug_video(debug_video, window.frames, output, diagnostics)
                timing["debug"] = perf_counter() - t
            timing["total"] = perf_counter() - started
            self.last_result = ExtractionResult(output, timing, diagnostics)
            return output

    def assemble_observations(self, observations, *, audio=None):
        """Replay cached image-independent data using the identical local feature builder.

        Observations must be exactly the configured, contiguous 15FPS window.
        No global track/team identities enter window-local inference.
        """
        if len(observations) != self.steps:
            raise ValueError(f"Expected {self.steps} cached observations")
        targets = np.array([o.timestamp for o in observations])
        start = targets[0] - self.timestamps[0]
        if not np.allclose(targets - start, self.timestamps, atol=1e-7, rtol=0):
            raise ValueError("Cached observation grid does not match this window")
        times = np.array([o.source_timestamp - start for o in observations])
        if np.any(times >= self.config.clip_duration_seconds):
            raise ValueError("Cached observation outside window endpoint")
        frames = [FrameGeometry(o.shape) for o in observations]
        raw = [o.detections for o in observations]
        timing = dict.fromkeys(("tracking", "pitch_team", "camera", "interpolation", "assembly"), 0.0)
        features, diagnostics = self._assemble(frames, raw, times, timing, observations=observations)
        if audio is not None:
            if audio.shape != (self.steps, 5) or not np.isfinite(audio).all():
                raise ValueError("Invalid cached window audio")
            features[:, AUDIO] = audio
        validate(features, steps=self.steps)
        diagnostics.update(
            timestamps=self.timestamps.copy(),
            source_timestamps=times,
            clip_duration_seconds=self.config.clip_duration_seconds,
            audio_available_intervals=int(features[:, AUDIO][:, -1].sum()),
            detector_frames_inferred=0,
            detector_cache_hits=self.steps,
        )
        self.last_result = ExtractionResult(features, timing, diagnostics)
        return features

    def _assemble(self, frames, raw, times, timing, *, observations=None):
        cfg = self.config
        steps = len(frames)
        out = np.zeros((steps, FEATURES), np.float32)
        t = perf_counter()
        tracker = PlayerTracker(cfg.tracker, cfg.max_gap, cfg.player_max_speed)
        timing["tracking"] += perf_counter() - t
        ball_tracker = BallTracker(cfg.max_gap, cfg.ball_max_speed)
        if observations is None:
            analyzer = VisualAnalyzer(cfg)
            observations = [
                analyzer.analyze(frame, detections, self.timestamps[i], times[i], timing)
                for i, (frame, detections) in enumerate(zip(frames, raw, strict=True))
            ]
        cameras, regions, excluded, tracked_frames = [], [], [], []
        segments = np.zeros(steps, np.int32)
        ball_ids = np.full(steps, -1, np.int32)
        segment = 0
        for i, (frame, observation) in enumerate(zip(frames, observations, strict=True)):
            region = observation.region
            regions.append(region)
            people, rejects = observation.people, list(observation.excluded)
            camera = initial_camera() if i == 0 else observation.camera
            cameras.append(camera)
            if camera.cut:
                segment += 1
            segments[i] = segment
            out[i, CAMERA] = [region.coverage, camera.dx, camera.dy, camera.cut, observation.wide]
            t = perf_counter()
            if camera.cut:
                tracker.reset(segment)
                ball_tracker.reset()
            assignments = tracker.update(
                frame,
                people,
                i,
                times[i],
                region.confidence >= 0.45,
                camera,
                times,
                colours=observation.colours,
            )
            assigned_detections = {id(d) for _, d in assignments}
            rejects.extend((d, "unconfirmed tracking") for d in people if id(d) not in assigned_detections)
            tracked_frames.append(assignments)
            ball = ball_tracker.update(observation.balls, times[i], frame.shape, camera)
            if ball is not None:
                point, confidence, identity = ball
                out[i, BALL] = [*point, 0, 0, confidence, 1, 0]
                ball_ids[i] = identity
            timing["tracking"] += perf_counter() - t
            excluded.append(rejects)
        t = perf_counter()
        teams = TeamClassifier()
        teams.fit([track.colours for track in tracker.tracks.values()])
        for track in tracker.tracks.values():
            track.team, track.official, track.team_reliability = teams.classify(track.colours)
        selected = assign_slots(list(tracker.tracks.values()), cfg.min_track_observations)
        timing["pitch_team"] += perf_counter() - t
        t = perf_counter()
        players = out[:, PLAYERS].reshape(steps, SLOTS, PLAYER_WIDTH)
        slot_ids = np.full((steps, SLOTS), -1, np.int32)
        for track in selected:
            if track.slot is None:
                continue
            shot = segments == track.key[0]
            players[shot, track.slot, Player.TEAM] = track.team
            slot_ids[shot, track.slot] = track.key[1]
            for observation in track.observations:
                i = observation.frame
                h, w = frames[i].shape[:2]
                x1, y1, x2, y2 = observation.detection.xyxy
                x1, x2 = np.clip([x1, x2], 0, w)
                y1, y2 = np.clip([y1, y2], 0, h)
                players[i, track.slot] = [
                    (x1 + x2) / (2 * w),
                    y2 / h,
                    0,
                    0,
                    (x2 - x1) / w,
                    (y2 - y1) / h,
                    observation.detection.confidence,
                    1,
                    track.team,
                ]
        for i, assignments in enumerate(tracked_frames):
            for key, detection in assignments:
                track = tracker.tracks[key]
                if track.official:
                    excluded[i].append((detection, "likely official/third kit"))
                elif track.slot is None:
                    excluded[i].append((detection, "unverified/slot limit"))
        timing["assembly"] += perf_counter() - t
        t = perf_counter()
        player_valid = np.zeros((steps, SLOTS), bool)
        player_interpolated = np.zeros_like(player_valid)
        for slot in range(SLOTS):
            # Position + size only, so interpolated confidence and visibility stay zero.
            values = players[:, slot][:, [Player.X, Player.Y, Player.WIDTH, Player.HEIGHT]].copy()
            observed = players[:, slot, Player.VISIBLE].astype(bool)
            valid, estimated = interpolate(
                values,
                observed,
                times,
                segments,
                max_gap=cfg.max_gap,
                identities=slot_ids[:, slot],
                reliable=players[:, slot, Player.CONFIDENCE] >= 0.2,
                max_speed=cfg.player_max_speed,
            )
            players[:, slot, Player.X : Player.VX] = values[:, :2]
            players[:, slot, Player.WIDTH : Player.CONFIDENCE] = values[:, 2:]
            players[:, slot, Player.VX : Player.WIDTH] = velocities(
                values[:, :2], valid, times, segments, cameras
            )
            player_valid[:, slot], player_interpolated[:, slot] = valid, estimated
        ball_values = out[:, BALL]
        h, w = frames[0].shape[:2]
        ball_valid, ball_interpolated = interpolate(
            ball_values[:, :2],
            ball_values[:, Ball.VISIBLE].astype(bool),
            times,
            segments,
            max_gap=cfg.max_gap,
            identities=ball_ids,
            reliable=ball_values[:, Ball.CONFIDENCE] >= 0.15,
            max_speed=cfg.ball_max_speed,
            distance_scale=np.array([w, h]) / np.hypot(w, h),
        )
        ball_values[:, Ball.VX : Ball.CONFIDENCE] = velocities(
            ball_values[:, :2], ball_valid, times, segments, cameras
        )
        timing["interpolation"] += perf_counter() - t
        t = perf_counter()
        for i in range(steps):
            visible = players[i, :, Player.VISIBLE].astype(bool)
            if ball_valid[i] and visible.any():
                h, w = frames[i].shape[:2]
                distance = (players[i, visible, :2] - ball_values[i, :2]) * [w, h]
                ball_values[i, Ball.NEAREST_PLAYER_DISTANCE] = np.linalg.norm(
                    distance, axis=1
                ).min() / np.hypot(w, h)
        timing["assembly"] += perf_counter() - t
        return out, {
            "segments": segments,
            "slot_ids": slot_ids,
            "player_valid": player_valid,
            "player_interpolated": player_interpolated,
            "ball_valid": ball_valid,
            "ball_interpolated": ball_interpolated,
            "pitch_regions": regions,
            "excluded": excluded,
            "raw_detections": raw,
            "tracks": tracker.tracks,
            "camera_reliable": np.array([c.reliable for c in cameras]),
            "warnings": [
                "Heuristic kit, ball and view accuracy require representative football validation; "
                "replays cannot be reliably identified from these features."
            ],
        }


_DEFAULT_LOCK = RLock()


@lru_cache(maxsize=1)
def _default_detector():
    return YoloDetector()


@lru_cache(maxsize=4)
def _default_extractor(config):
    # Config changes reuse the already loaded model, not a second YOLO copy.
    return MatchFeatureExtractor(config=config, detector=_default_detector())


def extract_match_features(
    video: str | Path | np.ndarray,
    *,
    fps=None,
    audio=None,
    audio_sample_rate=None,
    extractor: MatchFeatureExtractor | None = None,
    debug_video=None,
    config_path: str | Path | None = None,
) -> np.ndarray:
    """Return (ceil(15*n),215) float32 using n from matchpulse/config.toml.

    NumPy FPS may be omitted for exactly ceil(15*n) frames sampled at 15 FPS.

    Pass an extractor to configure GPU, weights or sharing. The convenience
    default is loaded once per process and uses CPU YOLO26s at 640 pixels.
    """
    if extractor is not None and config_path is not None:
        raise ValueError("Provide extractor or config_path, not both")
    if extractor is None:
        config = ExtractorConfig.from_file(config_path)
        with _DEFAULT_LOCK:
            extractor = _default_extractor(config)
    return extractor.extract(
        video, fps=fps, audio=audio, audio_sample_rate=audio_sample_rate, debug_video=debug_video
    )
