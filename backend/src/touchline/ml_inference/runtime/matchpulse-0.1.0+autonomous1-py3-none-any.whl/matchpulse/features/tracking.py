"""BoT-SORT/ByteTrack adapter; fresh lightweight state per window, reset per shot.

Only direct detection boxes enter features. Kalman predictions help association,
but are never mislabelled as direct measurements. Unsafe ID jumps form fragments.
"""

import inspect
from dataclasses import dataclass, field
from threading import RLock

import numpy as np

from .teams import jersey_colour

_TRACKER_LOCK = RLock()  # protects legacy Ultralytics global ID counters


class _SharedCameraMotion:
    """BoT-SORT GMC interface using the pipeline's robust background estimate."""

    method = "matchpulse-affine"

    def __init__(self):
        self.reset_params()

    def reset_params(self):
        self.warp = np.eye(2, 3)

    def apply(self, image, detections=None):
        return self.warp


@dataclass
class TrackObservation:
    frame: int
    detection: object
    colour: np.ndarray | None
    pitch_reliable: bool


@dataclass
class PlayerTrack:
    key: tuple[int, int]
    observations: list[TrackObservation] = field(default_factory=list)
    team: float = 0.0
    official: bool = False
    team_reliability: float = 0.0
    slot: int | None = None

    @property
    def colours(self):
        return [o.colour for o in self.observations if o.colour is not None]


class PlayerTracker:
    def __init__(self, kind="botsort", max_gap=5, max_speed=1.5):
        from ultralytics.trackers.bot_sort import BOTSORT
        from ultralytics.trackers.byte_tracker import BYTETracker
        from ultralytics.utils import YAML, IterableSimpleNamespace
        from ultralytics.utils.checks import check_yaml

        config = YAML.load(check_yaml(f"{kind}.yaml"))
        config.update(track_buffer=max_gap + 2, with_reid=False, gmc_method="sparseOptFlow")
        cls = BOTSORT if kind == "botsort" else BYTETracker
        kwargs = {"args": IterableSimpleNamespace(**config)}
        if "frame_rate" in inspect.signature(cls).parameters:
            kwargs["frame_rate"] = 15
        with _TRACKER_LOCK:
            self.tracker = cls(**kwargs)
        if kind == "botsort":
            self.tracker.gmc = _SharedCameraMotion()
        self._counter = 0
        self.max_speed, self.max_gap = max_speed, max_gap
        self.segment = 0
        self.tracks = {}
        self._raw_to_key = {}
        self._next_id = 0
        self._cameras = {}

    def reset(self, segment):
        with _TRACKER_LOCK:
            self.tracker.reset()
            if hasattr(self.tracker, "gmc"):
                self.tracker.gmc.reset_params()
        self.segment = segment
        self._raw_to_key.clear()
        self._counter = 0
        self._cameras.clear()

    def _project(self, point, first_frame, last_frame):
        point = np.asarray(point, dtype=float)
        for i in range(first_frame + 1, last_frame + 1):
            camera = self._cameras.get(i)
            if camera is not None and camera.reliable:
                point = camera.affine @ np.r_[point, 1.0]
        return point

    def _reassociate(self, detection, colour, frame_index, timestamp, shape, timestamps, reserved):
        if colour is None:
            return None
        h, w = shape[:2]
        current = np.array([(detection.xyxy[0] + detection.xyxy[2]) / (2 * w), detection.xyxy[3] / h])
        candidates = []
        for key, track in self.tracks.items():
            if key[0] != self.segment or key in reserved or len(track.observations) < 2:
                continue
            last = track.observations[-1]
            gap = frame_index - last.frame
            if not 1 <= gap <= self.max_gap + 1:
                continue
            colours = track.colours[-5:]
            if len(colours) < 2:
                continue
            appearance = np.linalg.norm(colour - np.median(colours, axis=0))
            if appearance > 0.13:
                continue
            a = last.detection.xyxy
            old = np.array([(a[0] + a[2]) / (2 * w), a[3] / h])
            predicted = self._project(old, last.frame, frame_index)
            previous = track.observations[-2]
            dt_previous = timestamps[last.frame] - timestamps[previous.frame]
            elapsed = timestamp - timestamps[last.frame]
            if dt_previous > 1e-9:
                b = previous.detection.xyxy
                before = np.array([(b[0] + b[2]) / (2 * w), b[3] / h])
                velocity = (old - self._project(before, previous.frame, last.frame)) / dt_previous
                if np.linalg.norm(velocity) < self.max_speed:
                    predicted += velocity * elapsed
            distance = np.linalg.norm(current - predicted)
            if distance <= 0.025 + 0.3 * elapsed:
                candidates.append((distance + 0.08 * appearance, key))
        candidates.sort()
        if not candidates or (len(candidates) > 1 and candidates[1][0] - candidates[0][0] < 0.02):
            return None
        return candidates[0][1]

    def update(
        self, rgb, detections, frame_index, timestamp, pitch_reliable, camera, timestamps, *, colours=None
    ):
        from ultralytics.engine.results import Boxes
        from ultralytics.trackers.basetrack import BaseTrack

        data = np.array([(*d.xyxy, d.confidence, 0) for d in detections], np.float32).reshape(-1, 6)
        boxes = Boxes(data, rgb.shape[:2])
        self._cameras[frame_index] = camera
        if hasattr(self.tracker, "gmc"):
            warp = np.eye(2, 3)
            if camera.reliable:
                h, w = rgb.shape[:2]
                warp = camera.affine.copy()
                warp[0, 1] *= w / h
                warp[1, 0] *= h / w
                warp[:, 2] *= [w, h]
            self.tracker.gmc.warp = warp
        with _TRACKER_LOCK:
            global_counter = BaseTrack._count
            BaseTrack._count = self._counter
            try:
                # GMC consumes only the supplied affine. ReID is disabled, so no
                # pixel operation or RGB->BGR copy is required in this adapter.
                rows = self.tracker.update(boxes, rgb)
                self._counter = BaseTrack._count
            finally:
                BaseTrack._count = global_counter
        assigned = []
        reserved = {self._raw_to_key.get(int(row[4])) for row in rows}
        h, w = rgb.shape[:2]
        for row in rows:
            raw_id, index = int(row[4]), int(row[-1])
            if index < 0 or index >= len(detections):
                raise RuntimeError("Tracker returned an invalid source-detection index")
            detection = detections[index]
            colour = jersey_colour(rgb, detection.xyxy) if colours is None else colours[detection]
            key = self._raw_to_key.get(raw_id)
            if key is not None:
                previous = self.tracks[key].observations[-1]
                a, b = previous.detection.xyxy, detection.xyxy
                old = np.array([(a[0] + a[2]) / (2 * w), a[3] / h])
                current = np.array([(b[0] + b[2]) / (2 * w), b[3] / h])
                gap = frame_index - previous.frame
                if gap == 1 and camera.reliable:
                    old = camera.affine @ np.r_[old, 1.0]
                dt = timestamp - timestamps[previous.frame]
                jump = np.linalg.norm(current - old) > self.max_speed * dt + 0.025
                appearance_jump = (
                    colour is not None
                    and previous.colour is not None
                    and np.linalg.norm(colour - previous.colour) > 0.30
                )
                if gap < 1 or gap > self.max_gap + 1 or jump or appearance_jump:
                    key = None
            if key is None:
                key = self._reassociate(
                    detection, colour, frame_index, timestamp, rgb.shape, timestamps, reserved
                )
                if key is None:
                    self._next_id += 1
                    key = (self.segment, self._next_id)
                    self.tracks[key] = PlayerTrack(key)
                self._raw_to_key[raw_id] = key
            reserved.add(key)
            observation = TrackObservation(frame_index, detection, colour, pitch_reliable)
            self.tracks[key].observations.append(observation)
            assigned.append((key, detection))
        return assigned


def assign_slots(tracks, min_observations=2):
    """Choose tracks over the entire completed shot, never recycle an absent slot.

    More than 22 total identities in a shot means lower-ranked tracks are omitted,
    even if they occur later. Whole-shot ranking is valid for completed windows.
    """
    eligible = [
        t
        for t in tracks
        if len(t.observations) >= min_observations
        and not t.official
        and (any(o.pitch_reliable for o in t.observations) or (t.team != 0 and len(t.observations) >= 3))
    ]
    by_segment = {}
    for track in eligible:
        by_segment.setdefault(track.key[0], []).append(track)
    for candidates in by_segment.values():
        ranked = sorted(
            candidates,
            key=lambda t: (
                -sum(o.pitch_reliable for o in t.observations),
                -(t.team != 0),
                -len(t.observations),
                -t.team_reliability,
                -np.mean([o.detection.confidence for o in t.observations]),
                t.key,
            ),
        )[:22]
        # Stable deterministic order; team evidence affects selection, not per-frame position sorting.
        ranked.sort(key=lambda t: (t.observations[0].frame, t.key))
        for slot, track in enumerate(ranked):
            track.slot = slot
    return eligible
