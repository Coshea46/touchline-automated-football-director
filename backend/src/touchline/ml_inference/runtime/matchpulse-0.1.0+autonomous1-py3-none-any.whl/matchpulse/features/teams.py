"""Conservative clip-wide jersey prototypes, with track-level temporal voting.

Unsupervised labels are temporary and cannot identify club names. A separated
third colour is only excluded as a likely official when two multi-player teams
have strong support. Goalkeepers with a third kit may also remain unknown.
"""

import cv2
import numpy as np


def jersey_colour(rgb, xyxy):
    h, w = rgb.shape[:2]
    x1, y1, x2, y2 = xyxy
    bw, bh = x2 - x1, y2 - y1
    crop = rgb[
        max(0, int(y1 + 0.18 * bh)) : min(h, int(y1 + 0.53 * bh)),
        max(0, int(x1 + 0.20 * bw)) : min(w, int(x2 - 0.20 * bw)),
    ]
    if crop.size < 24:
        return None
    hsv = cv2.cvtColor(crop, cv2.COLOR_RGB2HSV).reshape(-1, 3)
    lab = cv2.cvtColor(crop, cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(float) / 255
    # Jersey filtering is narrower than the pitch segmentation hue band:
    # yellow official/team shirts (OpenCV hue ~20-35) must retain evidence.
    keep = ~((hsv[:, 0] >= 38) & (hsv[:, 0] <= 95) & (hsv[:, 1] > 55) & (hsv[:, 2] < 200))
    if keep.sum() < 8:
        return None
    return np.median(lab[keep], axis=0)


class TeamClassifier:
    def __init__(self):
        self.centres = None

    def fit(self, track_colours):
        """One vote per persistent track, so a single referee cannot dominate by duration."""
        samples = np.array([np.median(c, axis=0) for c in track_colours if len(c) >= 2])
        if len(samples) < 4:
            return
        k = 3 if len(samples) >= 7 else 2
        centres = [samples[np.lexsort(samples.T[::-1])[0]]]
        for _ in range(k - 1):
            distances = np.min(np.linalg.norm(samples[:, None] - np.array(centres)[None], axis=2), axis=1)
            centres.append(samples[np.argmax(distances)])
        centres = np.array(centres)
        for _ in range(20):
            labels = np.argmin(np.linalg.norm(samples[:, None] - centres[None], axis=2), axis=1)
            new = np.array(
                [
                    np.median(samples[labels == j], axis=0) if np.any(labels == j) else centres[j]
                    for j in range(k)
                ]
            )
            if np.allclose(new, centres):
                break
            centres = new
        counts = np.bincount(labels, minlength=k)
        ranked = sorted(range(k), key=lambda j: (-counts[j], tuple(centres[j])))
        a, b = ranked[:2]
        if min(counts[a], counts[b]) < 2 or np.linalg.norm(centres[a] - centres[b]) < 0.16:
            return
        # Encode the lexicographically first colour as -1; never flip within clip.
        primary = sorted([centres[a], centres[b]], key=tuple)
        self.centres = np.array(primary)

    def classify(self, colours):
        if self.centres is None or not colours:
            return 0.0, False, 0.0
        colours = np.array(colours)
        distances = np.linalg.norm(colours[:, None] - self.centres[None], axis=2)
        nearest = np.argmin(distances, axis=1)
        median = np.median(distances, axis=0)
        best = int(np.argmin(median))
        margin = float(abs(median[0] - median[1]))
        agreement = np.mean(nearest == best)
        if median[best] < 0.16 and margin > 0.07 and agreement >= 0.75:
            return (-1.0 if best == 0 else 1.0), False, float(agreement)
        official = bool(
            len(colours) >= 3 and np.min(median) > 0.22 and np.max(np.std(colours, axis=0)) < 0.065
        )
        return 0.0, official, 0.0
