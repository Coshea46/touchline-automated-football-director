"""Ball-specific constant-velocity Kalman association with separate speed gates."""

import numpy as np


class BallTracker:
    def __init__(self, max_gap=5, max_speed=3.0):
        self.max_gap, self.max_speed = max_gap, max_speed
        self.identity = 0
        self.reset()

    def reset(self):
        self.state = self.covariance = None
        self.last_t = self.last_observed_t = None
        self.missing = 0

    def update(self, detections, timestamp, shape, camera):
        h, w = shape[:2]
        candidates = []
        for d in detections:
            x1, y1, x2, y2 = d.xyxy
            if (x2 - x1) / w > 0.08 or (y2 - y1) / h > 0.12:
                continue
            point = np.array([(x1 + x2) / (2 * w), (y1 + y2) / (2 * h)])
            if np.all((point >= 0) & (point <= 1)):
                candidates.append((d, point))
        if self.state is not None:
            dt = timestamp - self.last_t
            transition = np.eye(4)
            transition[0, 2] = transition[1, 3] = dt
            self.state = transition @ self.state
            self.covariance = transition @ self.covariance @ transition.T + np.diag(
                [0.0004, 0.0004, 0.03, 0.03]
            )
            if camera.reliable:
                self.state[:2] = camera.affine @ np.r_[self.state[:2], 1]
                self.state[2:] = camera.affine[:, :2] @ self.state[2:]
            scores = []
            for d, point in candidates:
                delta = point - self.state[:2]
                distance = np.linalg.norm(delta * np.array([w, h])) / np.hypot(w, h)
                if distance <= self.max_speed * (timestamp - self.last_observed_t) + 0.025:
                    mahalanobis = delta @ np.linalg.solve(self.covariance[:2, :2] + 0.001 * np.eye(2), delta)
                    if mahalanobis < 16:
                        scores.append((mahalanobis - 2 * d.confidence, d, point))
            scores.sort(key=lambda x: x[0])
            if len(scores) > 1 and scores[1][0] - scores[0][0] < 0.2:
                scores = []  # ambiguous observation: preserve missingness
            selected = (scores[0][1], scores[0][2]) if scores else None
        else:
            candidates.sort(key=lambda x: (-x[0].confidence, x[0].xyxy))
            selected = candidates[0] if candidates else None
            if len(candidates) > 1 and candidates[0][0].confidence - candidates[1][0].confidence < 0.1:
                selected = None
        self.last_t = timestamp
        if selected is None:
            self.missing += 1
            if self.missing > self.max_gap:
                self.reset()
            return None
        detection, point = selected
        if self.state is None:
            self.identity += 1
            self.state = np.r_[point, 0.0, 0.0]
            self.covariance = np.diag([0.001, 0.001, 1.0, 1.0])
        else:
            observation = np.eye(2, 4)
            noise = np.eye(2) * (0.0001 / max(detection.confidence, 0.05))
            innovation = point - observation @ self.state
            gain = np.linalg.solve(
                observation @ self.covariance @ observation.T + noise, observation @ self.covariance
            ).T
            self.state += gain @ innovation
            self.covariance = (np.eye(4) - gain @ observation) @ self.covariance
        self.missing = 0
        self.last_observed_t = timestamp
        return point, detection.confidence, self.identity
