from dataclasses import dataclass
from functools import cached_property

import cv2
import numpy as np


@dataclass
class PitchRegion:
    mask: np.ndarray
    confidence: float
    coverage: float
    scale: float

    @cached_property
    def contours(self):
        contours, _ = cv2.findContours(self.mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        return contours

    def proximity(self, xyxy, tolerance=0.025):
        """Signed distance in analysis pixels, positive inside pitch."""
        x1, _, x2, y2 = xyxy
        foot = ((x1 + x2) * 0.5 * self.scale, y2 * self.scale)
        if not self.contours:
            return False
        distance = max(cv2.pointPolygonTest(c, foot, True) for c in self.contours)
        return distance >= -tolerance * np.hypot(*self.mask.shape)


class PitchSegmenter:
    def __init__(self, width=480):
        self.width = width

    def analyse(self, rgb):
        h, w = rgb.shape[:2]
        scale = min(1.0, self.width / w)
        small = cv2.resize(rgb, (round(w * scale), round(h * scale)))
        hsv = cv2.cvtColor(small, cv2.COLOR_RGB2HSV)
        grass = cv2.inRange(hsv, (28, 35, 25), (95, 255, 255))
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
        clean = cv2.morphologyEx(grass, cv2.MORPH_CLOSE, kernel)
        clean = cv2.morphologyEx(clean, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        count, labels, stats, _ = cv2.connectedComponentsWithStats(clean)
        mask = np.zeros_like(clean)
        confidence = 0.0
        if count > 1:
            candidates = []
            for i in range(1, count):
                x, y, bw, bh, area = stats[i]
                fraction = area / mask.size
                if fraction >= 0.06 and bw >= mask.shape[1] * 0.35 and bh >= mask.shape[0] * 0.18:
                    candidates.append((area, i))
            if candidates:
                _, index = max(candidates)
                component = np.uint8(labels == index) * 255
                points = cv2.findNonZero(component)
                hull = cv2.convexHull(points)
                cv2.fillConvexPoly(mask, hull, 255)
                solidity = stats[index, cv2.CC_STAT_AREA] / max(np.count_nonzero(mask), 1)
                coverage = np.count_nonzero(mask) / mask.size
                confidence = float(np.clip(solidity * min(1, coverage / 0.35), 0, 1))
        coverage = float(np.count_nonzero(mask) / mask.size)
        return PitchRegion(mask, confidence, coverage, scale)


def geometric_player(detection, shape):
    h, w = shape[:2]
    x1, y1, x2, y2 = detection.xyxy
    bw, bh = (x2 - x1) / w, (y2 - y1) / h
    aspect = (x2 - x1) / max(y2 - y1, 1)
    return 0.015 <= bh <= 0.48 and 0.002 <= bw <= 0.22 and 0.12 <= aspect <= 1.3 and y2 > 0.12 * h


def wide_view(region, detections, shape):
    heights = [(d.xyxy[3] - d.xyxy[1]) / shape[0] for d in detections]
    return bool(
        region.confidence >= 0.45
        and region.coverage >= 0.28
        and len(heights) >= 4
        and np.median(heights) < 0.24
    )
