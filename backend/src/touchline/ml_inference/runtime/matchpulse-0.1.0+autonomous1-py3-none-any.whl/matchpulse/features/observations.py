"""Image-dependent observations reusable by local and dataset extraction.

No team decisions or interpolation are computed here: those are window-local.
"""

from dataclasses import dataclass
from time import perf_counter

import numpy as np

from .camera import CameraEstimator, CameraObservation
from .pitch import PitchRegion, PitchSegmenter, geometric_player, wide_view
from .teams import jersey_colour


@dataclass
class FrameGeometry:
    """Image dimensions for tracking; external GMC and cached colours need no pixels."""

    shape: tuple


@dataclass
class VisualObservation:
    timestamp: float
    source_timestamp: float
    shape: tuple
    detections: tuple
    people: tuple
    balls: tuple
    colours: dict
    excluded: list
    region: PitchRegion
    camera: CameraObservation
    wide: bool


def initial_camera():
    return CameraObservation(affine=np.eye(2, 3))


class VisualAnalyzer:
    def __init__(self, config):
        self.config = config
        self.pitch = PitchSegmenter(config.analysis_width)
        self.camera = CameraEstimator(config.analysis_width)

    def analyze(self, rgb, detections, timestamp, source_timestamp, timings):
        t = perf_counter()
        region = self.pitch.analyse(rgb)
        people, excluded = [], []
        for detection in detections:
            if detection.kind != "person":
                continue
            if not geometric_player(detection, rgb.shape):
                excluded.append((detection, "geometry/closeup"))
            elif region.confidence >= 0.45 and not region.proximity(
                detection.xyxy, self.config.touchline_tolerance
            ):
                excluded.append((detection, "outside pitch"))
            else:
                people.append(detection)
        people.sort(key=lambda d: d.xyxy)
        colours = {d: jersey_colour(rgb, d.xyxy) for d in people}
        wide = wide_view(region, people, rgb.shape)
        balls = tuple(
            d
            for d in detections
            if d.kind == "ball" and (region.confidence < 0.45 or region.proximity(d.xyxy, 0.15))
        )
        timings["pitch_team"] += perf_counter() - t
        t = perf_counter()
        camera = self.camera.update(rgb, source_timestamp, region, detections)
        timings["camera"] += perf_counter() - t
        return VisualObservation(
            float(timestamp),
            float(source_timestamp),
            tuple(rgb.shape),
            tuple(detections),
            tuple(people),
            balls,
            colours,
            excluded,
            region,
            camera,
            wide,
        )
