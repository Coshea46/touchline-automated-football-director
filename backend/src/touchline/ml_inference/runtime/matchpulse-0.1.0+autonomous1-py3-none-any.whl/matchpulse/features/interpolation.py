import numpy as np


def interpolate(
    values,
    observed,
    timestamps,
    segments,
    *,
    max_gap=5,
    identities=None,
    reliable=None,
    max_speed=1.5,
    distance_scale=(1.0, 1.0),
):
    """Fill bounded internal gaps, returning position validity and interpolation flags.

    values is (T,D), first two columns are normalized position. No confidence or
    visibility columns are modified. Identity and shot boundary checks include
    both endpoints. Boundary missingness is never extrapolated.
    """
    valid = observed.copy()
    estimated = np.zeros(len(values), dtype=bool)
    reliable = observed if reliable is None else reliable
    endpoints = np.flatnonzero(observed)
    for left, right in zip(endpoints[:-1], endpoints[1:]):
        gap = right - left - 1
        if not 1 <= gap <= max_gap or not (reliable[left] and reliable[right]):
            continue
        if np.any(segments[left : right + 1] != segments[left]):
            continue
        if identities is not None and identities[left] != identities[right]:
            continue
        dt = timestamps[right] - timestamps[left]
        if dt <= 1e-9:
            continue
        if np.linalg.norm((values[right, :2] - values[left, :2]) * distance_scale) > max_speed * dt + 0.025:
            continue
        weight = ((timestamps[left + 1 : right] - timestamps[left]) / dt)[:, None]
        values[left + 1 : right] = values[left] * (1 - weight) + values[right] * weight
        valid[left + 1 : right] = estimated[left + 1 : right] = True
    return valid, estimated


def velocities(positions, valid, timestamps, segments, cameras):
    out = np.zeros_like(positions, dtype=np.float32)
    for i in range(1, len(positions)):
        if (
            valid[i]
            and valid[i - 1]
            and segments[i] == segments[i - 1]
            and timestamps[i] - timestamps[i - 1] > 1e-9
        ):
            previous = positions[i - 1]
            if cameras[i].reliable:
                previous = cameras[i].affine @ np.r_[previous, 1]
            out[i] = (positions[i] - previous) / (timestamps[i] - timestamps[i - 1])
    return out
