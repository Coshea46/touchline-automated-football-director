import math
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

SAMPLE_FPS = 15
DEFAULT_CONFIG_PATH = Path(__file__).resolve().parents[1] / "config.toml"


def validate_duration(value):
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value < 1 / SAMPLE_FPS
    ):
        raise ValueError("clip_duration_seconds must be finite and at least 1/15 second")
    return float(value)


def load_clip_duration(path: str | Path | None = None) -> float:
    """Read the packaged config independently of the caller's working directory."""
    source = Path(path) if path is not None else DEFAULT_CONFIG_PATH
    with source.open("rb") as handle:
        settings = tomllib.load(handle)
    try:
        value = settings["features"]["clip_duration_seconds"]
    except (KeyError, TypeError) as exc:
        raise ValueError(f"{source} must define [features].clip_duration_seconds") from exc
    return validate_duration(value)


@dataclass(frozen=True)
class DetectorConfig:
    weights: str = "yolo26s.pt"
    device: str = "cpu"
    image_size: int = 640
    confidence: float = 0.15
    ball_confidence: float = 0.08
    batch_size: int = 16
    half: bool = False
    person_class: int = 0
    ball_class: int = 32

    def __post_init__(self):
        if self.image_size < 32 or self.batch_size < 1:
            raise ValueError("image_size >= 32 and batch_size >= 1 required")
        if not all(math.isfinite(v) and 0 <= v <= 1 for v in (self.confidence, self.ball_confidence)):
            raise ValueError("Confidence thresholds must lie in [0,1]")
        if self.half and self.device.lower() == "cpu":
            raise ValueError("half precision requires a supported accelerator")


@dataclass(frozen=True)
class ExtractorConfig:
    clip_duration_seconds: float = field(default_factory=load_clip_duration)
    tracker: str = "botsort"
    max_gap: int = 5
    touchline_tolerance: float = 0.025
    min_track_observations: int = 2
    analysis_width: int = 480
    cache_frames: int = 300
    cache_bytes: int = 512 * 1024 * 1024
    ball_max_speed: float = 3.0  # image diagonals / second
    player_max_speed: float = 1.5

    def __post_init__(self):
        validate_duration(self.clip_duration_seconds)
        if self.tracker not in ("botsort", "bytetrack"):
            raise ValueError("tracker must be botsort or bytetrack")
        if not 0 <= self.max_gap <= 15 or self.min_track_observations < 1:
            raise ValueError("Invalid gap or observation threshold")
        if self.analysis_width < 64 or self.cache_frames < 0 or self.cache_bytes < 0:
            raise ValueError("Invalid analysis size or cache bounds")
        if not 0 <= self.touchline_tolerance <= 0.2:
            raise ValueError("Invalid touchline tolerance")
        if not all(math.isfinite(v) and v > 0 for v in (self.ball_max_speed, self.player_max_speed)):
            raise ValueError("Speed gates must be positive and finite")

    @classmethod
    def from_file(cls, path: str | Path | None = None, **overrides):
        return cls(clip_duration_seconds=load_clip_duration(path), **overrides)
