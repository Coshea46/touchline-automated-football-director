"""Online counterpart of the frozen causal score policies in ``replay.py``.

The only inputs are synchronized, completed five-second observation scores and
their half-local endpoints. Call ``step`` once at endpoints 5,7,9,..., including
unavailable scores as None/NaN. A decision is selected before any current scores
enter history. No annotations, labels, future predictions, or wall-clock time
are accepted. The caller applies the returned decision at its availability time.
"""

from collections import deque
from collections.abc import Mapping
from dataclasses import asdict, dataclass

import numpy as np

DIRECTOR_VERSION = "matchpulse-online-director-v1"
REPLAY_VERSION = "matchpulse-director-replay-v1"


@dataclass(frozen=True)
class DirectorConfig:
    observation_seconds: float = 5.0
    decision_stride_seconds: float = 2.0
    staying_bonus_logit: float = 0.25
    adaptive_history_seconds: float = 300.0
    adaptive_warmup_seconds: float = 30.0
    prediction_latency_seconds: float = 0.0

    def __post_init__(self):
        if not np.isfinite(list(asdict(self).values())).all():
            raise ValueError("Director configuration must be finite")
        if self.observation_seconds != 5 or self.decision_stride_seconds != 2:
            raise ValueError("This policy requires five-second observations and two-second decisions")
        if self.staying_bonus_logit < 0 or self.prediction_latency_seconds < 0:
            raise ValueError("Bonus and prediction latency must be nonnegative")
        if not 0 <= self.adaptive_warmup_seconds <= self.adaptive_history_seconds or self.adaptive_history_seconds <= 0:
            raise ValueError("Invalid causal adaptive-history duration")


@dataclass(frozen=True)
class DirectorDecision:
    half: int
    prediction_endpoint_seconds: float
    prediction_available_seconds: float
    selected_match: str
    switched: bool
    complete_score_support: bool
    match_ids: tuple[str, ...]
    utilities: tuple[float | None, ...]
    centering_logits: tuple[float, ...]
    history_counts: tuple[int, ...]

    def to_dict(self):
        """JSON-safe decision; diagnostic vectors follow the explicit match order."""
        return asdict(self)


class OnlineDirector:
    """One policy/model and a fixed set of simultaneous independent matches.

    ``policy`` is exactly ``score`` (raw) or ``score_centered``. Match identifiers
    sort lexically, which also resolves exact utility ties. A half transition
    resets both histories and the selection to ``initial_match`` (lexical first
    by default). For a new playback of the same half, explicitly ``reset_half``.

    An incomplete step holds the current choice. Individual finite scores still
    enter their respective histories, exactly as in replay. ``supported=False``
    additionally reproduces replay's common support across multiple models.
    All match keys must be present; skipped/duplicate/out-of-order endpoints are
    rejected rather than silently inflating warmup or changing the policy clock.
    This runtime hold behavior does not replace evaluation's full-grid gate.
    Instances are stateful: serialize calls within one director session.
    """

    def __init__(self, match_ids, *, policy="score_centered", config=None, initial_match=None):
        matches = tuple(match_ids)
        if (not matches or any(not isinstance(m, str) or not m for m in matches)
                or len(set(matches)) != len(matches)):
            raise ValueError("Distinct nonempty string match IDs are required")
        if policy not in ("score", "score_centered"):
            raise ValueError("Policy must be score or score_centered")
        self.match_ids = tuple(sorted(matches))
        self.policy = policy
        self.config = config if config is not None else DirectorConfig()
        if not isinstance(self.config, DirectorConfig):
            raise TypeError("config must be a DirectorConfig")
        self.initial_match = self.match_ids[0] if initial_match is None else initial_match
        if self.initial_match not in self.match_ids:
            raise ValueError("Initial match must belong to this director")
        self._half = None
        self._current = self.initial_match
        self._last_endpoint = None
        self._history = {m: deque() for m in self.match_ids}

    @property
    def current_match(self):
        return self._current

    def reset_half(self, half):
        """Start an explicit new half/session; discard all previous policy state."""
        self._validate_half(half)
        self._half = int(half)
        self._current = self.initial_match
        self._last_endpoint = None
        self._history = {m: deque() for m in self.match_ids}

    @staticmethod
    def _validate_half(half):
        if isinstance(half, (bool, np.bool_)) or not isinstance(half, (int, np.integer)) or half not in (1, 2):
            raise ValueError("half must be integer 1 or 2")

    def step(self, *, half, prediction_endpoint_seconds, scores, supported=True):
        """Select, then commit this endpoint's scores; return a frozen decision.

        ``scores`` maps every original match ID to a scalar probability in [0,1],
        or None/NaN for unavailable. Infinities and unknown/missing keys fail.
        Endpoints must start at 5s and advance by exactly 2s within a half.
        ``prediction_latency_seconds`` only reports when the choice may take
        effect: it never shifts the input observation or history endpoints.
        """
        self._validate_half(half)
        if not isinstance(supported, (bool, np.bool_)):
            raise TypeError("supported must be boolean")
        if not isinstance(scores, Mapping) or set(scores) != set(self.match_ids):
            raise ValueError("scores must contain exactly this director's match IDs")
        try:
            values = np.asarray([np.nan if scores[m] is None else scores[m] for m in self.match_ids], dtype=np.float64)
            endpoint = float(prediction_endpoint_seconds)
        except (TypeError, ValueError) as exc:
            raise ValueError("Endpoint and scores must be numeric scalars") from exc
        if values.shape != (len(self.match_ids),) or not np.isfinite(endpoint):
            raise ValueError("Endpoint and scores must be numeric scalars")
        finite = np.isfinite(values)
        if np.isinf(values).any() or np.any((values[finite] < 0) | (values[finite] > 1)):
            raise ValueError("Scores must be probabilities in [0,1] or unavailable")
        new_half = self._half is None or half != self._half
        if self._half is not None and half < self._half:
            raise ValueError("Old half received; explicitly reset_half for a new playback")
        expected = (self.config.observation_seconds if new_half or self._last_endpoint is None
                    else self._last_endpoint + self.config.decision_stride_seconds)
        if endpoint != expected:
            raise ValueError(f"Expected endpoint {expected:g}; submit unavailable scores for missing decisions")
        # Validation precedes mutation, so rejected calls cannot corrupt state.
        if new_half:
            self.reset_half(half)
        cutoff = endpoint - self.config.adaptive_history_seconds
        counts, baselines = [], []
        for match in self.match_ids:
            history = self._history[match]
            while history and history[0][0] < cutoff:
                history.popleft()
            counts.append(len(history))
            baseline = 0.0
            if (self.policy == "score_centered" and history
                    and len(history) * self.config.decision_stride_seconds >= self.config.adaptive_warmup_seconds):
                previous = np.clip(np.asarray([v for _, v in history], dtype=np.float64), 1e-7, 1 - 1e-7)
                baseline = float(np.median(np.log(previous) - np.log1p(-previous)))
            baselines.append(baseline)
        complete = bool(supported and finite.all())
        chosen = self._current
        utilities = (None,) * len(self.match_ids)
        if complete:
            q = np.clip(values, 1e-7, 1 - 1e-7)
            utility = np.log(q) - np.log1p(-q)
            utility -= np.asarray(baselines, dtype=np.float64)
            utility[self.match_ids.index(self._current)] += self.config.staying_bonus_logit
            chosen = self.match_ids[int(np.argmax(utility))]
            utilities = tuple(float(v) for v in utility)
        decision = DirectorDecision(int(half), endpoint, endpoint + self.config.prediction_latency_seconds,
            chosen, chosen != self._current, complete, self.match_ids, utilities, tuple(baselines), tuple(counts))
        # Commit follows query/selection, including finite scores on held steps.
        for match, value in zip(self.match_ids, values, strict=True):
            if np.isfinite(value):
                self._history[match].append((endpoint, float(value)))
        self._current = chosen
        self._last_endpoint = endpoint
        return decision

    def to_schema(self):
        """Portable JSON configuration; runtime histories are deliberately not serialized."""
        return {"version": DIRECTOR_VERSION, "replay_version": REPLAY_VERSION, "policy": self.policy,
            "match_ids": list(self.match_ids), "initial_match": self.initial_match, "config": asdict(self.config)}

    @classmethod
    def from_schema(cls, schema):
        if (not isinstance(schema, dict) or set(schema) != {
                "version", "replay_version", "policy", "match_ids", "initial_match", "config"}
                or schema["version"] != DIRECTOR_VERSION or schema["replay_version"] != REPLAY_VERSION):
            raise ValueError("Unsupported director schema")
        return cls(schema["match_ids"], policy=schema["policy"], initial_match=schema["initial_match"],
            config=DirectorConfig(**schema["config"]))
