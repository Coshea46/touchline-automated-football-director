"""Portable binary classifiers over an explicit, versioned descriptor matrix.

This contract is deliberately separate from the raw (75,215) tabular runtime.
The caller supplies descriptors in the saved ordered schema. Causal PCM/image
builders and any fitted PCA are separate artifacts described by builder_metadata;
this classifier never guesses a feature builder or accepts raw observation cubes.
"""

import hashlib
import io
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .tabular import _estimator_arrays, _load_arrays, _predict_numerical, _threshold, _validate_numerical

VERSION = "matchpulse-descriptor-classifier-v1"
SCHEMA_VERSION = "matchpulse-descriptor-schema-v1"


@dataclass(frozen=True, init=False)
class DescriptorSchema:
    names: tuple[str, ...]
    version: str
    _builder_json: str

    def __init__(self, names, version, builder_metadata):
        if isinstance(names, str):
            raise ValueError("Descriptor names must be an ordered sequence, not a string")
        try:
            names = tuple(names)
        except TypeError as exc:
            raise ValueError("Descriptor names must be an ordered sequence") from exc
        if not names or any(not isinstance(name, str) or not name or name.strip() != name for name in names):
            raise ValueError("Descriptor names must be nonempty strings without surrounding whitespace")
        if len(set(names)) != len(names):
            raise ValueError("Descriptor names must be unique")
        if not isinstance(version, str) or not version or version.strip() != version:
            raise ValueError("A nonempty exact descriptor version is required")
        if not isinstance(builder_metadata, dict):
            raise ValueError("Explicit descriptor builder metadata must be a JSON object")
        try:
            frozen = json.dumps(builder_metadata, sort_keys=True, separators=(",", ":"), allow_nan=False)
        except (ValueError, TypeError) as exc:
            raise ValueError("Builder metadata must contain finite JSON values") from exc
        object.__setattr__(self, "names", names)
        object.__setattr__(self, "version", version)
        object.__setattr__(self, "_builder_json", frozen)

    @property
    def width(self):
        return len(self.names)

    @property
    def builder_metadata(self):
        # Independent copy: callers cannot silently mutate an exported schema.
        return json.loads(self._builder_json)

    def to_dict(self):
        return {"schema_version": SCHEMA_VERSION, "version": self.version, "feature_names": list(self.names),
                "input_dtype": "float32", "input_shape": ["batch", self.width], "builder_metadata": self.builder_metadata}

    @classmethod
    def from_dict(cls, metadata):
        try:
            schema = cls(metadata["feature_names"], metadata["version"], metadata["builder_metadata"])
        except (KeyError, TypeError) as exc:
            raise ValueError("Incomplete descriptor schema") from exc
        if metadata != schema.to_dict():
            raise ValueError("Descriptor schema/version/input contract mismatch")
        return schema


def _validate_config(config, arrays, schema):
    if not isinstance(config, dict) or config.get("version") != VERSION:
        raise ValueError("Unsupported descriptor classifier version")
    if config.get("input_shape") != ["batch", schema.width] or config.get("input_dtype") != "float32":
        raise ValueError("Descriptor classifier matrix input contract changed")
    if "raw_input_shape" in config or "raw_input_dtype" in config or "representation" in config:
        raise ValueError("Descriptor classifier cannot claim the raw215 observation contract")
    if config.get("classes") != [0, 1] or config.get("positive_label") != 1:
        raise ValueError("Descriptor classifier requires binary classes [0,1]")
    if config.get("threshold_comparator") != ">=":
        raise ValueError("Descriptor classifier requires score >= threshold comparison")
    _threshold(config.get("metadata"))
    _validate_numerical(config.get("architecture"), arrays, expected_width=schema.width)


def export_descriptor_estimator(directory, estimator, *, schema, metadata, scaler=None):
    """Save binary numeric weights/scaling and a separate exact builder contract.

    PCA or other learned feature construction belongs to separate builder files;
    their schema and SHA references should be provided in schema.builder_metadata.
    The optional scaler is the classifier's fitted StandardScaler, training only.
    """
    if not isinstance(schema, DescriptorSchema):
        raise ValueError("An explicit DescriptorSchema is required")
    architecture, arrays = _estimator_arrays(estimator, scaler=scaler)
    config = {
        "version": VERSION, "descriptor_schema": schema.to_dict(), "architecture": architecture,
        "classes": [0, 1], "positive_label": 1, "threshold_comparator": ">=",
        "input_shape": ["batch", schema.width], "input_dtype": "float32", "metadata": metadata,
        "numeric_precision": "float64 normalization and binary decision computation from float32 descriptors",
        "score_semantics": "Uncalibrated interest ranking score; sigmoid of binary decision logit/margin",
    }
    _validate_config(config, arrays, schema)
    buffer = io.BytesIO()
    np.savez_compressed(buffer, **arrays)
    payload = buffer.getvalue()
    config["weights_sha256"] = hashlib.sha256(payload).hexdigest()
    text = json.dumps(config, indent=2, allow_nan=False) + "\n"
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    (directory / "weights.npz").write_bytes(payload)
    (directory / "model.json").write_text(text, encoding="utf-8")
    return directory


class DescriptorClassifier:
    def __init__(self, directory):
        directory = Path(directory)
        self.config = json.loads((directory / "model.json").read_text(encoding="utf-8"))
        if not isinstance(self.config, dict) or self.config.get("version") != VERSION:
            raise ValueError("Unsupported descriptor classifier version")
        try:
            self.schema = DescriptorSchema.from_dict(self.config["descriptor_schema"])
        except (KeyError, TypeError) as exc:
            raise ValueError("Incomplete descriptor classifier schema") from exc
        self.arrays = _load_arrays(directory, self.config)
        _validate_config(self.config, self.arrays, self.schema)
        self.architecture = self.config["architecture"]
        self.metadata = self.config["metadata"]
        self.threshold = _threshold(self.metadata)
        for array in self.arrays.values():
            array.flags.writeable = False

    def predict_descriptors(self, descriptors, *, feature_names=None):
        matrix = np.asarray(descriptors)
        if matrix.ndim != 2 or matrix.shape[1] != self.schema.width or matrix.dtype != np.float32:
            raise ValueError(f"Expected float32 [batch,{self.schema.width}] descriptor matrix")
        if feature_names is not None and tuple(feature_names) != self.schema.names:
            raise ValueError("Descriptor feature names/order disagree with saved schema")
        return _predict_numerical(matrix, self.architecture, self.arrays)

    def predict_batch(self, descriptors, *, feature_names=None):
        return self.predict_descriptors(descriptors, feature_names=feature_names)

    def predict(self, descriptor, *, feature_names=None):
        vector = np.asarray(descriptor)
        if vector.ndim != 1:
            raise ValueError("Expected one float32 descriptor vector")
        return float(self.predict_descriptors(vector[None], feature_names=feature_names)[0])


def load_descriptor_classifier(directory):
    return DescriptorClassifier(directory)
