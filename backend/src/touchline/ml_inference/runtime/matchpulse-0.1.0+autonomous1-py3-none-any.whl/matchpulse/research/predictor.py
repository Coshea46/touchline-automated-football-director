"""Explicit selected-model composition without training, decoding or service code.

Release callers must supply the independently recorded manifest SHA. Numerical
weights, PCA and executable audio/image helpers are verified against that sealed
manifest before use. Helpers are supplied by the release, never downloaded.
History queries are read-only: score first, then explicitly commit fixed-grid
observations. Each instance owns its own history; serialize same-stream calls.
"""

import hashlib
import importlib.util
import json
import sys
from dataclasses import dataclass, replace
from numbers import Integral
from pathlib import Path

import numpy as np

from . import history, representation
from .core_audio import AudioInput, repair_core_audio
from .descriptor_classifier import VERSION as DESCRIPTOR_VERSION
from .descriptor_classifier import load_descriptor_classifier
from .representation import InvariantRepresentation
from .tabular import VERSION as TABULAR_VERSION
from .tabular import load_research_classifier, sigmoid

VERSION = "matchpulse-selected-predictor-v1"
ENSEMBLE_VERSION = "matchpulse-multimodal-equal-logit-ensemble-v1"
TEMPORAL_VERSION = "matchpulse-temporal-threehead-v1"


def file_sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _verified(path, expected):
    path = Path(path).resolve()
    if (not isinstance(expected, str) or len(expected) != 64 or not path.is_file()
            or file_sha(path) != expected):
        raise ValueError("Required artifact/source SHA-256 mismatch: " + str(path))
    return path


def _contained(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Artifact path escapes the explicit release root")
    return path


def _helper(path, expected):
    """Load only an explicitly supplied, SHA-verified non-training builder."""
    path = _verified(path, expected)
    name = "_matchpulse_verified_builder_" + expected
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, path)
        if spec is None or spec.loader is None:
            raise ValueError("Cannot load verified builder")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        try:
            spec.loader.exec_module(module)
        except BaseException:
            sys.modules.pop(name, None)
            raise
    return sys.modules[name]


@dataclass(frozen=True)
class ImageInput:
    """Online float32 encoder outputs; runtime reproduces cached float16 quantization."""
    embeddings: np.ndarray
    target_seconds: np.ndarray
    source_seconds: np.ndarray
    encoder_weights_sha256: str


@dataclass(frozen=True)
class Observation:
    match_id: str
    half: int
    endpoint_seconds: float
    raw215: np.ndarray | None = None
    audio: AudioInput | None = None
    image: ImageInput | None = None

    def __post_init__(self):
        if not isinstance(self.match_id, str) or not self.match_id:
            raise ValueError("Original match ID required")
        if isinstance(self.half, bool) or not isinstance(self.half, Integral) or self.half not in (1, 2):
            raise ValueError("Original half 1 or 2 required")
        if not np.isfinite(self.endpoint_seconds) or self.endpoint_seconds < 5:
            raise ValueError("Finite endpoint of a completed five-second observation required")


def with_core_audio(observation):
    """Explicit copy/repair; existing predict() continues to expect corrected raw."""
    if not isinstance(observation, Observation):
        raise TypeError("Explicit Observation required")
    fixed = repair_core_audio(observation.raw215, observation.audio, endpoint_seconds=observation.endpoint_seconds)
    return replace(observation, raw215=fixed)


class SelectedPredictor:
    def __init__(self, directory, *, expected_manifest_sha256, head=None, builder_paths=None, release_root=None):
        self.directory = Path(directory).resolve()
        self.release_root = Path(release_root).resolve() if release_root is not None else self.directory.parent
        if not self.directory.is_relative_to(self.release_root):
            raise ValueError("Model directory is outside the explicit release root")
        self.builder_paths = dict(builder_paths or {})
        self._relative = InvariantRepresentation("relative")
        self._history = None
        self.components = []
        self._audio = self._image = None
        if (self.directory / "ensemble.json").is_file():
            manifest = self.directory / "ensemble.json"
        elif (self.directory / "model.json").is_file():
            manifest = self.directory / "model.json"
        else:
            manifest = self.directory / "classifier.pt"
        self.manifest_path = _verified(manifest, expected_manifest_sha256)
        self.manifest_sha256 = expected_manifest_sha256
        if manifest.suffix == ".pt":
            if head is None:
                raise ValueError("A selected temporal head is required; no implicit head selection")
            from .temporal import load_temporal_classifier
            self.model = load_temporal_classifier(manifest, head=head)
            self.format = TEMPORAL_VERSION
            self.config = self.model.metadata
            self.threshold = self.model.threshold
            self.kind = "raw215"
            return
        if head is not None:
            raise ValueError("head is valid only for a temporal checkpoint")
        self.config = json.loads(manifest.read_text(encoding="utf-8"))
        self.format = self.config.get("version")
        if self.format == ENSEMBLE_VERSION:
            self._load_ensemble()
            return
        if self.format == TABULAR_VERSION:
            self.model = load_research_classifier(self.directory)
            self.kind = "raw215"
        elif self.format == DESCRIPTOR_VERSION:
            self.model = load_descriptor_classifier(self.directory)
            self.kind = self.model.schema.builder_metadata.get("kind")
            self._load_descriptor_builder()
        else:
            raise ValueError("Unsupported selected-model format")
        self.threshold = self.model.threshold

    def _builder_path(self, name, default=None):
        if name in self.builder_paths:
            return Path(self.builder_paths[name])
        if default is None:
            raise ValueError("Explicit verified builder path required: " + name)
        return _contained(self.directory, default)

    def _load_descriptor_builder(self):
        schema = self.model.schema
        builder = schema.builder_metadata
        if schema.version == history.VERSION:
            self.kind = "relative_history511"
            _verified(history.__file__, self.model.metadata.get("builder_sha256"))
            if schema.to_dict() != history.descriptor_schema().to_dict():
                raise ValueError("Saved causal-history schema differs from runtime")
            self._history = history.CausalHistoryBuffer()
            return
        if self.kind in ("audio162", "relative_audio332"):
            self._audio = _helper(self._builder_path("audio", builder["audio_builder_file"]),
                builder["audio_descriptor_sha256"])
            if builder["audio_schema"] != self._audio.schema():
                raise ValueError("Saved causal audio builder schema differs")
            names = tuple("audio." + n for n in self._audio.FEATURE_NAMES)
            if self.kind == "relative_audio332":
                _verified(representation.__file__, builder["relative_builder_sha256"])
                if builder["relative_schema"] != self._relative.to_dict():
                    raise ValueError("Saved relative builder schema differs")
                names = tuple("relative." + n for n in self._relative.names) + names
        elif self.kind in ("image128", "relative_image298"):
            self._image = _helper(self._builder_path("embeddings"), builder["embedding"]["embedding_helper_sha256"])
            if builder["window_schema"] != self._image.descriptor_schema():
                raise ValueError("Saved causal image-window schema differs")
            pca = builder["PCA"]
            path = _verified(_contained(self.directory, pca["path"]), pca["sha256"])
            with np.load(path, allow_pickle=False) as saved:
                self.pca_mean = np.asarray(saved["mean"], np.float64)
                self.pca_components = np.asarray(saved["components"], np.float64)
            if (self.pca_mean.shape != (512,) or self.pca_components.shape != (64, 512)
                    or not np.isfinite(self.pca_mean).all() or not np.isfinite(self.pca_components).all()):
                raise ValueError("Saved image PCA dimensions/numbers differ")
            pca_identity = pca["metadata"]["identity"]
            if (pca_identity["fit_split"] != "train" or pca["metadata"]["sha256"] != pca["sha256"]
                    or pca_identity["cohort_sha256"] != self.model.metadata["cohort"]["cohort_sha256"]):
                raise ValueError("Image PCA must be SHA-bound and fitted on the same training cohort only")
            names = tuple(f"{stat}.resnet18_pca64_{i:03d}" for stat in ("mean", "last_minus_first") for i in range(64))
            if self.kind == "relative_image298":
                if builder["relative"] != self._relative.to_dict():
                    raise ValueError("Saved image relative builder schema differs")
                names = self._relative.names + names
        else:
            raise ValueError("Descriptor builder is not a supported explicit research family")
        if names != schema.names:
            raise ValueError("Composed descriptor names/order differ from the saved classifier")

    def _load_ensemble(self):
        cfg = self.config
        if (cfg.get("weights") != [1 / 3] * 3 or cfg.get("weights_tuned") is not False
                or cfg.get("epsilon") != 1e-6 or cfg.get("threshold_comparator") != ">="
                or len(cfg.get("components", [])) != 3):
            raise ValueError("Only the exact frozen three-component equal-logit ensemble is supported")
        roles = {"relative": "raw215", "relative_audio": "relative_audio332", "relative_image": "relative_image298"}
        seen = set()
        for item in cfg["components"]:
            role = item["role"]
            if role not in roles or role in seen or item["weight"] != 1 / 3:
                raise ValueError("Ensemble component roles/weights differ")
            seen.add(role)
            model_path = _contained(self.release_root, (self.directory / item["model_json"]).relative_to(self.release_root))
            weights_path = _contained(self.release_root, (self.directory / item["weights_npz"]).relative_to(self.release_root))
            _verified(weights_path, item["weights_sha256"])
            if model_path.name != "model.json" or weights_path != model_path.parent / "weights.npz":
                raise ValueError("Ensemble paths must identify each exact numerical component")
            component = SelectedPredictor(model_path.parent, expected_manifest_sha256=item["model_sha256"],
                builder_paths=self.builder_paths, release_root=self.release_root)
            actual_schema = (component.model.representation.to_dict() if role == "relative"
                else component.model.schema.to_dict())
            if (component.kind != roles[role] or component.format != item["runtime_format"]
                    or actual_schema != item["schema"] or _canonical(actual_schema) != item["schema_sha256"]
                    or _canonical(component.model.metadata["target"]) != item["target_sha256"]
                    or component.model.metadata["target"] != cfg["target"]
                    or component.model.metadata["cohort"]["cohort_sha256"] != item["cohort_sha256"]
                    or item["cohort_sha256"] != cfg["cohort"]["cohort_sha256"]):
                raise ValueError("Ensemble component schema/target/cohort differs")
            relative_schema = (actual_schema if role == "relative" else component.model.schema.builder_metadata[
                "relative_schema" if role == "relative_audio" else "relative"])
            if (relative_schema != self._relative.to_dict()
                    or _canonical(relative_schema) != item["relative_schema_sha256"]
                    or component.model.architecture.get("kind") != "hist_gradient_boosting"):
                raise ValueError("Ensemble requires the exact shared relative170 builder and HGB components")
            self.components.append(component)
        self.kind = "ensemble"
        self.threshold = float(cfg["decision_threshold"])
        if not np.isfinite(self.threshold) or not 0 <= self.threshold <= np.nextafter(1., np.inf):
            raise ValueError("Invalid ensemble operating threshold")

    @staticmethod
    def _raw(observation):
        raw = np.asarray(observation.raw215)
        if raw.shape != (75, 215) or raw.dtype != np.float32:
            raise ValueError("Explicit raw float32[75,215] observation required")
        return raw

    def descriptor(self, observation):
        """Compose one exact descriptor, without changing causal history."""
        if not isinstance(observation, Observation):
            raise TypeError("Explicit Observation required")
        if self.kind == "relative_history511":
            current = self._relative.transform(self._raw(observation))
            return self._history.query(current, observation.endpoint_seconds, observation.match_id, observation.half)
        if self.kind in ("raw215", "ensemble"):
            raise ValueError("This predictor does not consume a standalone descriptor")
        builder = self.model.schema.builder_metadata
        if self._audio is not None:
            audio = observation.audio
            if (not isinstance(audio, AudioInput)
                    or not isinstance(audio.available, bool) or audio.decoder_sha256 != builder["audio_decoder_sha256"]
                    or audio.start_seconds != observation.endpoint_seconds - 5 or audio.end_seconds != observation.endpoint_seconds):
                raise ValueError("Explicit aligned five-second16kHz PCM/availability/decoder identity required")
            if audio.available:
                pcm = np.asarray(audio.pcm)
                if (audio.sample_rate != 16000 or pcm.ndim not in (1, 2) or len(pcm) != 80000 or pcm.dtype.kind != "f"
                        or (pcm.ndim == 2 and pcm.shape[1] not in (1, 2)) or np.isinf(pcm).any()):
                    raise ValueError("PCM must contain exactly80000 float mono/stereo samples; NaN marks unavailable")
            else:
                if audio.pcm is not None or audio.sample_rate is not None:
                    raise ValueError("Explicitly unavailable audio must supply pcm=None and sample_rate=None")
                pcm = None
            vector = self._audio.audio_descriptors(pcm, audio.sample_rate, duration_seconds=5)
        elif self._image is not None:
            image = observation.image
            expected = builder["embedding"]["frozen_model"]["weights_sha256"]
            if not isinstance(image, ImageInput) or image.encoder_weights_sha256 != expected:
                raise ValueError("Explicit causal image embeddings and exact encoder-weight identity required")
            targets = np.asarray(image.target_seconds, np.float64)
            sources = np.asarray(image.source_seconds, np.float64)
            vectors = np.asarray(image.embeddings)
            if (vectors.dtype != np.float32 or targets.ndim != 1 or sources.shape != targets.shape
                    or not np.isfinite(sources).all() or np.any(sources < 0) or np.any(targets >= observation.endpoint_seconds)):
                raise ValueError("float32 causal embeddings strictly before endpoint required")
            # Extraction stores encoder outputs as float16. Training windows pool
            # those quantized values after casting to float32, not encoder float32.
            with np.errstate(over="ignore", invalid="ignore"):
                quantized = vectors.astype(np.float16).astype(np.float32)
            base = self._image.window_descriptors(targets, quantized, [observation.endpoint_seconds],
                source_times=sources)[0]
            vector = np.concatenate([(base[:512].astype(np.float64) - self.pca_mean) @ self.pca_components.T,
                base[512:].astype(np.float64) @ self.pca_components.T]).astype(np.float32)
        else:
            raise ValueError("This predictor does not consume a standalone descriptor")
        if self.kind.startswith("relative_"):
            vector = np.concatenate([self._relative.transform(self._raw(observation)), vector]).astype(np.float32)
        return np.asarray(vector, np.float32)

    def predict(self, observation):
        """Return one scalar uncalibrated interest score; never commit history."""
        if not isinstance(observation, Observation):
            raise TypeError("Explicit Observation required")
        if self.kind == "ensemble":
            q = np.clip(np.asarray([c.predict(observation) for c in self.components], np.float64), 1e-6, 1 - 1e-6)
            return float(sigmoid(np.mean(np.log(q) - np.log1p(-q))))
        if self.kind == "raw215":
            return float(self.model.predict(self._raw(observation)))
        return self.model.predict(self.descriptor(observation), feature_names=self.model.schema.names)

    @property
    def requires_raw215(self):
        if self.kind == "ensemble":
            return any(component.requires_raw215 for component in self.components)
        return self.kind not in ("audio162", "image128")

    def predict_with_core_audio(self, observation):
        """Explicit PCM -> corrected raw -> score. No history is committed."""
        if not self.requires_raw215:
            raise ValueError("This selected model has no raw215 input to repair")
        return self.predict(with_core_audio(observation))

    def commit_with_core_audio(self, observation):
        """Explicit history commit from the same corrected current observation."""
        if not self.requires_raw215:
            raise ValueError("This selected model has no raw215 input to repair")
        self.commit(with_core_audio(observation))

    def commit(self, observation):
        """Commit ONLY an actual grid endpoint, after all queries/scoring at it."""
        if self.kind == "ensemble":
            for component in self.components:
                component.commit(observation)
        elif self._history is not None:
            current = self._relative.transform(self._raw(observation))
            self._history.commit(current, observation.endpoint_seconds, observation.match_id, observation.half)

    def reset(self, match_id=None):
        if self._history is not None:
            self._history.reset(match_id)
        for component in self.components:
            component.reset(match_id)


def load_selected_predictor(directory, **kwargs):
    return SelectedPredictor(directory, **kwargs)
