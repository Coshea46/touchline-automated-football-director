"""Explicit v3 PCM -> five core audio channels for new research raw215 models.

Existing raw prediction APIs expect ALREADY corrected raw215. This module never
changes them implicitly. Copy visual channels0:210 and replace only210:215 via
the same public audio_features call used during autonomous data preparation.
"""

import hashlib
import importlib.util
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from matchpulse.features import audio as public_audio
from matchpulse.features.schema import SCHEMA_VERSION, validate

VERSION = "matchpulse-raw215-sampleclock-core-audio-v3"
DECODER_REVISION = "autonomous-native-sample-clock-v1"
DECODER_SHA256 = "e7772f027ddb2c66f3801329995c8c8a1c9a36e23e0c44d92aeaa7023c75c8a4"
CORE_FEATURE_SOURCE_SHA256 = "77918bc5d4a65dc0c157ab37fb4ada6a00be71c4f57eb45ba6362e5af86ab0b1"


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@dataclass(frozen=True)
class AudioInput:
    pcm: np.ndarray | None
    sample_rate: int | None
    start_seconds: float
    end_seconds: float
    available: bool
    decoder_sha256: str


def validate_aligned_audio(audio, *, endpoint_seconds):
    if not isinstance(audio, AudioInput):
        raise TypeError("Explicit aligned AudioInput required")
    times = [audio.start_seconds, audio.end_seconds, endpoint_seconds]
    if (not np.isfinite(times).all() or audio.start_seconds < 0 or audio.end_seconds != endpoint_seconds
            or audio.end_seconds - audio.start_seconds != 5):
        raise ValueError("Audio must span exactly[endpoint-5,endpoint) on the original source clock")
    if not isinstance(audio.available, bool) or audio.decoder_sha256 != DECODER_SHA256:
        raise ValueError("Exact v3 sample-clock decoder SHA and explicit audio availability required")
    if not audio.available:
        if audio.pcm is not None or audio.sample_rate is not None:
            raise ValueError("Unavailable audio requires pcm=None and sample_rate=None")
        return
    pcm = np.asarray(audio.pcm)
    if (not isinstance(audio.sample_rate, (int, np.integer)) or audio.sample_rate != 16000
            or isinstance(audio.sample_rate, bool) or pcm.ndim not in (1, 2)
            or len(pcm) != 80000 or pcm.dtype.kind != "f" or (pcm.ndim == 2 and pcm.shape[1] not in (1, 2))
            or np.isinf(pcm).any() or np.any(np.abs(pcm[np.isfinite(pcm)]) > 1.00001)):
        raise ValueError("Exactly80000 float16kHz mono/stereo PCM samples required; NaN marks genuine gaps")


def schema():
    if _sha(public_audio.__file__) != CORE_FEATURE_SOURCE_SHA256:
        raise ValueError("Public core-audio feature source differs from the frozen training contract")
    return {"version": VERSION, "raw_schema": SCHEMA_VERSION, "raw_shape": [75, 215], "raw_dtype": "float32",
        "sampling_fps": 15, "observation_seconds": 5, "visual_slice_unchanged": [0, 210],
        "audio_slice_replaced": [210, 215], "audio_feature_shape": [75, 5],
        "decoder_revision": DECODER_REVISION, "decoder_sha256": DECODER_SHA256,
        "public_audio_feature_source_sha256": CORE_FEATURE_SOURCE_SHA256,
        "feature_call": "matchpulse.features.audio.audio_features(pcm,rate,allow_gaps=True,duration_seconds=5)",
        "audio_columns": ["dBFS_over80", "dBFS_over80_delta", "positive_L2_spectral_flux", "centroid_over_Nyquist", "available"],
        "PCM": "Exactly80000 aligned16kHz float mono/stereo samples in[endpoint-5,endpoint); NaN gaps; stereo power/magnitude aggregation preserved",
        "causality": "Native samples cropped strictly before endpoint BEFORE resampling by the exact supplied decoder; no future audio",
        "already_corrected_raw": "Existing predict(raw215) expects these corrected channels; supplying PCM alone never silently repairs raw",
        "release_reproduction_gate": {"core5_atol": 2e-6, "core5_rtol": 1e-5,
            "availability_masks_exact": True, "visual210_bytes_exact": True, "bitwise_core5_equality_reported_not_required": True,
            "tabular_score_atol": 1e-10, "temporal_score_atol": 2e-5,
            "timing": "Declared before real winner/PCM smoke outcomes; no producer or independent waveform gate is changed"},
        "scope": "All new raw-dependent autonomous models, including compact/relative/history/temporal/fused models. Legacy reference checkpoints keep their separately documented contract"}


def repair_core_audio(raw215, audio, *, endpoint_seconds):
    """Return a new rawfloat32[75,215]; original raw and visual bytes never change."""
    raw = np.asarray(raw215)
    if raw.shape != (75, 215) or raw.dtype != np.float32 or not np.isfinite(raw[:, :210]).all():
        raise ValueError("Finite visual210 in rawfloat32[75,215] required")
    validate_aligned_audio(audio, endpoint_seconds=endpoint_seconds)
    schema()  # Independently bind the actual public implementation to training.
    sound = public_audio.audio_features(audio.pcm, audio.sample_rate, allow_gaps=True, duration_seconds=5)
    result = raw.copy()
    result[:, 210:] = sound
    if result[:, :210].tobytes() != raw[:, :210].tobytes():
        raise AssertionError("Visual feature bytes changed during explicit audio repair")
    validate(result, steps=75)
    return result


def decode_aligned_audio(video_path, *, start_seconds, end_seconds, video_origin_seconds, decoder_path):
    """Use the exact supplied audit decoder; never call the unchanged from_file decoder.

    ``video_origin_seconds`` is the original video stream start_time*time_base,
    not an audio offset. No detector/YOLO is constructed or invoked.
    """
    if (not np.isfinite([start_seconds, end_seconds, video_origin_seconds]).all()
            or start_seconds < 0 or end_seconds - start_seconds != 5):
        raise ValueError("Explicit original five-second interval/video origin required")
    path = Path(decoder_path).resolve()
    if not path.is_file() or _sha(path) != DECODER_SHA256:
        raise ValueError("Supplied v3 decoder source SHA differs")
    spec = importlib.util.spec_from_file_location("_matchpulse_core_sampleclock_" + DECODER_SHA256, path)
    if spec is None or spec.loader is None:
        raise ValueError("Cannot load exact audited sample-clock decoder")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.REVISION != DECODER_REVISION:
        raise ValueError("Decoder revision differs")
    wave, rate = module.decode_audio_sampleclock(video_path, start_seconds, end_seconds, video_origin_seconds)
    result = AudioInput(wave, rate, start_seconds, end_seconds, wave is not None, DECODER_SHA256)
    validate_aligned_audio(result, endpoint_seconds=end_seconds)
    return result
