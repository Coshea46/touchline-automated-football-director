"""One fixed post-selection timing negative control on paired support.

This module never selects a model/policy. It reuses the frozen causal policy and
incident evaluator, discarding all warmup footage from reported durations and
switches while retaining genuine policy state. A 120s lag never wraps or reads
future scores. All comparisons use identical measured four-match footage.
"""

from dataclasses import asdict, replace

import numpy as np
from sklearn.metrics import average_precision_score

from . import replay

VERSION = "matchpulse-temporal-lag-control-v1"
LAG_SECONDS = 120.0
RESET_ACTION_SECONDS = 120.0
FIRST_PAIRED_ENDPOINT_SECONDS = 125.0
MEASURE_ACTION_SECONDS = 426.0


def _paired_grids(rows, scores, half_durations, config):
    """Construct both causal policies without access to events or labels."""
    if config.prediction_latency_seconds != 1 or config.adaptive_history_seconds != 300:
        raise ValueError("The frozen lag diagnostic requires 1s delay and 300s history")
    if config.adaptive_warmup_seconds != 30 or config.staying_bonus_logit != .25:
        raise ValueError("The lag diagnostic retains fixed 30s warmup and .25 staying bonus")
    grid = replay._prepare(rows, {"selected": scores}, half_durations, config)
    if not grid.support["all_score_grid_complete"]:
        raise ValueError("The fixed lag control requires complete label-independent support")
    versions = {"original": [], "lagged_120s": []}
    for session in grid.sessions:
        if session.end <= MEASURE_ACTION_SECONDS:
            raise ValueError("Every common half must leave measured support after 426s")
        lookup = {replay._time_key(time): i for i, time in enumerate(session.prediction_times)}
        indices = np.flatnonzero(session.prediction_times >= FIRST_PAIRED_ENDPOINT_SECONDS)
        previous = []
        for i in indices:
            j = lookup.get(replay._time_key(session.prediction_times[i] - LAG_SECONDS))
            if j is None or session.prediction_times[j] >= session.prediction_times[i]:
                raise ValueError("Exact earlier same-half 120s lag lookup required")
            previous.append(j)
        for name, source_indices in (("original", indices), ("lagged_120s", previous)):
            values = session.scores["selected"][source_indices].copy()
            endpoints = np.repeat(session.prediction_times[np.asarray(source_indices), None], len(grid.matches), axis=1)
            versions[name].append(replace(session, prediction_times=session.prediction_times[indices],
                times=session.times[indices], lengths=session.lengths[indices],
                scores={"selected": values}, supported=np.isfinite(values).all(axis=1),
                prediction_endpoints={"selected": endpoints}))
    return {name: replace(grid, sessions=sessions) for name, sessions in versions.items()}


def _measured_metrics(grid, schedules, events, include_trace):
    """Keep exact event-time/run history, but count viewing/switches only>=426s."""
    scopes = {}
    event_keys = ("available_incident_groups", "incident_groups_in_replay", "incident_groups_outside_common_playback",
        "complete_support_incident_groups", "verified_shown_incident_groups", "missed_incident_groups_on_complete_support",
        "shown_fraction_on_complete_support", "shown_fraction_all_available_lower_bound",
        "macro_match_shown_fraction_on_complete_support", "macro_match_shown_fraction_all_available_lower_bound",
        "macro_match_count_with_complete_support_incidents", "macro_match_count_with_available_incidents",
        "shown_with_at_least_3s_preselection", "newly_anticipated_via_switch",
        "mean_preselection_lead_capped10_seconds_for_shown", "preselection_lead_capped10_quantiles", "per_match", "cases")
    seconds = switches = 0
    viewing = {match: 0. for match in grid.matches}
    trace = []
    for session, schedule in zip(grid.sessions, schedules, strict=True):
        mask = session.times >= MEASURE_ACTION_SECONDS
        seconds += float(session.lengths[mask].sum())
        switches += int(schedule["switched"][mask].sum())
        for i in np.flatnonzero(mask):
            match = grid.matches[int(schedule["selected"][i])]
            viewing[match] += float(session.lengths[i])
            if include_trace:
                trace.append({"half": session.half, "prediction_endpoint_seconds": float(session.prediction_times[i]),
                    "score_source_prediction_endpoint_seconds": float(session.prediction_endpoints["selected"][i, 0]),
                    "prediction_available_seconds": float(session.times[i]),
                    "display_end_seconds": float(session.times[i] + session.lengths[i]),
                    "selected_match": match, "switched": bool(schedule["switched"][i]),
                    "complete_score_support": bool(session.supported[i])})
    for scope, allowed in replay.SCOPES.items():
        # Group FIRST: censoring annotation rows first could shift an original
        # group's earliest timestamp across the measured-support boundary.
        incidents = replay._incidents(events, grid.matches, set(grid.support["half_sessions"]), allowed)
        incidents = [incident for incident in incidents if incident["timestamp"] >= MEASURE_ACTION_SECONDS]
        metrics = replay._scope_metrics(grid, schedules, incidents)
        scopes[scope] = {key: metrics[key] for key in event_keys}
        scopes[scope].update(switches=switches, switches_per_output_minute=switches/(seconds/60),
            measured_output_seconds=seconds)
    result = {"scopes": scopes, "measured_output_seconds": seconds, "viewing_seconds_by_match": viewing,
        "viewing_fraction_by_match": {match: value/seconds for match, value in viewing.items()}}
    if include_trace:
        result["trace"] = trace
    return result


def _binary(labels, original, lagged):
    count = len(labels)
    return {"windows": count, "positives": int(labels.sum()),
        "prevalence": float(labels.mean()) if count else None,
        "original_AP": float(average_precision_score(labels, original)) if count and labels.any() else None,
        "lagged120s_AP": float(average_precision_score(labels, lagged)) if count and labels.any() else None,
        "AP_note": "Identical restricted original-eligible rows only; never compare this AP with full eligible-cohort AP"}


def paired_eligible_AP(grid_rows, grid_scores, eligible_rows, eligible_scores, half_durations):
    """Pair original labels/scores to exact earlier grid predictions, no jitter."""
    raw = np.asarray(grid_scores, dtype=np.float64)
    current = np.asarray(eligible_scores, dtype=np.float64)
    if raw.shape != (len(grid_rows),) or current.shape != (len(eligible_rows),):
        raise ValueError("One score per exact grid/original eligible row required")
    if any(row["split"] != "valid" for row in [*grid_rows, *eligible_rows]):
        raise ValueError("Paired AP may use official validation only")
    if not np.isfinite(raw).all() or not np.isfinite(current).all() or np.any((raw < 0) | (raw > 1)) or np.any((current < 0) | (current > 1)):
        raise ValueError("Finite probability predictions required")
    lookup = {}
    for row, score in zip(grid_rows, raw, strict=True):
        key = (row["match_id"], int(row["half"]), replay._time_key(row["observation_end_seconds"]))
        if key in lookup:
            raise ValueError("Duplicate fixed-grid lag source")
        lookup[key] = float(score)
    matches = sorted({row["match_id"] for row in grid_rows})
    common_ends = {half: min(float(half_durations[match, half]) for match in matches) for half in {int(r["half"]) for r in grid_rows}}
    kept = []
    excluded = {match: {"before426s": 0, "outside_common_source": 0, "no_exact_lag_grid_endpoint": 0} for match in matches}
    for row, score in zip(eligible_rows, current, strict=True):
        match, half, endpoint = row["match_id"], int(row["half"]), float(row["observation_end_seconds"])
        if match not in excluded:
            raise ValueError("Eligible score belongs to another validation match")
        action = endpoint + 1
        if action < MEASURE_ACTION_SECONDS:
            excluded[match]["before426s"] += 1
            continue
        if action >= common_ends[half]:
            excluded[match]["outside_common_source"] += 1
            continue
        key = (match, half, replay._time_key(endpoint - LAG_SECONDS))
        if key not in lookup:
            excluded[match]["no_exact_lag_grid_endpoint"] += 1
            continue
        if row["label"] not in (0, 1):
            raise ValueError("Original binary eligible validation labels required")
        kept.append((match, row["window_id"], int(row["label"]), score, lookup[key]))
    labels = np.asarray([item[2] for item in kept], dtype=np.int8)
    original, lagged = np.asarray([item[3] for item in kept]), np.asarray([item[4] for item in kept])
    return {**_binary(labels, original, lagged), "included_original_window_ids": [item[1] for item in kept],
        "excluded_counts_per_match": excluded,
        "per_match": {match: _binary(labels[mask], original[mask], lagged[mask]) for match in matches
            for mask in [np.asarray([item[0] == match for item in kept], dtype=bool)]},
        "excluded_from_both_versions": True, "future_or_interpolated_scores_used": False}


def evaluate_fixed_lag(rows, scores, events, *, half_durations, frozen_policy, config=None,
                       eligible_rows=None, eligible_scores=None, include_trace=True):
    """Compare only the frozen winner with its 120s-lag negative control."""
    policy = frozen_policy.split("::", 1)[0]
    if policy not in ("score", "score_centered") or "::" not in frozen_policy:
        raise ValueError("Supply the already frozen selected score policy")
    config = config or replay.ReplayConfig(prediction_latency_seconds=1, include_centered_policies=True)
    grids = _paired_grids(rows, scores, half_durations, config)
    # Both schedules are committed before any event labels are evaluated.
    schedules = {name: replay._schedule(grid, policy, "selected") for name, grid in grids.items()}
    versions = {name: _measured_metrics(grid, schedules[name], events, include_trace) for name, grid in grids.items()}
    difference = {}
    for scope in replay.SCOPES:
        first, lagged = versions["original"]["scopes"][scope], versions["lagged_120s"]["scopes"][scope]
        if first["complete_support_incident_groups"] != lagged["complete_support_incident_groups"]:
            raise ValueError("Lag comparison lost paired event support")
        difference[scope] = {"original_minus_lagged_verified_shown": first["verified_shown_incident_groups"] - lagged["verified_shown_incident_groups"],
            "per_match_original_minus_lagged_shown": {match: first["per_match"][match]["verified_shown"] - lagged["per_match"][match]["verified_shown"]
                for match in grids["original"].matches}}
    ap = None
    if eligible_rows is not None or eligible_scores is not None:
        if eligible_rows is None or eligible_scores is None:
            raise ValueError("Both exact original eligible rows and scores required for paired AP")
        ap = paired_eligible_AP(rows, scores, eligible_rows, eligible_scores, half_durations)
    return {"version": VERSION, "configuration": asdict(config), "frozen_policy": frozen_policy,
        "score_lag_seconds": LAG_SECONDS, "policy_reset_action_seconds": RESET_ACTION_SECONDS,
        "first_valid_paired_action_seconds": FIRST_PAIRED_ENDPOINT_SECONDS + config.prediction_latency_seconds,
        "measured_support_start_action_seconds": MEASURE_ACTION_SECONDS,
        "independent_match_ids": grids["original"].matches, "half_sessions": grids["original"].support["half_sessions"],
        "versions": versions, "paired_original_minus_lagged": difference, "paired_original_eligible_AP": ap,
        "analysis_only": True, "model_reselection_performed": False, "eligible_for_model_promotion": False,
        "interpretation": "A single descriptive timing negative control preserving match identity/score priors approximately. Similar performance is consistent with match-prior reliance; degradation suggests local timing contribution. Neither proves anticipation, significance or generalization.",
        "test_accessed": False}
