"""Tiny causal three-head GRU over observed invariant frame features.

Raw observation input staysfloat32[batch,75,215]. Normalization is fitted only on
observed training-frame values; the model receives34 normalized values plus34
explicit validity bits. No metadata/labels/match IDs enter its forward method.
"""
from hashlib import sha256
from pathlib import Path

import numpy as np
import torch
from torch import nn

from matchpulse.features.schema import SCHEMA_VERSION,validate
from . import representation
from .representation import frame_representation,RELATIVE_NAMES

VERSION='matchpulse-temporal-threehead-v1'
HEADS=('any3_10','shots3_10','shots0_5')
ARCHITECTURE={'input_size':68,'hidden_size':16,'heads':3,'dropout':.2,'layers':1,'bidirectional':False}


def source_hash(path):return sha256(Path(path).read_bytes()).hexdigest()


def fit_observed_normalization(values,valid,indices=None,*,batch_size=256):
    """Train-only caller-supplied indices; unobserved values never affect moments."""
    if values.shape!=valid.shape or values.ndim!=3 or values.shape[2]!=34:raise ValueError('Expected aligned frame values/masks')
    if valid.dtype!=np.bool_:raise ValueError('Validity mask must bebool')
    ix=np.arange(len(values)) if indices is None else np.asarray(indices,dtype=np.int64)
    if len(ix)==0 or np.any(ix<0) or np.any(ix>=len(values)):raise ValueError('Nonempty valid normalization indices required')
    total=np.zeros(34,np.float64);squares=total.copy();count=np.zeros(34,np.int64)
    for start in range(0,len(ix),batch_size):
        selection=ix[start:start+batch_size];a=np.asarray(values[selection],np.float64);m=np.asarray(valid[selection],bool)
        if not np.isfinite(a[m]).all():raise ValueError('Observed normalization values must befinite')
        masked=np.where(m,a,0);total+=masked.sum((0,1));squares+=(masked**2).sum((0,1));count+=m.sum((0,1))
    mean=total/np.maximum(count,1);scale=np.sqrt(np.maximum(0,squares/np.maximum(count,1)-mean**2))
    scale[scale<1e-6]=1
    return {'mean':torch.tensor(mean,dtype=torch.float32),'scale':torch.tensor(scale,dtype=torch.float32),
            'count':torch.tensor(count,dtype=torch.int64)}


def normalize_frames(values,valid,normalization):
    mean=np.asarray(normalization['mean'],dtype=np.float32);scale=np.asarray(normalization['scale'],dtype=np.float32)
    if values.shape!=valid.shape or values.ndim!=3 or values.shape[-1]!=34:raise ValueError('Aligned34-channel values/masks required')
    if valid.dtype!=np.bool_:raise ValueError('Validity mask must bebool')
    normalized=np.where(valid,(np.asarray(values,np.float32)-mean)/scale,0)
    result=np.concatenate([normalized,np.asarray(valid,np.float32)],axis=-1).astype(np.float32)
    if not np.isfinite(result).all():raise ValueError('Nonfinite normalized observed sequence')
    return result


class TemporalGRU(nn.Module):
    def __init__(self):
        super().__init__()
        self.gru=nn.GRU(68,16,num_layers=1,batch_first=True,bidirectional=False)
        self.dropout=nn.Dropout(.2);self.head=nn.Linear(16,3)

    def encode(self,x):
        output,_=self.gru(x)
        return output

    def forward(self,x):
        return self.head(self.dropout(self.encode(x)[:,-1]))


def _targets(targets):
    if not isinstance(targets,dict) or set(targets)!=set(HEADS):raise ValueError('All three exact target definitions are required')
    for name,target in targets.items():
        minimum,maximum=(0,5) if name=='shots0_5' else (3,10)
        expected={'Corner','Direct free-kick','Goal','Penalty','Shots off target','Shots on target'} if name=='any3_10' else {'Goal','Shots off target','Shots on target'}
        if (target.get('version')!='matchpulse-autonomous-targets-v1.0.0' or target.get('name')!=name or target.get('min_lead_seconds')!=minimum or target.get('max_lead_seconds')!=maximum
            or target.get('observation_seconds')!=5 or set(target.get('event_types',[]))!=expected):
            raise ValueError('Temporal target/horizon semantics mismatch')


def export_temporal_checkpoint(path,model,normalization,*,targets,thresholds,metadata):
    from matchpulse.interest.checkpoint import atomic_checkpoint
    _targets(targets)
    if set(thresholds)!=set(HEADS) or not np.isfinite(list(thresholds.values())).all():raise ValueError('Three finite operating thresholds required')
    payload={'version':VERSION,'architecture':ARCHITECTURE,'state_dict':{k:v.detach().cpu() for k,v in model.state_dict().items()},
        'normalization':{k:torch.as_tensor(v).detach().cpu() for k,v in normalization.items()},
        'head_order':list(HEADS),'targets':targets,'thresholds':thresholds,'threshold_comparator':'>=',
        'input_schema':{'dtype':'float32','shape':[75,215],'fps':15,'observation_seconds':5,'feature_schema':SCHEMA_VERSION},
        'frame_schema':{'names':list(RELATIVE_NAMES),'width':34,'sequence_length':75,'input_order':'34 normalized observed values then34 validity bits'},
        'representation_source_sha256':source_hash(representation.__file__),'model_source_sha256':source_hash(__file__),
        'metadata':metadata,'score_semantics':'Uncalibrated per-target interest scores; no probability calibration claimed'}
    atomic_checkpoint(path,payload)


class TemporalClassifier:
    def __init__(self,checkpoint,*,device='cpu',head=None):
        if (checkpoint.get('version')!=VERSION or checkpoint.get('architecture')!=ARCHITECTURE
            or checkpoint.get('head_order')!=list(HEADS) or checkpoint.get('threshold_comparator')!='>='):
            raise ValueError('Temporal classifier version/architecture/head contract mismatch')
        if checkpoint.get('input_schema')!={'dtype':'float32','shape':[75,215],'fps':15,'observation_seconds':5,'feature_schema':SCHEMA_VERSION}:
            raise ValueError('Temporal raw observation schema mismatch')
        if checkpoint.get('frame_schema')!={'names':list(RELATIVE_NAMES),'width':34,'sequence_length':75,'input_order':'34 normalized observed values then34 validity bits'}:
            raise ValueError('Temporal invariant frame schema mismatch')
        if checkpoint.get('representation_source_sha256')!=source_hash(representation.__file__) or checkpoint.get('model_source_sha256')!=source_hash(__file__):
            raise ValueError('Temporal runtime source SHA differs from saved builder/model contract')
        _targets(checkpoint['targets'])
        if set(checkpoint['thresholds'])!=set(HEADS) or not np.isfinite(list(checkpoint['thresholds'].values())).all():raise ValueError('Invalid temporal thresholds')
        if head is not None and head not in HEADS:raise ValueError('Unknown temporal head')
        self.device=torch.device(device)
        if self.device.type=='cuda' and not torch.cuda.is_available():raise RuntimeError('Requested CUDA device unavailable')
        self.normalization=checkpoint['normalization']
        if set(self.normalization)!={'mean','scale','count'}:raise ValueError('Incomplete saved temporal normalization')
        for name,value in self.normalization.items():
            if not isinstance(value,torch.Tensor) or value.shape!=(34,) or not torch.isfinite(value).all():raise ValueError('Invalid saved temporal normalization')
            if value.dtype!=(torch.int64 if name=='count' else torch.float32):raise ValueError('Saved normalization dtype mismatch')
        if (self.normalization['scale']<=0).any() or (self.normalization['count']<0).any():raise ValueError('Invalid normalization scale/count')
        self.model=TemporalGRU().to(self.device);self.model.load_state_dict(checkpoint['state_dict'],strict=True);self.model.eval()
        self.selected_head=head;self.head_order=HEADS;self.thresholds=checkpoint['thresholds'];self.threshold=None if head is None else float(self.thresholds[head])
        self.metadata={k:v for k,v in checkpoint.items() if k not in ('state_dict','normalization')}

    def predict_batch(self,features,*,head=None):
        raw=np.asarray(features)
        if raw.ndim!=3 or raw.shape[1:]!=(75,215) or raw.dtype!=np.float32:raise ValueError('Expected raw float32[batch,75,215]')
        for sample in raw:validate(sample,steps=75)
        values,valid=frame_representation(raw,'relative');sequence=normalize_frames(values,valid,self.normalization)
        with torch.inference_mode():scores=self.model(torch.from_numpy(sequence).to(self.device)).sigmoid().cpu().numpy()
        selected=self.selected_head if head is None else head
        if selected is not None:
            if selected not in HEADS:raise ValueError('Unknown temporal head')
            return scores[:,HEADS.index(selected)]
        return scores

    def predict(self,features,*,head=None):
        raw=np.asarray(features)
        if raw.shape!=(75,215):raise ValueError('Expected one raw float32[75,215] observation')
        result=self.predict_batch(raw[None],head=head)
        return float(result[0]) if result.ndim==1 else result[0]


def load_temporal_classifier(path,*,device='cpu',head=None):
    checkpoint=torch.load(path,map_location='cpu',weights_only=True)
    return TemporalClassifier(checkpoint,device=device,head=head)
