"""Causal 15-second context from current/past relative170 observations only.

The current vector describes the completed five-second observation. Historical
vectors are committed ONLY on the fixed two-second source grid. A query never
commits, prunes, changes half state, or observes labels/future descriptors.
"""

from collections import defaultdict, deque
from numbers import Integral

import numpy as np

from .descriptor_classifier import DescriptorSchema
from .representation import InvariantRepresentation

VERSION = "causal-relative-history15-v1"
BASE_WIDTH = 170
WIDTH = 511
LOOKBACK_SECONDS = 10.0
GRID_FIRST_ENDPOINT = 5.0
GRID_STRIDE_SECONDS = 2.0
MAX_PAST_VECTORS = 5
TOLERANCE = 1e-7


def _scope(match_id, half, endpoint):
    if not isinstance(match_id, str) or not match_id:
        raise ValueError("Original nonempty match ID is required")
    if not isinstance(half, Integral) or isinstance(half, bool) or int(half) not in (1, 2):
        raise ValueError("Original half 1 or2 is required")
    endpoint = float(endpoint)
    if not np.isfinite(endpoint) or endpoint < GRID_FIRST_ENDPOINT - TOLERANCE:
        raise ValueError("Finite endpoint after a completed five-second observation required")
    return match_id, int(half), endpoint


def _vector(value):
    value = np.asarray(value)
    if value.shape != (BASE_WIDTH,) or value.dtype != np.float32 or not np.isfinite(value).all():
        raise ValueError("Finite float32 relative170 vector required")
    return value


class CausalHistoryBuffer:
    """At most five committed170-float vectors per live independent match.

    Query BEFORE committing that endpoint. Re-querying an already committed
    endpoint is rejected, since keeping the five vectors needed for the NEXT
    decision does not retain the sixth vector needed to reconstruct an old one.
    An off-grid query can inspect past state but can never update it.
    """

    def __init__(self):
        self._states = {}

    def reset(self, match_id=None):
        if match_id is None:
            self._states.clear()
        else:
            self._states.pop(match_id, None)

    def query(self, current, endpoint, match_id, half):
        current = _vector(current)
        match_id, half, endpoint = _scope(match_id, half, endpoint)
        state = self._states.get(match_id)
        previous = []
        if state is not None:
            if half < state["half"]:
                raise ValueError("Old-half queries require an explicit independent reset")
            if half == state["half"]:
                if endpoint <= state["last_endpoint"] + TOLERANCE:
                    raise ValueError("Query must precede commit at that endpoint; no retrospective state reconstruction")
                previous = [(time, value) for time, value in state["history"]
                    if endpoint - LOOKBACK_SECONDS - TOLERANCE <= time < endpoint - TOLERANCE]
        vectors = [value for _, value in previous] + [current]
        mean = np.mean(np.stack(vectors), axis=0, dtype=np.float64).astype(np.float32)
        oldest = previous[0][1] if previous else current
        span = min(1.0, max(0.0, (endpoint - previous[0][0]) / LOOKBACK_SECONDS)) if previous else 0.0
        return np.concatenate((current, mean, current - oldest, np.asarray([span], np.float32))).astype(np.float32)

    def commit(self, current, endpoint, match_id, half):
        current = _vector(current)
        match_id, half, endpoint = _scope(match_id, half, endpoint)
        phase = (endpoint - GRID_FIRST_ENDPOINT) / GRID_STRIDE_SECONDS
        if abs(phase - round(phase)) > TOLERANCE:
            raise ValueError("Only actual fixed two-second-grid observations may be committed")
        state = self._states.get(match_id)
        if state is not None and half < state["half"]:
            raise ValueError("Cannot commit a previous half without reset")
        if state is None or half > state["half"]:
            state = {"half": half, "last_endpoint": -np.inf, "history": deque(maxlen=MAX_PAST_VECTORS)}
            self._states[match_id] = state
        if endpoint <= state["last_endpoint"] + TOLERANCE:
            raise ValueError("Fixed-grid commits must be strictly chronological within each half")
        state["history"].append((endpoint, current.copy()))
        state["last_endpoint"] = endpoint

    @property
    def vector_payload_bytes(self):
        return sum(value.nbytes for state in self._states.values() for _, value in state["history"])

    def snapshot(self):
        """A diagnostic copy, not an input to the model."""
        return {match: {"half": state["half"], "last_endpoint": state["last_endpoint"],
            "history": [{"endpoint": time, "relative170": value.tolist()} for time, value in state["history"]]}
            for match, state in self._states.items()}


def descriptor_schema():
    relative = InvariantRepresentation("relative")
    if len(relative.names) != BASE_WIDTH:
        raise ValueError("Relative170 source schema changed")
    names = tuple(prefix + name for prefix in ("current.", "history_mean.", "current_minus_oldest.")
                  for name in relative.names) + ("history_span_fraction",)
    metadata = {"version": VERSION, "source_relative_schema": relative.to_dict(),
        "source_width": BASE_WIDTH, "descriptor_width": WIDTH,
        "maximum_effective_raw_observation_seconds": 15., "history_lookback_seconds": LOOKBACK_SECONDS,
        "first_fixed_grid_endpoint_seconds": GRID_FIRST_ENDPOINT, "fixed_grid_stride_seconds": GRID_STRIDE_SECONDS,
        "mean": "Current vector once, plus committed grid vectors with endpoints in[query_end-10,query_end)",
        "difference": "current-relative170 minus oldest retained causal vector; zero if no history",
        "history_span_fraction": "(current endpoint-oldest retained endpoint)/10, clipped[0,1]; zero if no history",
        "warmup": "Current5s vector is always retained; context grows until10s prior grid span (15s total raw context). No past context is fabricated",
        "state": "Separate per original match; reset on a new half; no cross-match/cross-half pooling",
        "query": "Read-only. Build before committing that same endpoint. Off-grid eligible queries never mutate the actual2s-grid buffer",
        "commit": "Only actual endpoints5,7,9,...; copied vectors; chronological; retain5 most recent committed vectors for the next decision",
        "maximum_retained_vectors_per_match": MAX_PAST_VECTORS,
        "maximum_retained_vector_payload_bytes_per_match": MAX_PAST_VECTORS * BASE_WIDTH * np.dtype(np.float32).itemsize,
        "memory_note": "3400B numerical vectors +40B float64 timestamps per match; Python/container/name overhead and transient current/output vectors are additional",
        "labels": "Never read by the history builder; only original identity, split and observation time route state",
        "migration": "Supply current raw5s(75,215) through InvariantRepresentation('relative'), then CausalHistoryBuffer.query(current,end,match,half); score descriptor511, then commit current ONLY if this was an actual fixed-grid decision"}
    return DescriptorSchema(names, version=VERSION, builder_metadata=metadata)


def build_history_features(grid_rows, grid_vectors, query_rows=None, query_vectors=None):
    """Construct arbitrary causal queries without making off-grid queries state.

    Original eligible queries may be one second apart. The query is evaluated
    before same-timestamp grid commit, so matching endpoints are included ONCE.
    Output order matches input query order; source rows are never enriched.
    """
    grid_rows = list(grid_rows)
    grid_vectors = np.asarray(grid_vectors)
    if query_rows is None:
        if query_vectors is not None:
            raise ValueError("Query vectors require explicit query rows")
        query_rows, query_vectors = grid_rows, grid_vectors
    else:
        query_rows = list(query_rows)
        query_vectors = np.asarray(query_vectors)
    for values, rr in ((grid_vectors, grid_rows), (query_vectors, query_rows)):
        if values.shape != (len(rr), BASE_WIDTH) or values.dtype != np.float32 or not np.isfinite(values).all():
            raise ValueError("Aligned finite float32[rows,170] matrices required")
    groups, queries, match_splits = defaultdict(list), defaultdict(list), {}

    def identify(row):
        split = row.get("split")
        if split not in ("train", "valid"):
            raise ValueError("History construction permits only official train/valid rows")
        match, half, endpoint = _scope(row["match_id"], row["half"], row["observation_end_seconds"])
        if abs(endpoint - float(row["observation_start_seconds"]) - 5) > TOLERANCE:
            raise ValueError("Source descriptor must represent exactly the completed5s observation")
        if match in match_splits and match_splits[match] != split:
            raise ValueError("A match cannot cross official splits")
        match_splits[match] = split
        return (match, half), endpoint

    for i, row in enumerate(grid_rows):
        key, endpoint = identify(row)
        groups[key].append((endpoint, i))
    for i, row in enumerate(query_rows):
        key, endpoint = identify(row)
        if key not in groups:
            raise ValueError("Query has no same-half causal source grid")
        queries[key].append((endpoint, i))
    output = np.empty((len(query_rows), WIDTH), np.float32)
    for key, query_indices in queries.items():
        source = sorted(groups[key])
        times = np.asarray([time for time, _ in source])
        if (not len(times) or abs(times[0] - GRID_FIRST_ENDPOINT) > TOLERANCE
                or np.any(np.abs(np.diff(times) - GRID_STRIDE_SECONDS) > TOLERANCE)):
            raise ValueError("Full chronological two-second source grid beginning at5s required")
        buffer = CausalHistoryBuffer()
        pointer = 0
        for endpoint, i in sorted(query_indices):
            while pointer < len(source) and source[pointer][0] < endpoint - TOLERANCE:
                time, source_index = source[pointer]
                buffer.commit(grid_vectors[source_index], time, key[0], key[1])
                pointer += 1
            output[i] = buffer.query(query_vectors[i], endpoint, key[0], key[1])
    return output
