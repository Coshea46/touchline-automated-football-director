"""Portable numerical classifiers with no sklearn/pickle dependency at inference.

model.json binds the exact numerical payload by SHA-256; a release inventory
must independently verify the JSON. Both export and load validate the fixed
binary schema before prediction, including the complete numerical tree graph.
"""
import hashlib
import io
import json
from numbers import Integral, Real
from pathlib import Path
import numpy as np
from .representation import InvariantRepresentation

VERSION='matchpulse-research-tabular-v1'
TREE_FIELDS=('value','feature_idx','num_threshold','missing_go_to_left','left','right','is_leaf')
MAX_TREE_DEPTH=127
# Existing coverage selection uses nextafter(1,+inf) to exclude saturated ties.
MAX_THRESHOLD=float(np.nextafter(1.,np.inf))


def sigmoid(x):
    x=np.asarray(x,dtype=np.float64)
    result=np.empty_like(x);positive=x>=0
    result[positive]=1/(1+np.exp(-x[positive]))
    exp=np.exp(x[~positive]);result[~positive]=exp/(1+exp)
    return result


def _positive_integer(value,name):
    if not isinstance(value,Integral) or isinstance(value,(bool,np.bool_)) or value<1:
        raise ValueError(f'{name} must be a positive integer')
    return int(value)


def _threshold(metadata):
    if not isinstance(metadata,dict):raise ValueError('Classifier metadata must be a JSON object')
    threshold=metadata.get('threshold',.5)
    if not isinstance(threshold,Real) or isinstance(threshold,(bool,np.bool_)):
        raise ValueError('Classifier threshold must be finite and numeric')
    threshold=float(threshold)
    if not np.isfinite(threshold) or not 0<=threshold<=MAX_THRESHOLD:
        raise ValueError('Classifier threshold must be in [0,1], or nextafter(1,+inf) for forward-none')
    return threshold


def _float_array(arrays,key,shape):
    if key not in arrays:raise ValueError(f'Missing numerical classifier array {key}')
    a=arrays[key]
    if a.shape!=shape or a.dtype.kind not in 'fiu' or not np.isfinite(a).all():
        raise ValueError(f'Classifier array {key} must have shape {shape} and finite numeric values')
    return a


def _integer_array(arrays,key,shape,*,binary=False):
    if key not in arrays:raise ValueError(f'Missing numerical classifier array {key}')
    a=arrays[key]
    if a.shape!=shape or a.dtype.kind not in 'iub':
        raise ValueError(f'Classifier array {key} must have integer shape {shape}')
    if binary and not np.isin(a,[0,1]).all():raise ValueError(f'Classifier array {key} must contain binary flags')
    return a


def _validate_tree(arrays,prefix,width):
    key=prefix+'is_leaf'
    if key not in arrays or arrays[key].ndim!=1 or len(arrays[key])<1:
        raise ValueError('Each numerical tree must contain at least its root node')
    count=len(arrays[key]);shape=(count,)
    leaf=_integer_array(arrays,key,shape,binary=True).astype(bool)
    feature=_integer_array(arrays,prefix+'feature_idx',shape)
    left=_integer_array(arrays,prefix+'left',shape);right=_integer_array(arrays,prefix+'right',shape)
    _integer_array(arrays,prefix+'missing_go_to_left',shape,binary=True)
    _float_array(arrays,prefix+'value',shape)
    if prefix+'num_threshold' not in arrays:raise ValueError('Missing numeric split thresholds')
    thresholds=arrays[prefix+'num_threshold']
    # +/-inf is legitimate for sklearn numeric missingness-only splits.
    if thresholds.shape!=shape or thresholds.dtype.kind not in 'fiu' or np.isnan(thresholds).any():
        raise ValueError('Numeric split thresholds must have matching shape and cannot contain NaN')
    if np.any(feature<0) or np.any(feature>=width):raise ValueError('Tree feature indices exceed descriptor schema')
    if np.any(left<0) or np.any(right<0) or np.any(left>=count) or np.any(right>=count):
        raise ValueError('Tree child indices are out of bounds')
    if np.any(left[leaf]!=0) or np.any(right[leaf]!=0):
        raise ValueError('Canonical leaf nodes must have zero child placeholders')
    if np.any(left[~leaf]==right[~leaf]):raise ValueError('A nonleaf split must have two distinct children')
    parents=np.zeros(count,np.int64)
    np.add.at(parents,left[~leaf].astype(np.int64),1);np.add.at(parents,right[~leaf].astype(np.int64),1)
    if parents[0]!=0 or np.any(parents[1:]!=1):
        raise ValueError('Tree graph must have one root and one parent per nonroot node')
    seen=np.zeros(count,bool);pending=[(0,0)]
    while pending:
        node,depth=pending.pop()
        if seen[node] or depth>MAX_TREE_DEPTH:raise ValueError('Tree graph is cyclic or exceeds portable maximum depth')
        seen[node]=True
        if not leaf[node]:pending.extend([(int(left[node]),depth+1),(int(right[node]),depth+1)])
    if not seen.all():raise ValueError('Tree graph contains unreachable or cyclic nodes')


def _validate_schema(config,arrays,representation):
    if config.get('version')!=VERSION:raise ValueError('Unsupported research classifier version')
    if config.get('classes')!=[0,1] or config.get('positive_label')!=1:
        raise ValueError('Portable classifier requires binary classes [0,1] and positive label 1')
    if config.get('raw_input_shape')!=[75,215] or config.get('raw_input_dtype')!='float32':
        raise ValueError('Portable classifier raw input contract changed')
    if config.get('threshold_comparator')!='>=':raise ValueError('Portable classifier requires score >= threshold comparison')
    _threshold(config.get('metadata'))
    architecture=config.get('architecture')
    if not isinstance(architecture,dict):raise ValueError('Classifier architecture must be a JSON object')
    width=_positive_integer(architecture.get('input_size'),'Descriptor input_size')
    if width!=len(representation.names):raise ValueError('Estimator feature width disagrees with exact representation schema')
    _validate_numerical(architecture,arrays,expected_width=len(representation.names))


def _validate_numerical(architecture,arrays,*,expected_width):
    """Shared binary numerical core; declares no raw-window input contract."""
    if not isinstance(architecture,dict):raise ValueError('Classifier architecture must be a JSON object')
    width=_positive_integer(architecture.get('input_size'),'Descriptor input_size')
    if width!=expected_width:raise ValueError('Estimator feature width disagrees with exact descriptor schema')
    kind=architecture.get('kind')
    if kind=='linear':
        if set(architecture)!={'kind','input_size'}:raise ValueError('Unknown linear architecture fields')
        keys=set(arrays);expected={'coef','intercept'}
        if 'mean' in keys or 'scale' in keys:expected|={'mean','scale'}
        if keys!=expected:raise ValueError('Unexpected or incomplete linear numerical arrays')
        _float_array(arrays,'coef',(width,));_float_array(arrays,'intercept',())
        if 'mean' in arrays:
            _float_array(arrays,'mean',(width,));scale=_float_array(arrays,'scale',(width,))
            if np.any(scale<=0):raise ValueError('Saved normalization scales must be strictly positive')
    elif kind=='hist_gradient_boosting':
        if set(architecture)!={'kind','input_size','trees'}:raise ValueError('Unknown histogram architecture fields')
        trees=_positive_integer(architecture.get('trees'),'Number of histogram trees')
        if len(arrays)!=1+len(TREE_FIELDS)*trees:raise ValueError('Histogram tree array count disagrees with architecture')
        expected={'initial_logit'}|{f'tree_{i}_{field}' for i in range(trees) for field in TREE_FIELDS}
        if set(arrays)!=expected:raise ValueError('Unexpected or incomplete histogram numerical arrays')
        _float_array(arrays,'initial_logit',())
        for i in range(trees):_validate_tree(arrays,f'tree_{i}_',width)
    else:raise ValueError('Unsupported numerical classifier architecture')


def _estimator_arrays(estimator,*,scaler=None):
    """Convert fitted sklearn objects during export only; runtime stays NumPy-only."""
    classes=np.asarray(getattr(estimator,'classes_',[]))
    if classes.shape!=(2,) or not np.array_equal(classes,[0,1]):
        raise ValueError('Only fitted binary classifiers with classes [0,1] are supported')
    width=_positive_integer(getattr(estimator,'n_features_in_',None),'Fitted estimator feature width')
    arrays={};architecture={}
    if hasattr(estimator,'coef_'):
        coef=np.asarray(estimator.coef_,np.float64);intercept=np.asarray(estimator.intercept_,np.float64)
        if coef.shape!=(1,width) or intercept.shape!=(1,):raise ValueError('Binary linear coefficients/intercept have unsupported shapes')
        architecture={'kind':'linear','input_size':width}
        arrays.update(coef=coef[0].copy(),intercept=np.asarray(intercept[0],np.float64))
        if scaler is not None:
            if getattr(scaler,'n_features_in_',None)!=width or not all(hasattr(scaler,k) for k in ('with_mean','with_std','mean_','scale_')):
                raise ValueError('A fitted matching StandardScaler is required')
            arrays.update(mean=np.asarray(scaler.mean_,np.float64) if scaler.with_mean else np.zeros(width,np.float64),
                scale=np.asarray(scaler.scale_,np.float64) if scaler.with_std else np.ones(width,np.float64))
    elif hasattr(estimator,'_predictors'):
        if scaler is not None:raise ValueError('Histogram model export does not accept an external scaler')
        architecture={'kind':'hist_gradient_boosting','input_size':width,'trees':len(estimator._predictors)}
        baseline=np.asarray(estimator._baseline_prediction,np.float64)
        if baseline.shape!=(1,1):raise ValueError('Unsupported binary histogram intercept shape')
        arrays['initial_logit']=np.asarray(baseline[0,0],np.float64)
        for i,predictors in enumerate(estimator._predictors):
            if len(predictors)!=1:raise ValueError('Only one tree per binary boosting iteration supported')
            nodes=predictors[0].nodes
            if np.any(nodes['is_categorical']):raise ValueError('Categorical splits require a new runtime version')
            for field in TREE_FIELDS:
                arrays[f'tree_{i}_{field}']=np.array(nodes[field],copy=True)
            # Canonicalize copied unused leaf placeholders without changing predictions.
            leaf=arrays[f'tree_{i}_is_leaf'].astype(bool)
            for field in ('feature_idx','num_threshold','missing_go_to_left','left','right'):
                arrays[f'tree_{i}_{field}'][leaf]=0
    else:raise ValueError('Unsupported estimator')
    return architecture,arrays


def export_estimator(directory,estimator,*,representation,metadata,scaler=None):
    """Export the strict raw215 observation representation and a binary classifier."""
    if not isinstance(representation,InvariantRepresentation):raise ValueError('A versioned InvariantRepresentation is required')
    architecture,arrays=_estimator_arrays(estimator,scaler=scaler)
    config={'version':VERSION,'architecture':architecture,'representation':representation.to_dict(),
        'classes':[0,1],'positive_label':1,'threshold_comparator':'>=',
        'metadata':metadata,'raw_input_shape':[75,215],'raw_input_dtype':'float32',
        'score_semantics':'Uncalibrated interest ranking score; sigmoid of binary decision logit/margin'}
    _validate_schema(config,arrays,representation)
    buffer=io.BytesIO();np.savez_compressed(buffer,**arrays);payload=buffer.getvalue()
    config['weights_sha256']=hashlib.sha256(payload).hexdigest()
    serialized=json.dumps(config,indent=2,allow_nan=False)+'\n'
    # Validation precedes directory creation, so invalid exports leave no final model.
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
    (directory/'weights.npz').write_bytes(payload)
    (directory/'model.json').write_text(serialized,encoding='utf-8')
    return directory


def _load_arrays(directory,config):
    """Read only SHA-bound, non-pickle numerical arrays, shared by both contracts."""
    expected=config.get('weights_sha256')
    if not isinstance(expected,str) or len(expected)!=64 or any(c not in '0123456789abcdef' for c in expected):
        raise ValueError('A valid weights SHA-256 is required in model.json')
    payload=(Path(directory)/'weights.npz').read_bytes()
    if hashlib.sha256(payload).hexdigest()!=expected:raise ValueError('Classifier weights SHA-256 integrity check failed')
    with np.load(io.BytesIO(payload),allow_pickle=False) as data:
        if len(data.files)!=len(set(data.files)):raise ValueError('Duplicate numerical classifier array names')
        return {key:data[key] for key in data.files}


def _predict_numerical(features,architecture,arrays):
    """Execute an already validated binary numerical model, without a builder."""
    x=np.asarray(features,dtype=np.float64)
    if x.ndim!=2 or x.shape[1]!=architecture['input_size'] or not np.isfinite(x).all():
        raise ValueError('Finite [batch,descriptor_width] input required')
    a=arrays
    if architecture['kind']=='linear':
        if 'mean' in a:
            with np.errstate(over='ignore',invalid='ignore',divide='ignore'):x=(x-a['mean'])/a['scale']
            if not np.isfinite(x).all():raise ValueError('Saved normalization produced nonfinite descriptors')
        with np.errstate(over='ignore',invalid='ignore'):logits=x@a['coef']+a['intercept']
    elif architecture['kind']=='hist_gradient_boosting':
        logits=np.full(len(x),float(a['initial_logit']),np.float64)
        for i in range(architecture['trees']):
            prefix=f'tree_{i}_';nodes=np.zeros(len(x),np.int64)
            for depth in range(MAX_TREE_DEPTH+1):
                leaf=a[prefix+'is_leaf'][nodes].astype(bool)
                if leaf.all():break
                ix=np.flatnonzero(~leaf);at=nodes[ix]
                value=x[ix,a[prefix+'feature_idx'][at].astype(np.int64)]
                left=value<=a[prefix+'num_threshold'][at]
                nodes[ix]=np.where(left,a[prefix+'left'][at],a[prefix+'right'][at])
            else:raise ValueError('Invalid cyclic/deep tree in portable model')
            with np.errstate(over='ignore',invalid='ignore'):logits+=a[prefix+'value'][nodes]
    else:raise ValueError('Unsupported architecture')
    if not np.isfinite(logits).all():raise ValueError('Classifier produced nonfinite decision values')
    return sigmoid(logits)


class TabularClassifier:
    def __init__(self,directory):
        directory=Path(directory)
        self.config=json.loads((directory/'model.json').read_text(encoding='utf-8'))
        if not isinstance(self.config,dict) or self.config.get('version')!=VERSION:raise ValueError('Unsupported research classifier version')
        try:self.representation=InvariantRepresentation.from_dict(self.config['representation'])
        except (KeyError,TypeError) as exc:raise ValueError('Incomplete versioned representation schema') from exc
        self.arrays=_load_arrays(directory,self.config)
        _validate_schema(self.config,self.arrays,self.representation)
        self.architecture=self.config['architecture'];self.metadata=self.config['metadata']
        self.threshold=_threshold(self.metadata)
        for array in self.arrays.values():array.flags.writeable=False

    def predict_descriptors(self,features):
        return _predict_numerical(features,self.architecture,self.arrays)

    def predict_batch(self,raw):
        raw=np.asarray(raw)
        if raw.ndim!=3 or raw.shape[1:]!=(75,215) or raw.dtype!=np.float32:
            raise ValueError('Expected raw float32 [batch,75,215] features')
        from matchpulse.features.schema import validate
        for row in raw:validate(row,steps=75)
        return self.predict_descriptors(self.representation.transform(raw))

    def predict(self,raw):return float(self.predict_batch(np.asarray(raw)[None])[0])


def load_research_classifier(directory):return TabularClassifier(directory)
