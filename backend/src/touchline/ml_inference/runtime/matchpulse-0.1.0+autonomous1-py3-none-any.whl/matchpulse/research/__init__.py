"""Versioned research-only feature and product evaluation tools."""
