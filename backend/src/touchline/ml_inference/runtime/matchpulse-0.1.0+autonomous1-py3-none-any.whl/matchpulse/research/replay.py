"""Causal validation-only concurrent-match replay.

Policies receive scores available at each fixed observation endpoint, never labels
or events. Event annotations are consumed only after all selections are frozen.
The default rejects missing scores, including label-dependent ignored-window gaps.
Halves are replay sessions of the SAME independent matches, never extra matches.
"""

from collections import defaultdict
from dataclasses import asdict, dataclass

import numpy as np

REPLAY_VERSION = "matchpulse-director-replay-v1"
SHOT_TYPES = frozenset(("Shots on target", "Shots off target", "Goal"))
SCOPES = {
    "all_qualifying": None,
    "shot_attempts": SHOT_TYPES,
    "shots_on_target_or_goal": frozenset(("Shots on target", "Goal")),
    "goals": frozenset(("Goal",)),
}


@dataclass(frozen=True)
class ReplayConfig:
    """Frozen policy/evaluation choices, independent of validation outcomes.

    The 0.25 log-odds staying bonus multiplies current-match odds by exp(.25).
    Annotation proximity measures viewing context; it is not a claim that all
    other football footage is uninteresting.
    """

    observation_seconds: float = 5.0
    decision_stride_seconds: float = 2.0
    staying_bonus_logit: float = 0.25
    round_robin_dwell_seconds: float = 30.0
    minimum_anticipation_seconds: float = 3.0
    maximum_anticipation_seconds: float = 10.0
    event_context_before_seconds: float = 10.0
    event_context_after_seconds: float = 3.0
    unnecessary_switch_horizon_seconds: float = 10.0
    prediction_latency_seconds: float = 0.0
    adaptive_history_seconds: float = 300.0
    adaptive_warmup_seconds: float = 30.0
    include_centered_policies: bool = False
    seed: int = 42
    require_full_grid: bool = True

    def __post_init__(self):
        if self.observation_seconds != 5 or self.decision_stride_seconds != 2:
            raise ValueError("This replay version requires five-second observations and two-second decisions")
        if self.round_robin_dwell_seconds <= 0 or self.staying_bonus_logit < 0:
            raise ValueError("Invalid fixed policy settings")
        if not 0 <= self.minimum_anticipation_seconds <= self.maximum_anticipation_seconds:
            raise ValueError("Invalid anticipation interval")
        if min(self.event_context_before_seconds, self.event_context_after_seconds,
               self.unnecessary_switch_horizon_seconds) < 0:
            raise ValueError("Invalid event-context duration")
        if not np.isfinite(self.prediction_latency_seconds) or self.prediction_latency_seconds < 0:
            raise ValueError("Prediction latency must be finite and nonnegative")
        if (not np.isfinite([self.adaptive_warmup_seconds, self.adaptive_history_seconds]).all()
                or not 0 <= self.adaptive_warmup_seconds <= self.adaptive_history_seconds
                or self.adaptive_history_seconds <= 0):
            raise ValueError("Invalid causal adaptive-history duration")


@dataclass
class _Session:
    half: int
    end: float
    prediction_times: np.ndarray
    times: np.ndarray
    lengths: np.ndarray
    scores: dict
    supported: np.ndarray
    prediction_endpoints: dict


@dataclass
class _Grid:
    matches: list
    sessions: list
    support: dict
    config: ReplayConfig


def _time_key(value):
    return round(float(value), 6)


def _prepare(rows, scores_by_model, half_durations, config):
    if not rows or not scores_by_model:
        raise ValueError("Nonempty validation rows and model predictions are required")
    if any(row.get("split") != "valid" for row in rows):
        raise ValueError("Replay may use only official validation matches")
    matches = sorted({row["match_id"] for row in rows})
    if len(matches) < 2:
        raise ValueError("At least two independent match IDs are required; halves are not matches")
    models = {}
    for name, values in scores_by_model.items():
        scores = np.asarray(values, dtype=np.float64)
        if scores.shape != (len(rows),) or np.isinf(scores).any():
            raise ValueError("One finite or explicitly unavailable score is required per row")
        finite = np.isfinite(scores)
        if np.any((scores[finite] < 0) | (scores[finite] > 1)):
            raise ValueError("Director scores must be in [0,1]")
        models[str(name)] = scores
    by_key = {}
    halves = defaultdict(set)
    row_ends = defaultdict(list)
    for i, row in enumerate(rows):
        end = float(row["observation_end_seconds"])
        start = float(row["observation_start_seconds"])
        if not np.isfinite([start, end]).all() or abs(end - start - 5) > 1e-6 or start < -1e-6:
            raise ValueError("Every prediction must use an existing five-second causal observation")
        key = (row["match_id"], int(row["half"]), _time_key(end))
        if key in by_key:
            raise ValueError("Duplicate match/half/endpoint prediction")
        by_key[key] = i
        halves[row["match_id"]].add(int(row["half"]))
        row_ends[key[:2]].append(end)
    common_halves = sorted(set.intersection(*(halves[m] for m in matches)))
    if not common_halves:
        raise ValueError("Independent matches have no common recorded half")
    provided_durations = half_durations is not None
    durations = half_durations or {k: max(v) for k, v in row_ends.items()}
    sessions, missing = [], []
    for half in common_halves:
        lengths = [float(durations[(m, half)]) for m in matches]
        if not np.isfinite(lengths).all() or min(lengths) <= config.observation_seconds + config.prediction_latency_seconds:
            raise ValueError("Finite source-half durations must leave replay time after observation and latency")
        end = min(lengths)
        prediction_times = np.arange(config.observation_seconds,
            end - config.prediction_latency_seconds - 1e-7, config.decision_stride_seconds)
        times = prediction_times + config.prediction_latency_seconds
        period_lengths = np.minimum(config.decision_stride_seconds, end - times)
        values = {n: np.full((len(times), len(matches)), np.nan) for n in models}
        endpoints = {n: np.full((len(times), len(matches)), np.nan) for n in models}
        for t, time in enumerate(prediction_times):
            for m, match in enumerate(matches):
                i = by_key.get((match, half, _time_key(time)))
                if i is None:
                    if len(missing) < 16:
                        missing.append({"match_id": match, "half": half, "prediction_endpoint": float(time)})
                    continue
                for name, scores in models.items():
                    values[name][t, m] = scores[i]
                    if np.isfinite(scores[i]):
                        endpoints[name][t, m] = float(rows[i]["observation_end_seconds"])
        supported = np.ones(len(times), bool)
        for scores in values.values():
            supported &= np.isfinite(scores).all(axis=1)
        sessions.append(_Session(half, end, prediction_times, times, period_lengths, values, supported, endpoints))
    total = sum(len(s.times) for s in sessions)
    supported = sum(int(s.supported.sum()) for s in sessions)
    wall_seconds = sum(float(s.lengths.sum()) for s in sessions)
    supported_seconds = sum(float(s.lengths[s.supported].sum()) for s in sessions)
    support = {
        "independent_match_count": len(matches),
        "independent_match_ids": matches,
        "seven_independent_matches_available": len(matches) >= 7,
        "limitation": None if len(matches) >= 7 else
            f"Only {len(matches)} independent validation matches; this is not a seven-match validation.",
        "half_sessions": common_halves,
        "halves_are_not_independent_matches": True,
        "timeline_alignment": "Same half-local playback clock; halftime resets policy state, excludes halftime gaps",
        "duration_source": "provided video source durations" if provided_durations else
            "last available prediction endpoint (lower bound; source duration was not provided)",
        "half_ends": {str(s.half): s.end for s in sessions},
        "session_duration_rule": "Stop each half at the shortest source half among simultaneous matches",
        "first_prediction_endpoint_seconds": config.observation_seconds,
        "first_decision_seconds": config.observation_seconds + config.prediction_latency_seconds,
        "initial_match_rule": "Lexicographic first match before first prediction; fixed-stay baselines each use their named match",
        "latency_assumption": f"Fixed {config.prediction_latency_seconds:g}s modeled scoring/switch delay; not a measured serving latency benchmark",
        "warmup_seconds_excluded_per_half": config.observation_seconds + config.prediction_latency_seconds,
        "decision_count": total,
        "complete_score_decisions": supported,
        "complete_score_decision_fraction": supported / total if total else None,
        "output_viewing_seconds": wall_seconds,
        "complete_score_output_seconds": supported_seconds,
        "complete_score_output_fraction": supported_seconds / wall_seconds if wall_seconds else None,
        "all_score_grid_complete": supported == total,
        "first_missing_endpoints": missing,
        "gaps_note": "No interpolation, future scores, or missing-as-zero scores. With incomplete support "
            "every policy freezes its last match; gap-dependent successes are exploratory only. "
            "Verified event metrics require complete score support from up to 10s before the event through its instant.",
    }
    if config.require_full_grid and supported != total:
        raise ValueError(
            f"Replay grid incomplete ({supported}/{total} decisions). Score label-independent windows, "
            "including ignored intervals; sparse supervised predictions cannot verify full replay."
        )
    return _Grid(matches, sessions, support, config)


def _schedule(grid, policy, model_name=None, *, initial_match=None, seed=None):
    """The complete policy implementation: labels/events never enter this call."""
    config = grid.config
    rng = np.random.default_rng(config.seed if seed is None else seed)
    if initial_match is not None and initial_match not in grid.matches:
        raise ValueError("Initial match must be a validation match in the replay")
    initial = grid.matches.index(initial_match) if initial_match is not None else 0
    schedules = []
    for session in grid.sessions:
        current = initial
        selections = np.zeros(len(session.times), dtype=np.int64)
        run_start = np.zeros(len(session.times), dtype=np.int64)
        switched = np.zeros(len(session.times), dtype=bool)
        start_index = 0
        for i, time in enumerate(session.times):
            chosen = current
            if session.supported[i]:
                if policy in ("score", "score_centered"):
                    scores = session.scores[model_name][i]
                    q = np.clip(scores, 1e-7, 1 - 1e-7)
                    utility = np.log(q) - np.log1p(-q)
                    if policy == "score_centered":
                        endpoint = session.prediction_times[i]
                        lo = int(np.searchsorted(session.prediction_times,
                            endpoint - config.adaptive_history_seconds, side="left"))
                        for m in range(len(grid.matches)):
                            # Current and future scores are excluded from their own
                            # baseline. Warmup is observed support, not future labels.
                            history = session.scores[model_name][lo:i, m]
                            history = history[np.isfinite(history)]
                            if len(history) * config.decision_stride_seconds >= config.adaptive_warmup_seconds and len(history):
                                previous = np.clip(history, 1e-7, 1 - 1e-7)
                                utility[m] -= float(np.median(np.log(previous) - np.log1p(-previous)))
                    utility[current] += config.staying_bonus_logit
                    chosen = int(np.argmax(utility))
                elif policy == "random":
                    chosen = int(rng.integers(len(grid.matches)))
                elif policy == "round_robin":
                    chosen = int((time - session.times[0]) // config.round_robin_dwell_seconds) % len(grid.matches)
                elif policy != "stay":
                    raise ValueError(f"Unknown policy {policy}")
            if chosen != current:
                switched[i] = True
                start_index = i
            current = chosen
            selections[i] = chosen
            run_start[i] = start_index
        schedules.append({"half": session.half, "selected": selections, "run_start": run_start, "switched": switched})
    return schedules


def _incidents(events, matches, halves, allowed_types=None):
    """Retain original grouping while using the relevant original event timestamps."""
    groups = {}
    for event in events:
        if event["match_id"] not in matches or int(event["half"]) not in halves:
            continue
        if event.get("split", "valid") != "valid":
            raise ValueError("Replay annotations must belong to official validation matches")
        if not event.get("qualifying", False):
            continue
        if allowed_types is not None and event["event_type"] not in allowed_types:
            continue
        group_id = event.get("evaluation_group_id")
        if not group_id:
            raise ValueError("Original evaluation_group_id is required; replay never regroups labels")
        key = (event["match_id"], int(event["half"]), group_id)
        group = groups.setdefault(key, {"id": group_id, "match_id": key[0], "half": key[1],
            "timestamp": float(event["timestamp_seconds"]), "types": set(), "event_ids": []})
        group["timestamp"] = min(group["timestamp"], float(event["timestamp_seconds"]))
        group["types"].add(event["event_type"])
        group["event_ids"].append(event["event_id"])
    return sorted(groups.values(), key=lambda g: (g["half"], g["timestamp"], g["match_id"], g["id"]))


def _union_overlap(start, end, intervals):
    total = 0.0
    cursor = start
    for a, b in intervals:
        if b <= cursor or a >= end:
            continue
        a, b = max(cursor, a), min(end, b)
        if b > a:
            total += b - a
            cursor = b
    return total


def _scope_metrics(grid, schedules, incidents):
    config = grid.config
    by_half = {s.half: (s, schedule) for s, schedule in zip(grid.sessions, schedules, strict=True)}
    events_by_half_match = defaultdict(list)
    for event in incidents:
        events_by_half_match[(event["half"], event["match_id"])].append(event["timestamp"])
    cases, per_match = [], {}
    for match in grid.matches:
        per_match[match] = {"available_incidents": 0, "incidents_in_replay": 0,
            "complete_support_incidents": 0, "verified_shown": 0, "exploratory_shown": 0}
    for event in incidents:
        session, schedule = by_half[event["half"]]
        time = event["timestamp"]
        stats = per_match[event["match_id"]]
        stats["available_incidents"] += 1
        if time < session.times[0] or time >= session.end:
            cases.append({"id": event["id"], "match_id": event["match_id"], "half": event["half"],
                "timestamp": time, "in_replay": False, "shown_verified": False,
                "types": sorted(event["types"]), "event_ids": event["event_ids"]})
            continue
        i = int(np.searchsorted(session.times, time, side="right") - 1)
        lo = max(0, int(np.searchsorted(session.times, time - config.maximum_anticipation_seconds, side="right") - 1))
        complete = bool(session.supported[lo:i + 1].all())
        chosen = grid.matches[int(schedule["selected"][i])]
        shown = chosen == event["match_id"]
        run = int(schedule["run_start"][i])
        segment_start = float(session.times[run])
        lead = max(0.0, time - segment_start) if shown else None
        switch_anticipation = bool(shown and schedule["switched"][run]
            and config.minimum_anticipation_seconds <= lead <= config.maximum_anticipation_seconds)
        stats["incidents_in_replay"] += 1
        stats["complete_support_incidents"] += int(complete)
        stats["verified_shown"] += int(shown and complete)
        stats["exploratory_shown"] += int(shown)
        cases.append({"id": event["id"], "match_id": event["match_id"], "half": event["half"],
            "timestamp": time, "types": sorted(event["types"]), "event_ids": event["event_ids"],
            "in_replay": True, "complete_score_support": complete, "selected_match_at_event": chosen,
            "shown_exploratory": shown, "shown_verified": shown and complete,
            "viewing_segment_start": segment_start if shown else None,
            "preselection_lead_seconds": lead,
            "preselection_lead_capped10_seconds": min(lead, config.maximum_anticipation_seconds) if lead is not None else None,
            "newly_anticipated_via_switch": switch_anticipation and complete})
    included = [e for e in cases if e["in_replay"]]
    supported = [e for e in included if e["complete_score_support"]]
    shown = [e for e in included if e["shown_verified"]]
    leads = [e["preselection_lead_capped10_seconds"] for e in shown]
    useful_choices = choices = competing = best_competing = any_competing = 0
    informative_seconds = total_seconds = supported_seconds = context_seconds = 0.0
    switches = unnecessary = regretted = 0
    for session, schedule in zip(grid.sessions, schedules, strict=True):
        per_match_times = {m: np.asarray(events_by_half_match[(session.half, m)]) for m in grid.matches}
        contexts = {m: sorted((t - config.event_context_before_seconds, t + config.event_context_after_seconds)
            for t in per_match_times[m]) for m in grid.matches}
        for i, time in enumerate(session.times):
            duration = float(session.lengths[i])
            selected = grid.matches[int(schedule["selected"][i])]
            total_seconds += duration
            if not session.supported[i]:
                continue
            supported_seconds += duration
            informative_seconds += _union_overlap(float(time), float(time + duration), contexts[selected])
            context_seconds += duration
            upcoming = {}
            for match, times in per_match_times.items():
                leads_here = times - time
                relevant = leads_here[(leads_here >= config.minimum_anticipation_seconds)
                    & (leads_here <= config.maximum_anticipation_seconds)]
                if len(relevant):
                    upcoming[match] = float(relevant.min())
            if upcoming:
                choices += 1
                useful_choices += int(selected in upcoming)
            if len(upcoming) >= 2:
                competing += 1
                any_competing += int(selected in upcoming)
                earliest = min(upcoming.values())
                best_competing += int(selected in upcoming and upcoming[selected] <= earliest + 1e-6)
            if schedule["switched"][i]:
                switches += 1
                future = per_match_times[selected] - time
                good = np.any((future >= 0) & (future <= config.unnecessary_switch_horizon_seconds))
                unnecessary += int(not good)
                old_match = grid.matches[int(schedule["selected"][i - 1])] if i else grid.matches[0]
                old_future = per_match_times[old_match] - time
                regretted += int(not good and np.any((old_future >= 0)
                    & (old_future <= config.unnecessary_switch_horizon_seconds)))
    for stats in per_match.values():
        stats["shown_fraction_all_available_lower_bound"] = stats["verified_shown"] / stats["available_incidents"] if stats["available_incidents"] else None
        stats["shown_fraction_on_complete_support"] = stats["verified_shown"] / stats["complete_support_incidents"] if stats["complete_support_incidents"] else None
    macro_supported = [stats["shown_fraction_on_complete_support"] for stats in per_match.values()
                       if stats["shown_fraction_on_complete_support"] is not None]
    macro_available = [stats["shown_fraction_all_available_lower_bound"] for stats in per_match.values()
                       if stats["shown_fraction_all_available_lower_bound"] is not None]
    return {
        "available_incident_groups": len(cases),
        "incident_groups_in_replay": len(included),
        "incident_groups_outside_common_playback": len(cases) - len(included),
        "complete_support_incident_groups": len(supported),
        "verified_shown_incident_groups": len(shown),
        "missed_incident_groups_on_complete_support": len(supported) - len(shown),
        "shown_fraction_on_complete_support": len(shown) / len(supported) if supported else None,
        "shown_fraction_all_available_lower_bound": len(shown) / len(cases) if cases else None,
        "macro_match_shown_fraction_on_complete_support": float(np.mean(macro_supported)) if macro_supported else None,
        "macro_match_shown_fraction_all_available_lower_bound": float(np.mean(macro_available)) if macro_available else None,
        "macro_match_count_with_complete_support_incidents": len(macro_supported),
        "macro_match_count_with_available_incidents": len(macro_available),
        "exploratory_shown_fraction_including_gap_holds": sum(e["shown_exploratory"] for e in included) / len(included) if included else None,
        "shown_with_at_least_3s_preselection": sum(e["preselection_lead_seconds"] >= config.minimum_anticipation_seconds for e in shown),
        "newly_anticipated_via_switch": sum(e["newly_anticipated_via_switch"] for e in shown),
        "mean_preselection_lead_capped10_seconds_for_shown": float(np.mean(leads)) if leads else None,
        "preselection_lead_capped10_quantiles": np.quantile(leads, [0, .25, .5, .75, 1]).tolist() if leads else None,
        "switches": switches,
        "switches_per_output_minute": switches / (total_seconds / 60) if total_seconds else None,
        "unnecessary_switches_proxy": unnecessary,
        "unnecessary_switch_fraction_proxy": unnecessary / switches if switches else None,
        "switch_regret_proxy": regretted,
        "uneventful_footage_seconds_proxy_on_complete_scores": max(0.0, context_seconds - informative_seconds),
        "uneventful_footage_fraction_proxy_on_complete_scores": 1 - informative_seconds / context_seconds if context_seconds else None,
        "upcoming_event_decisions": choices,
        "selected_upcoming_event_match_decisions": useful_choices,
        "upcoming_event_selection_accuracy": useful_choices / choices if choices else None,
        "competing_upcoming_event_decisions": competing,
        "earliest_event_match_selected_in_competition": best_competing,
        "earliest_event_selection_accuracy_in_competition": best_competing / competing if competing else None,
        "any_event_match_selection_accuracy_in_competition": any_competing / competing if competing else None,
        "per_match": per_match,
        "cases": cases,
    }


def _evaluate(grid, schedules, events, *, include_trace):
    scopes = {name: _scope_metrics(grid, schedules,
        _incidents(events, grid.matches, set(grid.support["half_sessions"]), allowed_types))
        for name, allowed_types in SCOPES.items()}
    viewing = {match: 0.0 for match in grid.matches}
    supported_viewing = viewing.copy()
    for session, schedule in zip(grid.sessions, schedules, strict=True):
        for i, selected in enumerate(schedule["selected"]):
            match = grid.matches[int(selected)]
            viewing[match] += float(session.lengths[i])
            if session.supported[i]:
                supported_viewing[match] += float(session.lengths[i])
    seconds = sum(viewing.values())
    supported_seconds = sum(supported_viewing.values())
    result = {"scopes": scopes, "viewing_seconds_by_match": viewing,
        "viewing_fraction_by_match": {m: t / seconds for m, t in viewing.items()},
        "complete_support_viewing_seconds_by_match": supported_viewing,
        "complete_support_viewing_fraction_by_match": {m: t / supported_seconds if supported_seconds else None
            for m, t in supported_viewing.items()}}
    if include_trace:
        result["trace"] = [{"half": session.half,
            "prediction_endpoint_seconds": float(session.prediction_times[i]),
            "prediction_available_seconds": float(time),
            "display_start_seconds": float(time), "display_end_seconds": float(time + session.lengths[i]),
            "selected_match": grid.matches[int(schedule["selected"][i])],
            "complete_score_support": bool(session.supported[i]), "switched": bool(schedule["switched"][i])}
            for session, schedule in zip(grid.sessions, schedules, strict=True) for i, time in enumerate(session.times)]
    return result


def _random_summary(results):
    scopes = {}
    for scope in SCOPES:
        scalars = {}
        for key, value in results[0]["scopes"][scope].items():
            if key in ("cases", "per_match") or value is None or not isinstance(value, (int, float)):
                continue
            samples = [r["scopes"][scope][key] for r in results]
            if any(v is None for v in samples):
                continue
            scalars[key] = {"mean": float(np.mean(samples)),
                "quantiles_2p5_50_97p5": np.quantile(samples, [.025, .5, .975]).tolist()}
        scopes[scope] = scalars
    return {"scopes": scopes, "note": "Seeded conditional Monte Carlo variability; not a population confidence interval"}


def compare_policies(rows, scores_by_model, events, *, half_durations=None, config=None,
                     random_repeats=32, include_trace=True):
    """Compare frozen policies on synchronized independent validation matches.

    `rows` is a label-independent five-second grid ending at 5,7,9,... seconds;
    each row retains match_id, half, split='valid', observation_start_seconds,
    observation_end_seconds. Model score arrays align exactly with these rows.
    `half_durations` maps (original_match_id, half) to the actual source duration.

    Every candidate uses identical common support. Scoring-only supervised rows
    should fail the default full-grid gate; do not claim actual director quality
    from exclusions defined using future labels. Setting require_full_grid=False
    yields explicitly conservative supported metrics plus exploratory gap holds.
    """
    config = config or ReplayConfig()
    if random_repeats < 1:
        raise ValueError("At least one seeded random replay is required")
    grid = _prepare(rows, scores_by_model, half_durations, config)
    policies = {}
    for match in grid.matches:
        schedules = _schedule(grid, "stay", initial_match=match)
        policies["stay::" + match] = _evaluate(grid, schedules, events, include_trace=include_trace)
    policies["round_robin"] = _evaluate(grid, _schedule(grid, "round_robin"), events, include_trace=include_trace)
    for name in scores_by_model:
        schedules = _schedule(grid, "score", str(name))
        policies["score::" + str(name)] = _evaluate(grid, schedules, events, include_trace=include_trace)
        if config.include_centered_policies:
            centered = _schedule(grid, "score_centered", str(name))
            policies["score_centered::" + str(name)] = _evaluate(grid, centered, events, include_trace=include_trace)
    random_results = [_evaluate(grid, _schedule(grid, "random", seed=config.seed + i), events, include_trace=False)
                      for i in range(random_repeats)]
    return {
        "replay_version": REPLAY_VERSION,
        "configuration": asdict(config),
        "support": grid.support,
        "policies": policies,
        "random": {"repeats": random_repeats, "seeds": list(range(config.seed, config.seed + random_repeats)),
            "summary": _random_summary(random_results),
            "trials": [{"scopes": {s: {k: v for k, v in r["scopes"][s].items() if k not in ("cases", "per_match")}
                for s in SCOPES}} for r in random_results]},
        "test_used": False,
        "definitions": {
            "event_shown": "Selected match at the ORIGINAL incident timestamp, not merely a pre-event alert",
            "scoped_timestamps": "Original evaluation groups, earliest timestamp among annotations included in each scope; goals use actual Goal timestamps",
            "anticipation": "Contiguous viewing segment reaches the event. Preselection lead is capped at 10s; already watching is distinguished from a new 3–10s anticipatory switch",
            "policy_input": "Only causal endpoint scores and previous selection; no future events, labels, or future predictions",
            "adaptive_centering": f"Optional separate score_centered policies subtract the per-match median of PREVIOUS observed logits in the last {config.adaptive_history_seconds:g}s; baseline subtraction is zero until {config.adaptive_warmup_seconds:g}s observed support, then the same {config.staying_bonus_logit:g} staying bonus applies. AP/forwarding scores are unchanged",
            "prediction_latency": "Input grid remains endpoints5,7,9,...; score at endpoint t can change display only at t+configured latency. Actions beyond source-session end are dropped, and original prediction endpoints are retained",
            "competition": "At least two independent matches have a qualifying event 3–10s ahead; accuracy selects the soonest event (ties accepted)",
            "uneventful_footage_proxy": "Selected footage outside original annotation intervals [event−10s,event+3s]; not semantic excitement ground truth",
            "unnecessary_switch_proxy": "New match has no qualifying event in [switch,switch+10s]; evaluated after causal decisions",
            "uncertainty": "Random trials are conditional on these matches. Independent-match count, not windows/halves, determines generalization evidence",
            "fixed_stay_baseline": "Every named match is replayed as a fixed choice. Their mean is the predeclared uniform fixed-choice baseline; selecting the best after reading outcomes is a retrospective oracle, not a causal prediction policy",
            "macro_match_metrics": "Average each match's shown-event fraction with equal weight. A match with zero incidents in that scope is excluded only for that scope; included match counts are explicit",
        },
    }
