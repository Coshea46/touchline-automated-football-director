"""Causal, label-free summaries of raw observation features for small CPU models.

Coordinates here are normalized IMAGE coordinates, never pitch metres or an
attacking direction. No possession, goal proximity or physical speed is claimed.
Only direct observations enter geometry. Missing observations are masked rather
than mistaken for players/balls at (0, 0). TeamClassifier's actual convention is
anonymous teams -1/+1, UNKNOWN 0; all team features ignore the sign convention.

The schema's player/ball velocities are already affine-camera-compensated by
features.interpolation.velocities. We never subtract camera translation twice.
The schema lacks a camera-reliability bit and track IDs, so motion reliability
uses consecutive direct visibility and absence of a camera cut, conservatively.
"""

from dataclasses import dataclass

import numpy as np

from matchpulse.features.schema import SCHEMA_VERSION

VERSION = "observed-relative-image-v1"
SUMMARIES = ("mean", "std", "recent_mean", "recent_minus_early", "available_fraction")

# A small broadcast/audio context control. No raw player slot or team identity.
COMPACT_NAMES = (
    "player_visible_fraction",
    "player_known_team_fraction",
    "player_mean_box_height",
    "ball_visible",
    "camera_pitch_coverage",
    "camera_cut",
    "camera_wide_view",
    "camera_log_speed",
    "audio_available",
    "audio_log_rms",
    "audio_flux",
    "audio_centroid",
)

# More football-relative information, with no absolute ball/player position.
RELATIVE_NAMES = COMPACT_NAMES + (
    "player_mean_confidence",
    "player_spread_x",
    "player_spread_y",
    "player_known_team_balance",
    "player_motion_fraction",
    "player_mean_log_speed",
    "player_flow_coherence",
    "player_motion_dispersion",
    "ball_log_speed",
    "ball_nearest_player_diagonal_distance",
    "ball_player_unit_image_distance_mean",
    "ball_near_player_fraction_r010",
    "ball_near_player_fraction_r020",
    "ball_abs_x_offset_player_std",
    "ball_abs_y_offset_player_std",
    "ball_nearest_team_unit_image_distance_min",
    "ball_nearest_team_unit_image_distance_max",
    "ball_near_known_team_density_imbalance_r020",
    "team_center_unit_image_separation",
    "ball_relative_player_flow_log_speed",
    "ball_player_flow_alignment",
    "audio_rms_delta",
)


def feature_names(variant="relative"):
    """Stable summary-major column order, also embedded in model provenance."""
    names = _base_names(variant)
    return tuple(f"{summary}.{name}" for summary in SUMMARIES for name in names)


def _base_names(variant):
    if variant == "compact":
        return COMPACT_NAMES
    if variant == "relative":
        return RELATIVE_NAMES
    raise ValueError("Representation variant must be compact or relative")


def _mean(values, mask, axis=-1):
    count = mask.sum(axis=axis)
    return np.sum(np.where(mask, values, 0), axis=axis) / np.maximum(count, 1)


def frame_representation(raw, variant="relative"):
    """Return values and validity, each [batch,time,frame_features].

    ``raw`` contains only the completed observation, through the prediction
    endpoint. This function has no access to metadata, match identity or labels.
    Motion at the first frame is unavailable, including when callers slice a
    longer observation. All reductions are across players in the same frame.
    """
    names = _base_names(variant)
    x = np.asarray(raw)
    if x.ndim != 3 or x.shape[1] < 1 or x.shape[2] != 215 or x.dtype != np.float32:
        raise ValueError("Expected raw float32 [batch,time,215] with nonempty time")
    if not np.isfinite(x).all():
        raise ValueError("Raw observation features must be finite")
    p = x[..., :198].reshape(*x.shape[:2], 22, 9)
    # Cheap raw-schema guard catches accidental already-normalized input.
    if np.any((p[..., [0, 1, 4, 5, 6]] < 0) | (p[..., [0, 1, 4, 5, 6]] > 1)):
        raise ValueError("Expected raw, unnormalized player position/size/confidence")
    if not np.isin(p[..., 8], [-1, 0, 1]).all():
        raise ValueError("Team codes must be anonymous -1/+1 or unknown 0")
    for a in (p[..., 7], x[..., 203], x[..., 208:210], x[..., 214]):
        if not np.isin(a, [0, 1]).all():
            raise ValueError("Raw visibility/availability indicators must be binary")
    seen = p[..., 7] == 1
    n = seen.sum(-1)
    players = n > 0
    team_minus = seen & (p[..., 8] == -1)
    team_plus = seen & (p[..., 8] == 1)
    nm, np_ = team_minus.sum(-1), team_plus.sum(-1)
    known = nm + np_
    ball = x[..., 203] == 1
    audio = x[..., 214] == 1
    cut = x[..., 208] == 1
    wide = x[..., 209] == 1
    always = np.ones(x.shape[:2], bool)
    cam_motion = wide & ~cut
    cam_motion[:, 0] = False
    v, masks = {}, {}

    def add(name, value, valid=always):
        v[name] = value
        masks[name] = valid

    add("player_visible_fraction", n / 22)
    add("player_known_team_fraction", known / np.maximum(n, 1), players)
    add("player_mean_box_height", _mean(p[..., 5], seen), players)
    add("ball_visible", ball.astype(np.float32))
    add("camera_pitch_coverage", x[..., 205])
    add("camera_cut", cut.astype(np.float32))
    add("camera_wide_view", wide.astype(np.float32))
    add("camera_log_speed", np.log1p(np.linalg.norm(x[..., 206:208], axis=-1)), cam_motion)
    add("audio_available", audio.astype(np.float32))
    add("audio_log_rms", x[..., 210], audio)
    add("audio_flux", x[..., 212], audio)
    add("audio_centroid", x[..., 213], audio)

    if variant == "relative":
        mean_x = _mean(p[..., 0], seen)
        mean_y = _mean(p[..., 1], seen)
        std_x = np.sqrt(_mean((p[..., 0] - mean_x[..., None]) ** 2, seen))
        std_y = np.sqrt(_mean((p[..., 1] - mean_y[..., None]) ** 2, seen))
        add("player_mean_confidence", _mean(p[..., 6], seen), players)
        add("player_spread_x", std_x, n >= 2)
        add("player_spread_y", std_y, n >= 2)
        add("player_known_team_balance", np.minimum(nm, np_) / np.maximum(known, 1), known > 0)
        motion = seen.copy()
        motion[:, 0] = False
        motion[:, 1:] &= seen[:, :-1]
        motion &= ~cut[..., None]
        motions = motion.sum(-1)
        speed = np.linalg.norm(p[..., 2:4], axis=-1)
        flow_x = _mean(p[..., 2], motion)
        flow_y = _mean(p[..., 3], motion)
        flow = np.stack([flow_x, flow_y], axis=-1)
        flow_speed = np.linalg.norm(flow, axis=-1)
        mean_speed = _mean(speed, motion)
        add("player_motion_fraction", motions / 22)
        add("player_mean_log_speed", _mean(np.log1p(speed), motion), motions > 0)
        add("player_flow_coherence", flow_speed / np.maximum(mean_speed, 1e-6), motions >= 2)
        deviation = np.linalg.norm(p[..., 2:4] - flow[..., None, :], axis=-1)
        add("player_motion_dispersion", _mean(np.log1p(deviation), motion), motions >= 2)
        bmotion = ball.copy()
        bmotion[:, 0] = False
        bmotion[:, 1:] &= ball[:, :-1]
        bmotion &= ~cut
        bv = x[..., 200:202]
        bspeed = np.linalg.norm(bv, axis=-1)
        add("ball_log_speed", np.log1p(bspeed), bmotion)
        relative = p[..., :2] - x[..., None, 198:200]
        # Unit-image distances, not the schema's diagonal-scaled pixel distance.
        distance = np.linalg.norm(relative, axis=-1)
        geometry = ball & players
        add("ball_nearest_player_diagonal_distance", x[..., 204], geometry)
        add("ball_player_unit_image_distance_mean", _mean(distance, seen), geometry)
        add("ball_near_player_fraction_r010", _mean((distance < .10).astype(float), seen), geometry)
        add("ball_near_player_fraction_r020", _mean((distance < .20).astype(float), seen), geometry)
        # A floor/cap prevents sparse/near-collinear detections making giant values.
        # These describe framing-relative location and do not infer pitch positions.
        add("ball_abs_x_offset_player_std", np.minimum(np.abs(x[..., 198] - mean_x) / np.maximum(std_x, .02), 10), ball & (n >= 2))
        add("ball_abs_y_offset_player_std", np.minimum(np.abs(x[..., 199] - mean_y) / np.maximum(std_y, .02), 10), ball & (n >= 2))
        both = (nm > 0) & (np_ > 0)
        nearest_m = np.min(np.where(team_minus, distance, np.inf), axis=-1)
        nearest_p = np.min(np.where(team_plus, distance, np.inf), axis=-1)
        add("ball_nearest_team_unit_image_distance_min", np.minimum(nearest_m, nearest_p), ball & both)
        add("ball_nearest_team_unit_image_distance_max", np.maximum(nearest_m, nearest_p), ball & both)
        near_m = _mean((distance < .20).astype(float), team_minus)
        near_p = _mean((distance < .20).astype(float), team_plus)
        add("ball_near_known_team_density_imbalance_r020", np.abs(near_m - near_p), ball & both)
        mx, my = _mean(p[..., 0], team_minus), _mean(p[..., 1], team_minus)
        px, py = _mean(p[..., 0], team_plus), _mean(p[..., 1], team_plus)
        add("team_center_unit_image_separation", np.hypot(mx - px, my - py), (nm >= 2) & (np_ >= 2))
        add("ball_relative_player_flow_log_speed", np.log1p(np.linalg.norm(bv - flow, axis=-1)), bmotion & (motions >= 2))
        dot = np.sum(bv * flow, axis=-1)
        alignment = np.clip(dot / np.maximum(bspeed * flow_speed, 1e-6), -1, 1)
        add("ball_player_flow_alignment", alignment, bmotion & (motions >= 2) & (bspeed > 1e-6) & (flow_speed > 1e-6))
        add("audio_rms_delta", x[..., 211], audio)

    values = np.stack([v[name] for name in names], axis=-1)
    valid = np.stack([masks[name] for name in names], axis=-1)
    values = np.where(valid, values, 0).astype(np.float32)
    if not np.isfinite(values).all():
        raise ValueError("Nonfinite observed geometry")
    return values, valid


def _summarize(values, valid, frames_per_second=15):
    length = min(values.shape[1], frames_per_second)

    def mean(a, m):
        return np.where(m, a, 0).sum(1) / np.maximum(m.sum(1), 1)

    full = mean(values, valid)
    std = np.sqrt(mean((values - full[:, None, :]) ** 2, valid))
    recent = mean(values[:, -length:], valid[:, -length:])
    early = mean(values[:, :length], valid[:, :length])
    # A trend requires valid evidence in BOTH temporal regions. Otherwise emit 0
    # and retain availability. Missing early audio is not an excitement increase.
    trend_ok = valid[:, -length:].any(1) & valid[:, :length].any(1)
    trend = np.where(trend_ok, recent - early, 0)
    return np.concatenate([full, std, recent, trend, valid.mean(1)], axis=-1).astype(np.float32)


@dataclass(frozen=True)
class InvariantRepresentation:
    """Portable, deterministic raw-window transformer with no fitted statistics.

    Compact: 60 variables. Relative: 170 variables. Train-only estimator-level
    scaling is intentionally separate, to be saved with the trained classifier.
    A batch is processed independently, so memory scales with ``batch_size``.
    """

    variant: str = "relative"

    @property
    def names(self):
        return feature_names(self.variant)

    def transform(self, features, *, batch_size=128):
        x = np.asarray(features)
        single = x.ndim == 2
        if single:
            x = x[None]
        if x.ndim != 3 or x.shape[-1] != 215 or x.shape[1] < 1 or x.dtype != np.float32:
            raise ValueError("Expected raw float32 [batch,time,215] or [time,215]")
        if not isinstance(batch_size, int) or batch_size < 1:
            raise ValueError("batch_size must be a positive integer")
        output = np.empty((len(x), len(self.names)), np.float32)
        for start in range(0, len(x), batch_size):
            values, valid = frame_representation(x[start:start + batch_size], self.variant)
            output[start:start + batch_size] = _summarize(values, valid)
        return output[0] if single else output

    def to_dict(self):
        return {
            "version": VERSION,
            "variant": self.variant,
            "source_schema": SCHEMA_VERSION,
            "input": "raw float32 [batch,time,215], completed observation only",
            "sampling_fps": 15,
            "geometry": "normalized image coordinates; no pitch calibration/attack direction/possession",
            "team_encoding": "anonymous -1/+1; unknown 0; invariant to sign flip",
            "motion": "existing affine-compensated velocities; direct visibility at both adjacent frames; no cut; first frame unavailable",
            "camera_motion_validity": "wide/non-cut after first frame is an approximation; source schema lacks reliability bit",
            "summary_region": "early/recent use first/last 15 frames (one second), or all frames if shorter",
            "missing": "conditioned temporal summaries; zero when no observed values; separate per-variable availability fraction",
            "coordinate_scale_floor": .02,
            "normalized_offset_cap": 10,
            "feature_names": list(self.names),
        }

    @classmethod
    def from_dict(cls, metadata):
        representation = cls(metadata["variant"])
        if metadata != representation.to_dict():
            raise ValueError("Representation schema/provenance mismatch")
        return representation
