"""Supplemental full-source replay with changing stream availability.

The frozen common-period evaluator is imported read-only and remains unchanged.
This mode is post-selection sensitivity ONLY: it never ranks/promotes models.
Ended streams cannot be selected or scored; mid-tick endings leave blank display
until the next scheduled action, never a fabricated/interpolated prediction.
"""

from collections import defaultdict
from dataclasses import asdict, dataclass, fields

import numpy as np

from . import replay as common

VERSION = "matchpulse-full-source-replay-v1"


@dataclass(frozen=True)
class FullReplayConfig(common.ReplayConfig):
    session_end_rule: str = "full_available"

    def __post_init__(self):
        super().__post_init__()
        if self.session_end_rule not in ("common", "full_available"):
            raise ValueError("Source-end rule must be common or full_available")


@dataclass
class _Session:
    half: int
    end: float
    source_ends: np.ndarray
    prediction_times: np.ndarray
    times: np.ndarray
    lengths: np.ndarray
    scores: dict
    active: np.ndarray
    supported: np.ndarray


@dataclass
class _Grid:
    matches: list
    sessions: list
    support: dict
    config: FullReplayConfig


def _common_config(config):
    return common.ReplayConfig(**{field.name: getattr(config, field.name) for field in fields(common.ReplayConfig)})


def _prepare(rows, scores_by_model, half_durations, config):
    if not rows or not scores_by_model or not half_durations:
        raise ValueError("Full-source replay requires validation rows, scores and explicit source durations")
    if any(row.get("split") != "valid" for row in rows):
        raise ValueError("Full-source replay is official-validation-only")
    matches = sorted({row["match_id"] for row in rows})
    if len(matches) < 2:
        raise ValueError("At least two original independent match IDs are required")
    models = {}
    for name, values in scores_by_model.items():
        scores = np.asarray(values, np.float64)
        if scores.shape != (len(rows),) or np.isinf(scores).any():
            raise ValueError("One bounded or explicitly unavailable score per original row is required")
        finite = np.isfinite(scores)
        if np.any((scores[finite] < 0) | (scores[finite] > 1)) or str(name) in models:
            raise ValueError("Unique model names and sigmoid scores in[0,1] required")
        models[str(name)] = scores
    durations = {}
    for (match, half), duration in half_durations.items():
        if match not in matches:
            continue
        duration = float(duration)
        if int(half) not in (1, 2) or not np.isfinite(duration) or duration <= 0:
            raise ValueError("Finite positive original half1/2 source durations required")
        durations[(match, int(half))] = duration
    by_key = {}
    for i, row in enumerate(rows):
        match, half = row["match_id"], int(row["half"])
        start, end = float(row["observation_start_seconds"]), float(row["observation_end_seconds"])
        source_end = durations.get((match, half))
        if (source_end is None or not np.isfinite([start, end]).all() or start < -1e-6
                or abs(end-start-5) > 1e-6 or end > source_end + 1e-7):
            raise ValueError("Observation reaches beyond its own recorded source or violates the completed5s contract")
        key = (match, half, common._time_key(end))
        if key in by_key:
            raise ValueError("Duplicate match/half/endpoint prediction")
        by_key[key] = i
    halves = sorted({half for _, half in durations})
    sessions, missing, skipped = [], [], []
    active_seconds, active_decisions, available_seconds = defaultdict(float), defaultdict(int), defaultdict(float)
    for half in halves:
        source_ends = np.asarray([durations.get((match, half), 0.) for match in matches])
        end = float(source_ends.max())
        first_action = config.observation_seconds + config.prediction_latency_seconds
        if end <= first_action:
            skipped.append(half)
            continue
        prediction_times = np.arange(config.observation_seconds, end-config.prediction_latency_seconds-1e-7,
                                     config.decision_stride_seconds)
        times = prediction_times + config.prediction_latency_seconds
        lengths = np.minimum(config.decision_stride_seconds, end-times)
        active = source_ends[None, :] > times[:, None]
        if not active.any(axis=1).all():
            raise ValueError("Replay generated an action without an available recorded source")
        scores = {name: np.full(active.shape, np.nan) for name in models}
        for t, endpoint in enumerate(prediction_times):
            for m in np.flatnonzero(active[t]):
                match = matches[m]
                i = by_key.get((match, half, common._time_key(endpoint)))
                absent = []
                for name, values in models.items():
                    if i is not None and np.isfinite(values[i]):
                        scores[name][t, m] = values[i]
                    else:
                        absent.append(name)
                if absent and len(missing) < 16:
                    missing.append({"match_id": match, "half": half, "prediction_endpoint": float(endpoint),
                        "action_time": float(times[t]), "missing_active_models": absent})
        supported = np.ones(len(times), bool)
        for matrix in scores.values():
            supported &= (np.isfinite(matrix) | ~active).all(axis=1)
        sessions.append(_Session(half, end, source_ends, prediction_times, times, lengths, scores, active, supported))
        for count in active.sum(axis=1):
            active_decisions[int(count)] += 1
        boundaries = np.unique(np.concatenate(([first_action, end], source_ends[(source_ends > first_action) & (source_ends < end)])))
        for lo, hi in zip(boundaries[:-1], boundaries[1:], strict=True):
            active_seconds[int((source_ends > lo).sum())] += float(hi-lo)
        for m, match in enumerate(matches):
            available_seconds[match] += max(0., float(source_ends[m])-first_action)
    if not sessions:
        raise ValueError("No source remains available after observation/latency warmup")
    total = sum(len(session.times) for session in sessions)
    supported = sum(int(session.supported.sum()) for session in sessions)
    timeline = sum(float(session.lengths.sum()) for session in sessions)
    supported_timeline = sum(float(session.lengths[session.supported].sum()) for session in sessions)
    support = {"independent_match_count": len(matches), "independent_match_ids": matches,
        "seven_independent_matches_available": len(matches) >= 7, "halves_are_not_independent_matches": True,
        "limitation": f"{len(matches)} independent validation matches, with changing availability; one-active tails are not competitive selection evidence",
        "half_sessions": [session.half for session in sessions], "unreplayable_short_half_sessions": skipped,
        "session_end_rule": "full_available", "half_ends": {str(s.half): s.end for s in sessions},
        "source_half_ends": [{"match_id": match, "half": half, "source_end_seconds": duration}
            for (match, half), duration in sorted(durations.items())],
        "session_duration_rule": "Stop at the longest recorded source; only streams still recorded at action time are eligible",
        "first_prediction_endpoint_seconds": config.observation_seconds,
        "first_decision_seconds": config.observation_seconds+config.prediction_latency_seconds,
        "warmup_seconds_excluded_per_half": config.observation_seconds+config.prediction_latency_seconds,
        "decision_count": total, "complete_score_decisions": supported,
        "complete_score_decision_fraction": supported/total, "all_score_grid_complete": supported == total,
        "output_timeline_seconds": timeline, "complete_score_timeline_seconds": supported_timeline,
        "active_match_seconds_after_warmup": dict(available_seconds),
        "timeline_seconds_by_active_match_count": {str(n): t for n, t in sorted(active_seconds.items())},
        "decisions_by_active_match_count": {str(n): count for n, count in sorted(active_decisions.items())},
        "first_missing_active_endpoints": missing,
        "availability_rule": "Source_end > actual delayed action/event time, strictly; no ended/inactive observation is used or treated as a score gap",
        "blank_rule": "Clip chosen display at its own source end; remain blank until next scheduled action, never invent/interpolate an intervening prediction",
        "timeline_alignment": "Simulated synchronized half-local clocks; halftime resets state; actual fixture dates differ",
        "primary_evaluation_unchanged": "Matched common-period evaluation remains the frozen promotion criterion; this mode is supplemental post-selection sensitivity only"}
    if config.require_full_grid and supported != total:
        raise ValueError(f"Full-source active grid incomplete ({supported}/{total} actions); inactive missing predictions are exempt, active missing predictions are not")
    return _Grid(matches, sessions, support, config)


def _schedule(grid, policy, model_name=None, *, initial_match=None, seed=None):
    if policy not in ("score", "score_centered", "stay", "random", "round_robin"):
        raise ValueError("Unknown frozen replay policy")
    config = grid.config
    rng = np.random.default_rng(config.seed if seed is None else seed)
    if initial_match is not None and initial_match not in grid.matches:
        raise ValueError("Preferred fixed-stay source is outside the validation pool")
    initial = grid.matches.index(initial_match) if initial_match is not None else 0
    schedules = []
    for session in grid.sessions:
        current, segment_start = initial, 0
        selected = np.empty(len(session.times), np.int64)
        run_start = selected.copy()
        switched = np.zeros(len(session.times), bool)
        forced = switched.copy()
        display_end = np.empty(len(session.times), np.float64)
        for i, time in enumerate(session.times):
            active = session.active[i]
            choices = np.flatnonzero(active)
            previous = current
            previous_active = bool(active[current])
            chosen = current if previous_active else int(choices[0])
            if session.supported[i]:
                if policy in ("score", "score_centered"):
                    utility = np.full(len(grid.matches), -np.inf)
                    q = np.clip(session.scores[model_name][i, choices], 1e-7, 1-1e-7)
                    utility[choices] = np.log(q)-np.log1p(-q)
                    if policy == "score_centered":
                        lo = int(np.searchsorted(session.prediction_times,
                            session.prediction_times[i]-config.adaptive_history_seconds, side="left"))
                        for m in choices:
                            history = session.scores[model_name][lo:i, m]
                            history = history[np.isfinite(history)]
                            if len(history) and len(history)*config.decision_stride_seconds >= config.adaptive_warmup_seconds:
                                p = np.clip(history, 1e-7, 1-1e-7)
                                utility[m] -= float(np.median(np.log(p)-np.log1p(-p)))
                    if previous_active:
                        utility[previous] += config.staying_bonus_logit
                    chosen = int(np.argmax(utility))
                elif policy == "random":
                    chosen = int(choices[int(rng.integers(len(choices)))])
                elif policy == "round_robin":
                    phase = int((time-session.times[0])//config.round_robin_dwell_seconds) % len(grid.matches)
                    chosen = next((phase+offset) % len(grid.matches) for offset in range(len(grid.matches))
                                  if active[(phase+offset) % len(grid.matches)])
            if chosen != previous:
                switched[i] = True
                forced[i] = not previous_active
                segment_start = i
            current = chosen
            selected[i], run_start[i] = chosen, segment_start
            display_end[i] = min(float(time+session.lengths[i]), float(session.source_ends[chosen]))
        schedules.append({"half": session.half, "selected": selected, "run_start": run_start,
            "switched": switched, "forced_end_switch": forced, "display_end": display_end})
    return schedules


def _event_stratum(cases):
    available = [case for case in cases if case["inside_own_source"]]
    included = [case for case in available if case["in_replay"]]
    supported = [case for case in included if case["complete_score_support"]]
    shown = [case for case in supported if case["shown_verified"]]
    return {"available_source_incident_groups": len(available), "incident_groups_in_replay": len(included),
        "complete_support_incident_groups": len(supported), "verified_shown_incident_groups": len(shown),
        "initial_warmup_incident_groups": sum(case["exclusion_reason"] == "initial_warmup" for case in available),
        "shown_fraction_all_available_lower_bound": len(shown)/len(available) if available else None,
        "shown_fraction_on_complete_support": len(shown)/len(supported) if supported else None,
        "blank_at_event_incident_groups": sum(case.get("display_blank_at_event", False) for case in included)}


def _scope_metrics(grid, schedules, incidents):
    config = grid.config
    by_half = {s.half: (s, schedule) for s, schedule in zip(grid.sessions, schedules, strict=True)}
    events_by_source = defaultdict(list)
    cases = []
    per_match = {match: {"available_incidents": 0, "incidents_in_replay": 0, "complete_support_incidents": 0,
        "verified_shown": 0, "exploratory_shown": 0} for match in grid.matches}
    for incident in incidents:
        session, schedule = by_half[incident["half"]]
        time = incident["timestamp"]
        m = grid.matches.index(incident["match_id"])
        inside = bool(0 <= time < session.source_ends[m])
        actual_active = [grid.matches[i] for i in np.flatnonzero(session.source_ends > time)]
        case = {"id": incident["id"], "match_id": incident["match_id"], "half": incident["half"],
            "timestamp": time, "types": sorted(incident["types"]), "event_ids": incident["event_ids"],
            "inside_own_source": inside, "active_match_count_at_event": len(actual_active),
            "active_match_ids_at_event": actual_active, "in_replay": False, "shown_verified": False,
            "exclusion_reason": "outside_own_source" if not inside else None}
        stats = per_match[incident["match_id"]]
        if not inside:
            cases.append(case)
            continue
        stats["available_incidents"] += 1
        events_by_source[(incident["half"], incident["match_id"])].append(time)
        if time < session.times[0]:
            case["exclusion_reason"] = "initial_warmup"
            cases.append(case)
            continue
        if time >= session.end:
            case["exclusion_reason"] = "outside_output_timeline"
            cases.append(case)
            continue
        i = int(np.searchsorted(session.times, time, side="right")-1)
        lo = max(0, int(np.searchsorted(session.times, time-config.maximum_anticipation_seconds, side="right")-1))
        complete = bool(session.supported[lo:i+1].all())
        displayed = bool(time < schedule["display_end"][i])
        chosen = grid.matches[int(schedule["selected"][i])] if displayed else None
        shown = chosen == incident["match_id"]
        run = int(schedule["run_start"][i])
        segment_start = float(session.times[run])
        lead = time-segment_start if shown else None
        anticipated = bool(shown and schedule["switched"][run] and config.minimum_anticipation_seconds <= lead <= config.maximum_anticipation_seconds)
        forced_anticipation = bool(anticipated and schedule["forced_end_switch"][run])
        stats["incidents_in_replay"] += 1
        stats["complete_support_incidents"] += int(complete)
        stats["verified_shown"] += int(shown and complete)
        stats["exploratory_shown"] += int(shown)
        case.update(in_replay=True, complete_score_support=complete, selected_match_at_event=chosen,
            display_blank_at_event=not displayed, shown_exploratory=shown, shown_verified=shown and complete,
            viewing_segment_start=segment_start if shown else None, preselection_lead_seconds=lead,
            preselection_lead_capped10_seconds=min(lead, config.maximum_anticipation_seconds) if shown else None,
            newly_anticipated_via_switch=anticipated and complete,
            newly_anticipated_via_nonforced_switch=anticipated and complete and not forced_anticipation,
            anticipatory_switch_forced_by_source_end=forced_anticipation)
        cases.append(case)
    for values in per_match.values():
        values["shown_fraction_all_available_lower_bound"] = values["verified_shown"]/values["available_incidents"] if values["available_incidents"] else None
        values["shown_fraction_on_complete_support"] = values["verified_shown"]/values["complete_support_incidents"] if values["complete_support_incidents"] else None
    available = [case for case in cases if case["inside_own_source"]]
    included = [case for case in available if case["in_replay"]]
    supported = [case for case in included if case["complete_score_support"]]
    shown = [case for case in supported if case["shown_verified"]]
    leads = [case["preselection_lead_capped10_seconds"] for case in shown]
    macros = [value["shown_fraction_on_complete_support"] for value in per_match.values() if value["shown_fraction_on_complete_support"] is not None]
    macro_available = [value["shown_fraction_all_available_lower_bound"] for value in per_match.values() if value["shown_fraction_all_available_lower_bound"] is not None]
    switches = forced = initial = unnecessary = regret = 0
    choices = useful = competing = earliest_selected = any_competing = 0
    timeline = displayed_seconds = blank_seconds = context_seconds = informative = 0.
    for session, schedule in zip(grid.sessions, schedules, strict=True):
        source_times = {match: np.asarray(sorted(events_by_source[(session.half, match)])) for match in grid.matches}
        contexts = {match: [(t-config.event_context_before_seconds, t+config.event_context_after_seconds) for t in times]
                    for match, times in source_times.items()}
        for i, time in enumerate(session.times):
            duration = float(session.lengths[i])
            viewing = float(schedule["display_end"][i]-time)
            selected = grid.matches[int(schedule["selected"][i])]
            timeline += duration
            displayed_seconds += viewing
            blank_seconds += duration-viewing
            if not session.supported[i]:
                continue
            context_seconds += viewing
            informative += common._union_overlap(float(time), float(schedule["display_end"][i]), contexts[selected])
            upcoming = {}
            for m in np.flatnonzero(session.active[i]):
                match = grid.matches[m]
                lead_values = source_times[match]-time
                relevant = lead_values[(lead_values >= config.minimum_anticipation_seconds) & (lead_values <= config.maximum_anticipation_seconds)]
                if len(relevant):
                    upcoming[match] = float(relevant.min())
            if upcoming:
                choices += 1
                useful += int(selected in upcoming)
            if len(upcoming) >= 2:
                competing += 1
                any_competing += int(selected in upcoming)
                earliest_selected += int(selected in upcoming and upcoming[selected] <= min(upcoming.values())+1e-6)
            if schedule["switched"][i]:
                switches += 1
                forced += int(schedule["forced_end_switch"][i])
                initial += int(i == 0 and not schedule["forced_end_switch"][i])
                ahead = source_times[selected]-time
                good = bool(np.any((ahead >= 0) & (ahead <= config.unnecessary_switch_horizon_seconds)))
                unnecessary += int(not good)
                previous = grid.matches[int(schedule["selected"][i-1])] if i else grid.matches[0]
                old_ahead = source_times[previous]-time
                regret += int(not good and np.any((old_ahead >= 0) & (old_ahead <= config.unnecessary_switch_horizon_seconds)))
    stratified = {str(n): _event_stratum([case for case in cases if case["active_match_count_at_event"] == n])
                  for n in range(1, len(grid.matches)+1)}
    proxy_switches = switches
    # Availability-driven switches still happen during an incomplete-score
    # diagnostic. Behavioral counts cover every tick, independently of labels.
    switches = sum(int(schedule["switched"].sum()) for schedule in schedules)
    forced = sum(int(schedule["forced_end_switch"].sum()) for schedule in schedules)
    initial = sum(int(schedule["switched"][0] and not schedule["forced_end_switch"][0]) for schedule in schedules)
    return {"available_incident_groups": len(available), "input_annotation_groups": len(cases),
        "annotation_groups_outside_own_source": len(cases)-len(available),
        "incident_groups_in_replay": len(included), "initial_warmup_incident_groups": sum(case["exclusion_reason"] == "initial_warmup" for case in available),
        "incident_groups_outside_output_timeline": len(available)-len(included),
        "complete_support_incident_groups": len(supported), "verified_shown_incident_groups": len(shown),
        "missed_incident_groups_on_complete_support": len(supported)-len(shown),
        "shown_fraction_on_complete_support": len(shown)/len(supported) if supported else None,
        "shown_fraction_all_available_lower_bound": len(shown)/len(available) if available else None,
        "macro_match_shown_fraction_on_complete_support": float(np.mean(macros)) if macros else None,
        "macro_match_shown_fraction_all_available_lower_bound": float(np.mean(macro_available)) if macro_available else None,
        "macro_match_count_with_complete_support_incidents": len(macros), "macro_match_count_with_available_incidents": len(macro_available),
        "shown_with_at_least_3s_preselection": sum(case["preselection_lead_seconds"] >= config.minimum_anticipation_seconds for case in shown),
        "newly_anticipated_via_switch": sum(case["newly_anticipated_via_switch"] for case in shown),
        "newly_anticipated_via_nonforced_switch": sum(case["newly_anticipated_via_nonforced_switch"] for case in shown),
        "mean_preselection_lead_capped10_seconds_for_shown": float(np.mean(leads)) if leads else None,
        "preselection_lead_capped10_quantiles": np.quantile(leads, [0, .25, .5, .75, 1]).tolist() if leads else None,
        "switches": switches, "switches_per_output_minute": switches/(timeline/60) if timeline else None,
        "forced_source_end_switches": forced, "initial_nonforced_selection_changes": initial,
        "voluntary_switches_excluding_initial": switches-forced-initial,
        "unnecessary_switches_proxy": unnecessary, "unnecessary_switch_fraction_proxy": unnecessary/proxy_switches if proxy_switches else None,
        "event_proxy_switch_count_on_complete_scores": proxy_switches,
        "event_proxy_note": "Switch/fallback totals cover every tick; event-proximity switch proxies use only actions with complete active-score support",
        "switch_regret_proxy": regret, "output_timeline_seconds": timeline, "displayed_seconds": displayed_seconds,
        "blank_seconds": blank_seconds, "blank_fraction_of_output_timeline": blank_seconds/timeline if timeline else None,
        "uneventful_footage_seconds_proxy_on_complete_scores": max(0., context_seconds-informative),
        "uneventful_footage_fraction_proxy_on_complete_scores": 1-informative/context_seconds if context_seconds else None,
        "upcoming_event_decisions": choices, "selected_upcoming_event_match_decisions": useful,
        "upcoming_event_selection_accuracy": useful/choices if choices else None,
        "competing_upcoming_event_decisions": competing, "earliest_event_match_selected_in_competition": earliest_selected,
        "earliest_event_selection_accuracy_in_competition": earliest_selected/competing if competing else None,
        "any_event_match_selection_accuracy_in_competition": any_competing/competing if competing else None,
        "capture_by_actual_active_match_count": stratified,
        "one_active_trivial_tail": _event_stratum([case for case in cases if case["active_match_count_at_event"] == 1]),
        "at_least_two_active_competition": _event_stratum([case for case in cases if case["active_match_count_at_event"] >= 2]),
        "per_match": per_match, "cases": cases}


def _evaluate(grid, schedules, events, include_trace):
    scopes = {name: _scope_metrics(grid, schedules,
        common._incidents(events, grid.matches, set(grid.support["half_sessions"]), types))
        for name, types in common.SCOPES.items()}
    viewing, supported_viewing = {match: 0. for match in grid.matches}, {match: 0. for match in grid.matches}
    timeline = blank = 0.
    trace = []
    for session, schedule in zip(grid.sessions, schedules, strict=True):
        for i, time in enumerate(session.times):
            selected = int(schedule["selected"][i])
            match = grid.matches[selected]
            duration = float(schedule["display_end"][i]-time)
            gap = float(session.lengths[i]-duration)
            viewing[match] += duration
            timeline += float(session.lengths[i])
            blank += gap
            if session.supported[i]:
                supported_viewing[match] += duration
            if include_trace:
                trace.append({"half": session.half, "prediction_endpoint_seconds": float(session.prediction_times[i]),
                    "prediction_available_seconds": float(time), "display_start_seconds": float(time),
                    "display_end_seconds": float(schedule["display_end"][i]),
                    "next_action_or_session_end_seconds": float(time+session.lengths[i]), "blank_seconds": gap,
                    "selected_match": match, "selected_source_end_seconds": float(session.source_ends[selected]),
                    "active_match_ids_at_action": [grid.matches[m] for m in np.flatnonzero(session.active[i])],
                    "active_match_count_at_action": int(session.active[i].sum()),
                    "complete_score_support": bool(session.supported[i]), "switched": bool(schedule["switched"][i]),
                    "forced_source_end_switch": bool(schedule["forced_end_switch"][i])})
    displayed, supported_seconds = sum(viewing.values()), sum(supported_viewing.values())
    result = {"scopes": scopes, "output_timeline_seconds": timeline, "displayed_seconds": displayed,
        "blank_seconds": blank, "blank_fraction_of_output_timeline": blank/timeline if timeline else None,
        "viewing_seconds_by_match": viewing,
        "viewing_fraction_by_match_among_displayed_seconds": {m: t/displayed if displayed else None for m, t in viewing.items()},
        "viewing_fraction_by_match_of_output_timeline": {m: t/timeline if timeline else None for m, t in viewing.items()},
        "complete_support_viewing_seconds_by_match": supported_viewing,
        "complete_support_viewing_fraction_by_match": {m: t/supported_seconds if supported_seconds else None for m, t in supported_viewing.items()}}
    if include_trace:
        result["trace"] = trace
    return result


def _random_summary(results):
    summary = common._random_summary(results)

    def summarize(records):
        output = {}
        for key in records[0]:
            values = [record[key] for record in records]
            available = [value for value in values if value is not None]
            if available and not all(isinstance(value, (int, float)) for value in available):
                continue
            output[key] = {"mean": float(np.mean(available)) if available else None,
                "quantiles_2p5_50_97p5": np.quantile(available, [.025, .5, .975]).tolist() if available else None,
                "non_null_trials": len(available)}
        return output

    for scope in common.SCOPES:
        for block in ("one_active_trivial_tail", "at_least_two_active_competition"):
            summary["scopes"][scope][block] = summarize([result["scopes"][scope][block] for result in results])
        counts = results[0]["scopes"][scope]["capture_by_actual_active_match_count"]
        summary["scopes"][scope]["capture_by_actual_active_match_count"] = {count: summarize([
            result["scopes"][scope]["capture_by_actual_active_match_count"][count] for result in results]) for count in counts}
    return summary


def compare_full_source_policies(rows, scores_by_model, events, *, half_durations,
                                 config=None, random_repeats=32, include_trace=True, score_policy_keys=None):
    """Descriptive full-source sensitivity. Never use this result for promotion.

    Source durations are mandatory. `session_end_rule='common'` delegates to the
    frozen common evaluator exactly, for compatibility/regression checks only.
    """
    config = config or FullReplayConfig()
    if not isinstance(config, FullReplayConfig) or random_repeats < 1:
        raise ValueError("FullReplayConfig and at least one random replicate required")
    if config.session_end_rule == "common":
        if score_policy_keys is not None:
            raise ValueError("Filtered frozen policies are a full-source sensitivity option, not a primary common-mode modification")
        return common.compare_policies(rows, scores_by_model, events, half_durations=half_durations,
            config=_common_config(config), random_repeats=random_repeats, include_trace=include_trace)
    grid = _prepare(rows, scores_by_model, half_durations, config)
    requested = set(score_policy_keys) if score_policy_keys is not None else None
    allowed = {"score::"+str(name) for name in scores_by_model}
    if config.include_centered_policies:
        allowed |= {"score_centered::"+str(name) for name in scores_by_model}
    if requested is not None and not requested <= allowed:
        raise ValueError("A requested frozen score policy is absent from source/model configuration")
    policies = {}
    for match in grid.matches:
        policies["stay::"+match] = _evaluate(grid, _schedule(grid, "stay", initial_match=match), events, include_trace)
    policies["round_robin"] = _evaluate(grid, _schedule(grid, "round_robin"), events, include_trace)
    for name in scores_by_model:
        if requested is None or "score::"+str(name) in requested:
            policies["score::"+str(name)] = _evaluate(grid, _schedule(grid, "score", str(name)), events, include_trace)
        if config.include_centered_policies and (requested is None or "score_centered::"+str(name) in requested):
            policies["score_centered::"+str(name)] = _evaluate(grid, _schedule(grid, "score_centered", str(name)), events, include_trace)
    random_results = [_evaluate(grid, _schedule(grid, "random", seed=config.seed+i), events, False)
                      for i in range(random_repeats)]
    return {"replay_version": VERSION, "frozen_common_replay_version": common.REPLAY_VERSION,
        "configuration": asdict(config), "support": grid.support, "policies": policies,
        "supplemental_postselection_sensitivity_only": True, "eligible_for_model_promotion": False,
        "random": {"repeats": random_repeats, "seeds": list(range(config.seed, config.seed+random_repeats)),
            "summary": _random_summary(random_results),
            "trials": [{"scopes": {scope: {key: value for key, value in result["scopes"][scope].items()
                if key not in ("cases", "per_match")} for scope in common.SCOPES}} for result in random_results]},
        "test_used": False,
        "definitions": {"active": "Original source_end strictly exceeds actual action/event time; inactive scores are never read or gap-penalized",
            "blank": "A selected stream ending mid-tick is clipped there; the display remains blank until next fixed action, even if another source survives",
            "forced_fallback": "Preferred fixed-stay or missing-score hold falls back to lexicographic active source. Scored/random/RR policies select normally among active sources; ended prior stream receives no staying bonus",
            "event_strata": "Actual source count at the event timestamp, not the preceding action. One-active tails are trivial availability, separately reported from>=2 competition",
            "event_denominators": "All annotated groups inside their OWN recorded source, including separately reported initial warmup. An annotation outside its own source is unavailable, not a fabricated missed frame",
            "policy_input": "Causal completed observations, past scores, previous selection and currently available sources only; annotations never choose a match",
            "no_reselection": "This supplementary mode never ranks/promotes models; preserve the fixed common-four-match primary selection"}}


def evaluate_frozen_full_source_selection(rows, scores_by_model, events, *, half_durations,
                                           frozen_policy, config=None, random_repeats=32, include_trace=True):
    """Restrict supplemental evaluation to fixed winner + preserved references.

    The caller must read/freeze selection from primary common-period validation
    first. Extra newly trained candidate arrays are filtered out, never searched.
    """
    if not frozen_policy.startswith(("score::", "score_centered::")):
        raise ValueError("Supply the already selected score/model policy, not a new full-source search")
    chosen = frozen_policy.split("::", 1)[1]
    required = {chosen, "baseline", "logistic"}
    if not required <= set(scores_by_model):
        raise ValueError("Frozen selected model and both preserved reference predictions required")
    config = config or FullReplayConfig(prediction_latency_seconds=1, include_centered_policies=True)
    if config.session_end_rule != "full_available":
        raise ValueError("This wrapper is only for supplementary full-source availability")
    policies = {frozen_policy, "score::baseline", "score::logistic"}
    if config.include_centered_policies:
        policies |= {"score_centered::baseline", "score_centered::logistic"}
    result = compare_full_source_policies(rows, {name: scores_by_model[name] for name in sorted(required)}, events,
        half_durations=half_durations, config=config, random_repeats=random_repeats, include_trace=include_trace,
        score_policy_keys=policies)
    if frozen_policy not in result["policies"]:
        raise ValueError("Frozen policy's centering/configuration is absent; do not silently substitute another policy")
    result.update(frozen_selected_policy=frozen_policy, model_reselection_performed=False,
        newly_trained_candidates_evaluated=[chosen] if chosen not in ("baseline", "logistic") else [],
        other_candidate_arrays_ignored=sorted(set(scores_by_model)-required))
    return result
