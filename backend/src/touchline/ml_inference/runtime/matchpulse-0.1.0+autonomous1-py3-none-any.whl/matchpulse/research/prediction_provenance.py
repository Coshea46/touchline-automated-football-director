"""Deterministic score-file/row-order provenance, separate from label values.

Producer-side sidecars bind each positional prediction vector to the exact
ordered original observation IDs/times. Ensemble verification never creates a
missing producer sidecar retroactively. No model fitting or data file discovery.
"""

import hashlib
import json
from pathlib import Path

import numpy as np

VERSION='matchpulse-prediction-identity-v1'
STANDARD_SETS=(('eligible','train'),('eligible','valid'),('grid','train'),('grid','valid'))


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def file_sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def row_identity(rows):
    records=[];seen=set()
    for row in rows:
        if row['split'] not in ('train','valid'):raise ValueError('Prediction provenance forbids test/unknown split rows')
        identifier=row['window_id']
        if not isinstance(identifier,str) or not identifier or identifier in seen:raise ValueError('Unique original prediction row IDs required')
        seen.add(identifier)
        start,end=float(row['observation_start_seconds']),float(row['observation_end_seconds'])
        if not np.isfinite(start) or not np.isfinite(end) or not start<end:raise ValueError('Finite increasing observation intervals required')
        records.append([identifier,str(row['match_id']),int(row['half']),row['split'],start,end])
    return canonical_sha(records)


def matrix_identity(matrix):
    """Hash canonical shape/dtype plus C-order numerical bytes, without copying if contiguous."""
    array=np.asarray(matrix)
    if array.dtype.kind not in 'fiu' or not np.isfinite(array).all():raise ValueError('Finite numeric matrix required for provenance')
    header={'shape':list(array.shape),'dtype':array.dtype.str,'order':'C'}
    digest=hashlib.sha256(json.dumps(header,sort_keys=True,separators=(',',':')).encode()+b'\n')
    contiguous=np.ascontiguousarray(array)
    if contiguous.size:digest.update(memoryview(contiguous).cast('B'))
    return {'sha256':digest.hexdigest(),'shape':list(array.shape),'dtype':str(array.dtype),'dtype_code':array.dtype.str,
            'hash_definition':'canonical shape/dtype header, newline, C-order numerical bytes'}


def prediction_identity(directory,rows,cohort_sha256,*,experiment=None,required_score_sets=None):
    directory=Path(directory)
    if not isinstance(cohort_sha256,str) or len(cohort_sha256)!=64 or any(c not in '0123456789abcdef' for c in cohort_sha256):
        raise ValueError('An exact source cohort SHA-256 is required')
    required=set(STANDARD_SETS if required_score_sets is None else map(tuple,required_score_sets))
    if not required or not required<=set(STANDARD_SETS):raise ValueError('Explicit train/valid eligible/grid score-set policy required')
    present={scope for scope in STANDARD_SETS if (directory/f'{scope[0]}-{scope[1]}-scores.npy').is_file()}
    if not required<=present:raise ValueError('Required producer prediction files are incomplete: '+str(sorted(required-present)))
    files={}
    for kind,split in sorted(present):
        rr=rows[kind][split]
        if any(row['split']!=split for row in rr):raise ValueError('Prediction row scope disagrees with score filename')
        path=directory/f'{kind}-{split}-scores.npy';digest=file_sha(path)
        scores=np.load(path,allow_pickle=False)
        if scores.shape!=(len(rr),) or scores.dtype.kind!='f' or not np.isfinite(scores).all() or np.any((scores<0)|(scores>1)):
            raise ValueError('Producer scores must be one finite [0,1] floating value per exact row')
        if file_sha(path)!=digest:raise ValueError('Prediction file changed during provenance snapshot')
        files[f'{kind}-{split}']={'path':path.name,'sha256':digest,'bytes':path.stat().st_size,
            'shape':list(scores.shape),'dtype':str(scores.dtype),'rows':len(rr),
            'sample_ids_sha256':canonical_sha([row['window_id'] for row in rr]),'row_identity_sha256':row_identity(rr)}
    return {'version':VERSION,'experiment':str(experiment or directory.name),'cohort_sha256':cohort_sha256,
        'required_score_sets':[list(s) for s in sorted(required)],'present_score_sets':[list(s) for s in sorted(present)],
        'omitted_standard_score_sets':[list(s) for s in STANDARD_SETS if s not in present],
        'files':files,'identity_columns':['window_id','match_id','half','split','observation_start_seconds','observation_end_seconds'],
        'label_values_hashed':False,'test_accessed':False}


def write_prediction_identity(directory,rows,cohort_sha256,*,experiment=None,required_score_sets=None):
    """Producer operation after score writes; never replace a differing completed sidecar."""
    directory=Path(directory);manifest=prediction_identity(directory,rows,cohort_sha256,experiment=experiment,required_score_sets=required_score_sets)
    path=directory/'prediction-identity.json'
    if path.exists():
        if json.loads(path.read_text(encoding='utf-8'))!=manifest:raise ValueError('Existing producer prediction identity differs; never overwrite')
    else:
        temporary=path.with_name(path.name+'.tmp')
        temporary.write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        temporary.replace(path)
    return manifest


def verify_prediction_identity(directory,rows,cohort_sha256,*,experiment=None,required_score_sets=None):
    """Consumer operation: require an already written producer-side binding."""
    path=Path(directory)/'prediction-identity.json'
    if not path.is_file():raise ValueError('Producer prediction-identity.json is required; never synthesize it in the consumer')
    expected=prediction_identity(directory,rows,cohort_sha256,experiment=experiment,required_score_sets=required_score_sets)
    actual=json.loads(path.read_text(encoding='utf-8'))
    if actual!=expected:raise ValueError('Producer prediction identity/score SHA/row order changed')
    return actual
