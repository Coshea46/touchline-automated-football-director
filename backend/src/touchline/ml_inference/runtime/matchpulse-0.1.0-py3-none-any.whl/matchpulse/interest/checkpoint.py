"""Portable tensor-only checkpoints and the application's score API."""

import os
import time
from pathlib import Path

import numpy as np
import torch

from matchpulse.features.schema import SCHEMA_VERSION, validate

from .models import build_model
from .preprocessing import MaskedStandardizer

CHECKPOINT_VERSION = "matchpulse-interest-v1"


def atomic_checkpoint(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as stream:
        torch.save(value, stream)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def export_checkpoint(
    path,
    model,
    model_config,
    normalization,
    *,
    threshold,
    audit,
    study_config,
    validation_metrics,
    experiment=None,
):
    atomic_checkpoint(
        path,
        {
            "checkpoint_version": CHECKPOINT_VERSION,
            "architecture": model_config,
            "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
            "feature_schema_version": SCHEMA_VERSION,
            "clip_duration_seconds": 5,
            "sampling_fps": 15,
            "input_shape": [75, 215],
            "model_input_size": model_config["input_size"],
            "feature_indices": list(range(model_config["input_size"])),
            "normalization": normalization.to_dict(),
            "decision_threshold": float(threshold),
            "threshold_comparator": ">=",
            "threshold_selection_split": "valid",
            "training_seed": study_config.seed,
            "training_configuration": study_config.to_dict(),
            "experiment_configuration": experiment,
            "training_pos_weight": audit["pos_weight"],
            "optimizer": "AdamW",
            "loss": "BCEWithLogitsLoss",
            "forwarding_definition": study_config.forwarding_mode,
            "event_label_version": audit["label_version"],
            "event_label_config_sha256": audit["label_config_sha256"],
            "event_labelling_configuration": audit["label_configuration"],
            "dataset_audit_sha256": audit["audit_sha256"],
            "validation_metrics": validation_metrics,
            "score_semantics": "Uncalibrated interest score; probability calibration has not been evaluated.",
        },
    )


class InterestClassifier:
    def __init__(self, checkpoint, device="cpu"):
        if (
            checkpoint["checkpoint_version"] != CHECKPOINT_VERSION
            or checkpoint["feature_schema_version"] != SCHEMA_VERSION
        ):
            raise ValueError("Unsupported classifier/feature schema")
        if (
            checkpoint["input_shape"] != [75, 215]
            or checkpoint["sampling_fps"] != 15
            or checkpoint["clip_duration_seconds"] != 5
        ):
            raise ValueError("Classifier observation contract mismatch")
        self.device = torch.device(device)
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("Requested CUDA device is unavailable")
        self.normalization = MaskedStandardizer.from_dict(checkpoint["normalization"])
        self.model = build_model(checkpoint["architecture"]).to(self.device)
        self.model.load_state_dict(checkpoint["state_dict"], strict=True)
        self.model.eval()
        self.input_size = checkpoint["architecture"]["input_size"]
        if checkpoint["feature_indices"] != list(range(self.input_size)) or self.input_size not in (210, 215):
            raise ValueError("Unsupported classifier feature selection")
        self.threshold = float(checkpoint["decision_threshold"])
        if not np.isfinite(self.threshold) or checkpoint["threshold_selection_split"] != "valid":
            raise ValueError("A validation-selected operating threshold is required")
        self.metadata = {k: v for k, v in checkpoint.items() if k != "state_dict"}

    def predict_batch(self, features):
        features = np.asarray(features)
        if features.ndim != 3 or features.shape[1:] != (75, 215) or features.dtype != np.float32:
            raise ValueError("Expected float32 [batch,75,215] raw features")
        for sample in features:
            validate(sample, steps=75)
        x = self.normalization.transform(features)[..., : self.input_size]
        x = torch.from_numpy(np.ascontiguousarray(x)).to(self.device)
        with torch.inference_mode():
            return self.model(x).sigmoid().cpu().numpy()

    def predict(self, features):
        features = np.asarray(features)
        if features.shape != (75, 215):
            raise ValueError("Expected a single (75,215) feature sequence")
        return float(self.predict_batch(features[None])[0])


def load_interest_classifier(path, *, device="cpu"):
    started = time.perf_counter()
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    classifier = InterestClassifier(checkpoint, device)
    if classifier.device.type == "cuda":
        torch.cuda.synchronize(classifier.device)
    classifier.load_seconds = time.perf_counter() - started
    return classifier
