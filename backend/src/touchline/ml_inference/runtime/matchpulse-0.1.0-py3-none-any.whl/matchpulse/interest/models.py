"""Lightweight logit models; the TCN never reads a future timestep."""

import torch.nn.functional as F
from torch import nn


class InterestGRU(nn.Module):
    def __init__(self, input_size=215, hidden_size=64, dropout=0.2):
        super().__init__()
        self.gru = nn.GRU(input_size, hidden_size, num_layers=1, batch_first=True)
        self.head = nn.Sequential(
            nn.Linear(hidden_size, 32), nn.ReLU(), nn.Dropout(dropout), nn.Linear(32, 1)
        )

    def forward(self, x):
        _, hidden = self.gru(x)
        return self.head(hidden[-1]).squeeze(-1)


class CausalConv(nn.Module):
    def __init__(self, channels, kernel_size, dilation):
        super().__init__()
        self.left = (kernel_size - 1) * dilation
        self.conv = nn.Conv1d(channels, channels, kernel_size, dilation=dilation)

    def forward(self, x):
        return self.conv(F.pad(x, (self.left, 0)))


class ResidualBlock(nn.Module):
    def __init__(self, channels, kernel_size, dilation, dropout):
        super().__init__()
        self.block = nn.Sequential(
            CausalConv(channels, kernel_size, dilation),
            nn.ReLU(),
            nn.Dropout(dropout),
            CausalConv(channels, kernel_size, dilation),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        return F.relu(x + self.block(x))


class InterestTCN(nn.Module):
    def __init__(self, input_size=215, channels=32, kernel_size=3, dilations=(1, 2, 4), dropout=0.2):
        super().__init__()
        self.projection = nn.Conv1d(input_size, channels, 1)
        self.blocks = nn.Sequential(*(ResidualBlock(channels, kernel_size, d, dropout) for d in dilations))
        self.head = nn.Sequential(nn.Linear(channels, 32), nn.ReLU(), nn.Dropout(dropout), nn.Linear(32, 1))
        self.receptive_field = 1 + 2 * (kernel_size - 1) * sum(dilations)

    def encode(self, x):
        return self.blocks(self.projection(x.transpose(1, 2)))

    def forward(self, x):
        return self.head(self.encode(x)[:, :, -1]).squeeze(-1)


def build_model(config):
    config = dict(config)
    kind = config.pop("kind")
    if kind == "gru":
        return InterestGRU(**config)
    if kind == "tcn":
        return InterestTCN(**config)
    raise ValueError(f"Unknown architecture: {kind}")


def parameter_count(model):
    return sum(p.numel() for p in model.parameters())
