"""PTS-based decoding. Arrays are uint8 (T,H,W,3) RGB; audio is time-major.

The sample at each interval centre is the source frame displayed at that time
(latest PTS <= centre). Source frames at/after the endpoint are never selected.
"""

from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

import av
import numpy as np

from .config import load_clip_duration, validate_duration
from .schema import FPS, sampling_timestamps


@dataclass
class VideoWindow:
    frames: list[np.ndarray]
    timestamps: np.ndarray
    source_timestamps: np.ndarray
    keys: list[tuple]
    audio: np.ndarray | None = None
    audio_sample_rate: int | None = None


def from_array(video, fps=None, *, duration_seconds=None):
    duration = load_clip_duration() if duration_seconds is None else validate_duration(duration_seconds)
    timestamps = sampling_timestamps(duration)
    if not isinstance(video, np.ndarray) or video.ndim != 4 or video.shape[-1] != 3:
        raise ValueError("NumPy video must be (T,H,W,3) RGB")
    if video.dtype != np.uint8 or min(video.shape[1:3]) < 16:
        raise ValueError("Video must be uint8 RGB with dimensions >=16 pixels")
    if fps is None:
        if len(video) != len(timestamps):
            raise ValueError(f"Source fps is required unless exactly {len(timestamps)} frames at 15 FPS")
        fps = float(FPS)
    if not np.isfinite(fps) or fps < 5 or fps > 1000:
        raise ValueError("Source fps must be finite and between 5 and 1000")
    if len(video) != int(np.ceil(duration * fps - 1e-9)):
        raise ValueError(f"Expected a complete {duration:g}-second video array")
    indices = np.floor(timestamps * fps + 1e-9).astype(int)
    if indices[-1] >= len(video):
        raise ValueError("Video is incomplete at observation endpoint")
    frames = [np.ascontiguousarray(video[i]) for i in indices]
    return VideoWindow(frames, timestamps, indices / fps, [])


def _stream_bounds(stream):
    origin = float((stream.start_time or 0) * stream.time_base)
    duration = float(stream.duration * stream.time_base) if stream.duration is not None else None
    return origin, duration


def from_file(path, *, start=None, cache=None, duration_seconds=None):
    observation_duration = (
        load_clip_duration() if duration_seconds is None else validate_duration(duration_seconds)
    )
    timestamps = sampling_timestamps(observation_duration)
    path = Path(path).resolve(strict=True)
    if not path.is_file():
        raise ValueError("Video input must be a file")
    windowed = start is not None
    start = 0.0 if start is None else float(start)
    if not np.isfinite(start) or start < 0:
        raise ValueError("Window start must be finite and non-negative")
    end = start + observation_duration
    stat = path.stat()
    identity = (str(path), stat.st_size, stat.st_mtime_ns)
    targets = start + timestamps
    keys = [(identity, round(float(t), 9)) for t in targets]
    values = [cache.get(k) if cache else None for k in keys]
    try:
        with av.open(str(path)) as container:
            if not container.streams.video:
                raise ValueError("File contains no video stream")
            stream = container.streams.video[0]
            origin, duration = _stream_bounds(stream)
            if duration is not None:
                if duration < end - 0.075 or (not windowed and abs(duration - observation_duration) > 0.1):
                    raise ValueError(
                        f"Expected {observation_duration:g} seconds; use extract_window for longer source files"
                    )
            missing = [i for i, v in enumerate(values) if v is None]
            if missing:
                first = missing[0]
                seek_time = max(0, targets[first] - 0.25) + origin
                container.seek(int(seek_time / stream.time_base), stream=stream, backward=True)
                pending = iter(missing)
                idx = next(pending, None)
                previous = None
                last_pts = None
                frame_duration = None
                shape = None
                for frame in container.decode(stream):
                    if frame.pts is None:
                        raise ValueError("Decoded frame has no presentation timestamp")
                    t = float(frame.pts * stream.time_base) - origin
                    if last_pts is not None and t <= last_pts:
                        raise ValueError("Non-monotonic video presentation timestamps")
                    # A frame beyond the window may bound the final frame's display interval,
                    # but its pixels are never read and never enter any analysis.
                    while idx is not None and targets[idx] < t - 1e-8:
                        if previous is None or targets[idx] - previous[0] > 0.21:
                            raise ValueError("Materially incomplete video / timestamp gap >210ms")
                        if isinstance(previous[1], av.VideoFrame):
                            previous = (previous[0], previous[1].to_ndarray(format="rgb24"))
                        values[idx] = previous
                        idx = next(pending, None)
                    if t >= end or idx is None:
                        break
                    if shape is not None and shape != (frame.height, frame.width):
                        raise ValueError("Frame dimensions change inside observation window")
                    shape = (frame.height, frame.width)
                    if min(shape) < 16 or frame.is_corrupt:
                        raise ValueError("Corrupt or invalid video frame")
                    # Convert only frames that could be displayed at a requested target.
                    previous = (t, frame)
                    last_pts = t
                    frame_duration = float(frame.duration * stream.time_base) if frame.duration else None
                while idx is not None:
                    if previous is None:
                        raise ValueError("Unable to decode observation window")
                    coverage_end = previous[0] + (frame_duration or 0)
                    if coverage_end < targets[idx] - 0.01 or targets[idx] - previous[0] > 0.21:
                        raise ValueError("Decoded video ends before the final sampling interval")
                    if isinstance(previous[1], av.VideoFrame):
                        previous = (previous[0], previous[1].to_ndarray(format="rgb24"))
                    values[idx] = previous
                    idx = next(pending, None)
                if cache:
                    # Cache immutable pixels and source PTS together; approximate size via pixels.
                    for i in missing:
                        t, pixels = values[i]
                        pixels.flags.writeable = False
                        cache.put(keys[i], pixels)
                        cache.put((keys[i], "pts"), np.array([t], dtype=np.float64))
            # Cache entries hold arrays, new entries above hold (PTS,array).
            frames, source_pts = [], []
            for k, value in zip(keys, values, strict=True):
                if isinstance(value, tuple):
                    t, pixels = value
                else:
                    pixels = value
                    pts = cache.get((k, "pts"))
                    if pts is None:
                        # Byte-bounded eviction may split metadata: retry cleanly.
                        return from_file(
                            path,
                            start=start if windowed else None,
                            cache=None,
                            duration_seconds=observation_duration,
                        )
                    t = float(pts[0])
                frames.append(pixels)
                source_pts.append(t)
            if len({f.shape for f in frames}) != 1:
                raise ValueError("Inconsistent sampled frame dimensions")
        audio, rate = decode_audio(path, start, end, origin)
        return VideoWindow(frames, timestamps, np.asarray(source_pts) - start, keys, audio, rate)
    except (av.error.FFmpegError, EOFError) as exc:
        raise ValueError(f"Cannot decode video {path.name}: {exc}") from exc


def decode_audio(path, start, end, video_origin):
    """Decode/resample to mono 16kHz, respecting stream PTS and video start offset.

    Gaps are represented by NaN internally; the audio feature layer emits an
    unavailable interval rather than mistaking decoder gaps for digital silence.
    """
    rate = 16000
    with av.open(str(path)) as container:
        if not container.streams.audio:
            return None, None
        stream = container.streams.audio[0]
        container.seek(max(0, int((video_origin + start - 0.25) * av.time_base)), backward=True)
        channels = 1 if len(stream.codec_context.layout.channels) == 1 else 2
        resampler = av.AudioResampler(format="fltp", layout="mono" if channels == 1 else "stereo", rate=rate)
        waveform = np.full((round((end - start) * rate), channels), np.nan, dtype=np.float32)

        def store(frame):
            if frame.pts is None:
                raise ValueError("Audio has no presentation timestamps")
            t = float(frame.pts * frame.time_base) - video_origin
            # Preserve stereo power (including opposite-phase channels) until
            # feature extraction; codec PCM can overshoot full scale slightly.
            data = np.clip(frame.to_ndarray().T, -1.0, 1.0)
            offset = round((t - start) * rate)
            a, b = max(0, offset), min(len(waveform), offset + len(data))
            if b > a:
                waveform[a:b] = data[a - offset : b - offset]

        for frame in container.decode(stream):
            if frame.pts is None:
                raise ValueError("Audio has no presentation timestamps")
            frame_time = float(frame.pts * frame.time_base)
            if frame_time - video_origin >= end:
                break
            # Crop BEFORE resampling: even the resampling filter must not see
            # waveform samples beyond the observation endpoint.
            a = max(0, int(np.ceil((video_origin + start - frame_time) * frame.sample_rate - 1e-7)))
            b = min(frame.samples, int(np.ceil((video_origin + end - frame_time) * frame.sample_rate - 1e-7)))
            if b <= a:
                continue
            if a > 0 or b < frame.samples:
                raw = frame.to_ndarray()
                channels = len(frame.layout.channels)
                cropped = raw[:, a:b] if frame.format.is_planar else raw[:, a * channels : b * channels]
                clipped = av.AudioFrame.from_ndarray(
                    np.ascontiguousarray(cropped), format=frame.format.name, layout=frame.layout.name
                )
                clipped.sample_rate = frame.sample_rate
                clipped.time_base = Fraction(1, frame.sample_rate)
                clipped.pts = round(frame_time * frame.sample_rate) + a
                frame = clipped
            for converted in resampler.resample(frame):
                store(converted)
        for converted in resampler.resample(None):
            store(converted)
    return waveform[:, 0] if channels == 1 else waveform, rate
